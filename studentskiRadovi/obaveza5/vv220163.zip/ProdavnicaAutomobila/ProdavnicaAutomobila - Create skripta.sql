
CREATE TABLE [Automobil]
( 
	[Id]                 integer  NOT NULL ,
	[RegBr]              varchar(7)  NULL ,
	[IdM]                integer  NOT NULL 
)
go

ALTER TABLE [Automobil]
	ADD CONSTRAINT [XPKAutomobil] PRIMARY KEY  CLUSTERED ([Id] ASC)
go

CREATE TABLE [Dobavljac]
( 
	[Id]                 integer  NOT NULL ,
	[Naziv]              varchar(20)  NULL ,
	[BrDobavljenih]      integer  NULL 
)
go

ALTER TABLE [Dobavljac]
	ADD CONSTRAINT [XPKDobavljac] PRIMARY KEY  CLUSTERED ([Id] ASC)
go

CREATE TABLE [Kupac]
( 
	[Id]                 integer  NOT NULL ,
	[Ime]                varchar(20)  NULL ,
	[Prezime]            varchar(20)  NULL ,
	[BrLK]               varchar(9)  NULL ,
	[BrKupljenih]        integer  NULL 
)
go

ALTER TABLE [Kupac]
	ADD CONSTRAINT [XPKKupac] PRIMARY KEY  CLUSTERED ([Id] ASC)
go

CREATE TABLE [Kupovina]
( 
	[IdA]                integer  NOT NULL ,
	[IdK]                integer  NOT NULL ,
	[DatumVreme]         datetime  NULL ,
	[Cena]               decimal(10,2)  NULL 
)
go

ALTER TABLE [Kupovina]
	ADD CONSTRAINT [XPKKupovina] PRIMARY KEY  CLUSTERED ([IdA] ASC)
go

CREATE TABLE [Model]
( 
	[Id]                 integer  NOT NULL ,
	[Marka]              varchar(20)  NULL ,
	[Model]              varchar(20)  NULL ,
	[BrProdatih]         integer  NULL ,
	[BrNabavljenih]      integer  NULL ,
	[Profit]             decimal(20,2)  NULL 
)
go

ALTER TABLE [Model]
	ADD CONSTRAINT [XPKModel] PRIMARY KEY  CLUSTERED ([Id] ASC)
go

CREATE TABLE [Nabavka]
( 
	[DatumVreme]         datetime  NULL ,
	[IdA]                integer  NOT NULL ,
	[IdD]                integer  NOT NULL ,
	[Cena]               decimal(10,2)  NULL 
)
go

ALTER TABLE [Nabavka]
	ADD CONSTRAINT [XPKNabavka] PRIMARY KEY  CLUSTERED ([IdA] ASC)
go


ALTER TABLE [Automobil]
	ADD CONSTRAINT [R_1] FOREIGN KEY ([IdM]) REFERENCES [Model]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [Kupovina]
	ADD CONSTRAINT [R_2] FOREIGN KEY ([IdA]) REFERENCES [Automobil]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Kupovina]
	ADD CONSTRAINT [R_3] FOREIGN KEY ([IdK]) REFERENCES [Kupac]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [Nabavka]
	ADD CONSTRAINT [R_4] FOREIGN KEY ([IdA]) REFERENCES [Automobil]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Nabavka]
	ADD CONSTRAINT [R_5] FOREIGN KEY ([IdD]) REFERENCES [Dobavljac]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go
