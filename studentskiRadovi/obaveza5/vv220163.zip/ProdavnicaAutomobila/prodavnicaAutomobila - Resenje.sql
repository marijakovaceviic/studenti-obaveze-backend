ALTER TRIGGER formirajStatistiku1
    ON Nabavka
    FOR DELETE, INSERT, UPDATE
    AS
    BEGIN
		declare @kursor cursor
		declare @idA int, @cena int, @idM int, @idD int

		set @kursor = cursor for
		select Cena, IdA, IdD
		from inserted

		open @kursor

		fetch from @kursor
		into @cena, @idA, @idD

		while @@FETCH_STATUS = 0
		begin
			select @idM = IdM
			from Automobil
			where Id = @idA

			update Model
			set BrNabavljenih = BrNabavljenih + 1,
			Profit = Profit - @cena
			where Id = @idM

			update Dobavljac
			set BrDobavljenih = BrDobavljenih + 1
			where Id = @idD

			fetch from @kursor
			into @cena, @idA, @idD
		end

		close @kursor
		deallocate @kursor

		set @kursor = cursor for
		select Cena, IdA, IdD
		from deleted

		fetch from @kursor
		into @cena, @idA, @idD

		while @@FETCH_STATUS = 0
		begin
			select @idM = IdM
			from Automobil
			where Id = @idA

			update Model
			set BrNabavljenih = BrNabavljenih - 1,
			Profit = Profit + @cena
			where Id = @idM

			update Dobavljac
			set BrDobavljenih = BrDobavljenih - 1
			where Id = @idD

			fetch from @kursor
			into @cena, @idA, @idD
		end

		close @kursor
		deallocate @kursor
    END


ALTER TRIGGER formirajStatistiku2
    ON Kupovina
    FOR DELETE, INSERT, UPDATE
    AS
    BEGIN
		declare @kursor cursor
		declare @idA int, @cena int, @idM int, @idK int

		set @kursor = cursor for
		select Cena, IdA, IdK
		from inserted

		open @kursor

		fetch from @kursor
		into @cena, @idA, @idK

		while @@FETCH_STATUS = 0
		begin
			select @idM = IdM
			from Automobil
			where Id = @idA

			update Model
			set BrProdatih = BrProdatih + 1,
			Profit = Profit + @cena
			where Id = @idM

			update Kupac
			set BrKupljenih = BrKupljenih + 1
			where Id = @idK

			fetch from @kursor
			into @cena, @idA, @idK
		end
		
		close @kursor
		deallocate @kursor

		set @kursor = cursor for
		select Cena, IdA, IdK
		from deleted

		fetch from @kursor
		into @cena, @idA, @idK

		while @@FETCH_STATUS = 0
		begin
			select @idM = IdM
			from Automobil
			where Id = @idA

			update Model
			set BrProdatih = BrProdatih - 1,
			Profit = Profit - @cena
			where Id = @idM

			update Kupac
			set BrKupljenih = BrKupljenih - 1
			where Id = @idK

			fetch from @kursor
			into @cena, @idA, @idK
		end

		close @kursor
		deallocate @kursor
    END
