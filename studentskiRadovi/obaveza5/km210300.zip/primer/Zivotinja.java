package primer;

public abstract class Zivotinja extends Thread {
	
	protected Kosnica kosnica;
	private int minVreme, maxVreme;
	private boolean radi = true;
	
	public Zivotinja(Kosnica kosnica, 
			int minVreme, int maxVreme) {
		super();
		this.kosnica = kosnica;
		this.minVreme = minVreme;
		this.maxVreme = maxVreme;
	}
	
	public synchronized void zaustavi() { radi = false; }
	public synchronized void nastavi() { radi = true; notifyAll(); }
	public void prekini() { interrupt(); }
	
	@Override
	public void run() {
		try {
			while(!Thread.interrupted()) {
				synchronized (this) {
					while (!radi) wait();
				}
				Thread.sleep(minVreme + (int)(Math.random() * 
					(maxVreme - minVreme)));
				akcija();
			}
		} catch (InterruptedException e) {}
		// ...
		
	}

	protected abstract void akcija() throws InterruptedException ;

}
