package primer;

import java.util.Scanner;

public class Test {
	
	public static final int N = 5;

	public static void main(String[] args) {

		Kosnica kosnica = new Kosnica(10);
		Meda meda = new Meda(kosnica, 100, 200);
		Pcela[] pcele = new Pcela[N];
		for (int i = 0; i < N; i++) {
			pcele[i] = new Pcela(kosnica, 500, 1000, i);
		}
		for (int i = 0; i < N; i++) {
			pcele[i].start();
		}
		meda.start();
		
		Scanner sc = new Scanner(System.in);
		sc.nextLine();
		
		meda.zaustavi();
		
		sc.nextLine();
		
		meda.nastavi();

		sc.nextLine();
		
		for (int i = 0; i < N; i++) {
			pcele[i].interrupt();
		}
		
		sc.nextLine();
		meda.interrupt();
		
		for (int i = 0; i < N; i++) {
			try {
				pcele[i].join();
			} catch (InterruptedException e) {}
		}
		try {
			meda.join();
		} catch (InterruptedException e) {}
		
		int proizvedeno = 0;
		for (int i = 0; i < N; i++) {
			proizvedeno += pcele[i].dohvatiProizvedenMed();
		}
		int pojedeno = meda.dohvatiPojedenMed();
		
		System.out.println("Proizveden med: " + proizvedeno);
		System.out.println("Pojden med: " + pojedeno);
		System.out.println("Med u kosnici: " + kosnica.dohvatiMed());
		
		sc.close();
		
	}

}
