
CREATE TABLE [Osoba]
( 
	[Id]                 integer  NOT NULL ,
	[Ime]                varchar(20)  NULL ,
	[Prezime]            varchar(20)  NULL ,
	[BrPoslatih]         integer  NULL ,
	[BrPrimljenih]       integer  NULL 
)
go

ALTER TABLE [Osoba]
	ADD CONSTRAINT [XPKOsoba] PRIMARY KEY  CLUSTERED ([Id] ASC)
go

CREATE TABLE [Paket]
( 
	[Id]                 integer  NOT NULL ,
	[Opis]               varchar(200)  NULL ,
	[Kapacitet]          integer  NULL ,
	[Adresa]             varchar(200)  NULL ,
	[Status]             char(1)  NULL ,
	[IdPos]              integer  NOT NULL ,
	[IdPri]              integer  NOT NULL ,
	[VremeKreiranja]     datetime  NULL 
)
go

ALTER TABLE [Paket]
	ADD CONSTRAINT [XPKPaket] PRIMARY KEY  CLUSTERED ([Id] ASC)
go

CREATE TABLE [Smesteno]
( 
	[IdV]                integer  NOT NULL ,
	[IdP]                integer  NOT NULL 
)
go

ALTER TABLE [Smesteno]
	ADD CONSTRAINT [XPKSmesteno] PRIMARY KEY  CLUSTERED ([IdV] ASC,[IdP] ASC)
go

CREATE TABLE [Vozilo]
( 
	[Id]                 integer  NOT NULL ,
	[Kapacitet]          integer  NULL ,
	[Status]             varchar(1)  NULL ,
	[Zauzeto]            integer  NULL 
)
go

ALTER TABLE [Vozilo]
	ADD CONSTRAINT [XPKVozilo] PRIMARY KEY  CLUSTERED ([Id] ASC)
go


ALTER TABLE [Paket]
	ADD CONSTRAINT [R_1] FOREIGN KEY ([IdPos]) REFERENCES [Osoba]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Paket]
	ADD CONSTRAINT [R_2] FOREIGN KEY ([IdPri]) REFERENCES [Osoba]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go


ALTER TABLE [Smesteno]
	ADD CONSTRAINT [R_3] FOREIGN KEY ([IdV]) REFERENCES [Vozilo]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [Smesteno]
	ADD CONSTRAINT [R_4] FOREIGN KEY ([IdP]) REFERENCES [Paket]([Id])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go
