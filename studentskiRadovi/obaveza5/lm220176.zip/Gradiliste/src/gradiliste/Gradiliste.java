/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gradiliste;

import entiteti.Distributer;
import entiteti.Kupljeno;
import entiteti.Materijal;
import entiteti.Ocena;
import entiteti.Ponuda;
import entiteti.Projekat;
import entiteti.Projektant;
import entiteti.Radi;
import entiteti.Radio;
import entiteti.Radnik;
import entiteti.Utroseno;
import entiteti.Zaposleni;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * @author stefan
 */
public class Gradiliste {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("GradilistePU");
        EntityManager em = emf.createEntityManager();

        kreirajPocetnoStanje(em);
        upiti(em);
    }
    
    public static void kreirajPocetnoStanje(EntityManager em) {
        em.getTransaction().begin();

        List<Distributer> distributeri = new ArrayList<>();
        distributeri.add(new Distributer("Integraltehnic", "111"));
        distributeri.add(new Distributer("Limis d.o.o.", "222"));
        distributeri.add(new Distributer("Studio K", "333"));
        distributeri.add(new Distributer("Urbana oprema d.o.o. Novi Sad", "444"));
        distributeri.add(new Distributer("Konsalting d.o.o.", "555"));
        distributeri.add(new Distributer("Anti Atom", "666"));
        distributeri.add(new Distributer("D-design d.o.o.", "777"));
        distributeri.add(new Distributer("Modelart Arhitekti - studio za prostorni dizajn", "888"));
        distributeri.add(new Distributer("Tehnomag NS d.o.o.", "999"));

        List<Materijal> materijali = new ArrayList<>();
        materijali.add(new Materijal("Aluminijumska folija"));
        materijali.add(new Materijal("Armatura"));
        materijali.add(new Materijal("Betonski blok"));
        materijali.add(new Materijal("Cement"));
        materijali.add(new Materijal("Cigla"));
        materijali.add(new Materijal("Crep"));
        materijali.add(new Materijal("Krec"));

        List<Ponuda> ponude = new ArrayList<>();
        ponude.add(new Ponuda(100, materijali.get(0), distributeri.get(0)));
        ponude.add(new Ponuda(200, materijali.get(0), distributeri.get(1)));
        ponude.add(new Ponuda(300, materijali.get(1), distributeri.get(2)));
        ponude.add(new Ponuda(400, materijali.get(1), distributeri.get(2)));
        ponude.add(new Ponuda(500, materijali.get(2), distributeri.get(3)));
        ponude.add(new Ponuda(600, materijali.get(3), distributeri.get(4)));
        ponude.add(new Ponuda(700, materijali.get(4), distributeri.get(5)));
        ponude.add(new Ponuda(800, materijali.get(5), distributeri.get(5)));
        ponude.add(new Ponuda(900, materijali.get(5), distributeri.get(6)));

        List<Kupljeno> kupljeno = new ArrayList<>();
        kupljeno.add(new Kupljeno(100, Date.valueOf("2010-5-5"), 5, materijali.get(0), distributeri.get(4)));
        kupljeno.add(new Kupljeno(200, Date.valueOf("2011-7-15"), 2, materijali.get(1), distributeri.get(3)));
        kupljeno.add(new Kupljeno(300, Date.valueOf("2012-3-20"), 1, materijali.get(2), distributeri.get(2)));
        kupljeno.add(new Kupljeno(400, Date.valueOf("2013-1-12"), 3, materijali.get(3), distributeri.get(1)));
        kupljeno.add(new Kupljeno(500, Date.valueOf("2014-10-05"), 4, materijali.get(4), distributeri.get(0)));

        List<Projektant> projektanti = new ArrayList<>();
        projektanti.add(new Projektant("Milos", "Mikic", "2107982720031", 5));
        projektanti.add(new Projektant("Goran", "Jovanovic", "2302983720031", 2));
        projektanti.add(new Projektant("Srdjan", "Stojkovic", "1007987720031", 4));

        List<Radnik> radnici = new ArrayList<>();
        radnici.add(new Radnik("Jovan", "Jovanovic", "1202988720031"));
        radnici.add(new Radnik("Zeljko", "Miskovic", "1202988620031"));
        radnici.add(new Radnik("Milos", "Kumanovic", "1701988720031"));
        radnici.add(new Radnik("Stefan", "Ostojic", "1202988120031"));
        radnici.add(new Radnik("Dejan", "Veselinovic", "1706988120031"));

        Zaposleni zaposleni = new Zaposleni("Dragan", "Jevtic", "1112988420031");

        List<Projekat> projekti = new ArrayList<>();
        projekti.add(new Projekat("22130 - Stambeni kompleks - Novi sad", Date.valueOf("2017-5-5"), projektanti.get(0)));
        projekti.add(new Projekat("1123 - Poslovni kompleks - Kragujevac", Date.valueOf("2016-10-21"), projektanti.get(1)));
        projekti.add(new Projekat("22130 - Zatvoreni bazen - Beograd", Date.valueOf("2015-4-18"), projektanti.get(2)));
        projekti.add(new Projekat("22130 - Soliter - Nis", Date.valueOf("2015-6-21"), projektanti.get(2)));

        List<Radi> rade = new ArrayList<>();
        rade.add(new Radi(radnici.get(0), projekti.get(0)));
        rade.add(new Radi(radnici.get(1), projekti.get(0)));
        rade.add(new Radi(radnici.get(2), projekti.get(0)));
        rade.add(new Radi(radnici.get(3), projekti.get(1)));
        rade.add(new Radi(radnici.get(4), projekti.get(1)));

        List<Radio> radili = new ArrayList<>();
        radili.add(new Radio(projekti.get(2), radnici.get(0)));
        radili.add(new Radio(projekti.get(2), radnici.get(1)));
        radili.add(new Radio(projekti.get(2), radnici.get(2)));
        radili.add(new Radio(projekti.get(3), radnici.get(1)));
        radili.add(new Radio(projekti.get(3), radnici.get(2)));
        radili.add(new Radio(projekti.get(3), radnici.get(3)));
        radili.add(new Radio(projekti.get(3), radnici.get(4)));

        List<Ocena> ocene = new ArrayList<>();
        ocene.add(new Ocena(radili.get(0), Date.valueOf("2015-7-7"), 10));
        ocene.add(new Ocena(radili.get(0), Date.valueOf("2015-7-8"), 9));
        ocene.add(new Ocena(radili.get(0), Date.valueOf("2015-7-9"), 8));
        ocene.add(new Ocena(radili.get(1), Date.valueOf("2015-7-10"), 7));
        ocene.add(new Ocena(radili.get(1), Date.valueOf("2015-7-11"), 10));
        ocene.add(new Ocena(radili.get(1), Date.valueOf("2015-7-12"), 9));
        ocene.add(new Ocena(radili.get(2), Date.valueOf("2015-7-13"), 8));
        ocene.add(new Ocena(radili.get(2), Date.valueOf("2015-7-14"), 9));
        ocene.add(new Ocena(radili.get(2), Date.valueOf("2015-7-15"), 10));
        ocene.add(new Ocena(radili.get(3), Date.valueOf("2015-7-16"), 7));
        ocene.add(new Ocena(radili.get(3), Date.valueOf("2015-7-17"), 10));
        ocene.add(new Ocena(radili.get(3), Date.valueOf("2015-7-18"), 9));
        ocene.add(new Ocena(radili.get(4), Date.valueOf("2015-7-19"), 7));
        ocene.add(new Ocena(radili.get(4), Date.valueOf("2015-7-20"), 8));
        ocene.add(new Ocena(radili.get(4), Date.valueOf("2015-7-21"), 8));

        List<Utroseno> utroseno = new ArrayList<>();
        utroseno.add(new Utroseno(4, Date.valueOf("2014-3-10"), kupljeno.get(0), projekti.get(2)));
        utroseno.add(new Utroseno(2, Date.valueOf("2011-4-11"), kupljeno.get(1), projekti.get(2)));
        utroseno.add(new Utroseno(1, Date.valueOf("2012-05-07"), kupljeno.get(2), projekti.get(3)));
        utroseno.add(new Utroseno(2, Date.valueOf("2013-10-4"), kupljeno.get(3), projekti.get(3)));

        for (Distributer distributer : distributeri) {
            em.persist(distributer);
        }
        
        for (Materijal materijal : materijali) {
            em.persist(materijal);
        }

        for (Ponuda ponuda : ponude) {
            em.persist(ponuda);
        }

        for (Kupljeno kupljen : kupljeno) {
            em.persist(kupljen);
        }

        for (Radnik radnik : radnici) {
            em.persist(radnik);
        }

        for (Projektant projektant : projektanti) {
            em.persist(projektant);
        }

        //em.persist(zaposleni);

        for (Projekat projekat : projekti) {
            em.persist(projekat);
        }

        for (Radi radi : rade) {
            em.persist(radi);
        }

        for (Radio radio : radili) {
            em.persist(radio);
        }

        for (Ocena ocena : ocene) {
            em.persist(ocena);
        }

        for (Utroseno utrosen : utroseno) {
            em.persist(utrosen);
        }

        em.getTransaction().commit();
        em.clear();
    }
    
    public static void upiti(EntityManager em){
        Projekat projekat = em.find(Projekat.class, 1);
        System.out.println(projekat.getNaziv());
        Radnik radnik = em.find(Radnik.class, 4);
        System.out.println(radnik.getIme());

        System.out.println("\nSvi zaposleni:");
        Query query = em.createQuery("SELECT z "
                + "FROM Zaposleni as z");
        List<Zaposleni> zaposleni = query.getResultList();
        for (Zaposleni zaposlen : zaposleni) {
            System.out.println(zaposlen.getIme() + " " + zaposlen.getPrezime());
        }
        
        System.out.println("\nSvi projektanti:");
        query = em.createQuery("SELECT projektant "
                + "FROM Projektant as projektant");
        System.out.println("JMBG | Ime | Prezime");
        List<Projektant> projektanti = query.getResultList();
        for (Projektant projektant : projektanti) {
            System.out.println(projektant.getJMBG() + " " + projektant.getIme() + " " + projektant.getPrezime());
        }
        
        System.out.println("\nRadnici koji rade na projektu ciji je id=3:");
        Projekat projekat3 = em.find(Projekat.class, 3);
        TypedQuery<Radnik> radniciNaProjektu = em.createQuery("SELECT r FROM Radnik r WHERE :projekat MEMBER OF r.projekti", Radnik.class);
        List<Radnik> radnici = radniciNaProjektu.setParameter("projekat", projekat3).getResultList();
        for (Radnik r : radnici) {
            System.out.println("Radnik " + r.getIme());
        }
        
        System.out.println("\nRadnici koji rade na projektu ciji je id=3:");
        Query upit = em.createQuery("SELECT r, p.naziv FROM Radnik r JOIN r.projekti p WHERE p.id = 3", Object[].class);
        List<Object[]> resultList = upit.getResultList();
        for (Object[] objects : resultList) {
            Radnik r = (Radnik) objects[0];
            String nazivProjekta = (String) objects[1];
            
            System.out.println("Radnik " + r.getIme() + " radio na projektu " + nazivProjekta);
        }
        
        System.out.println("\nPrikaz distributera po prosecnoj ceni njihovih ponuda "
                + "sortirano nerastuce po prosecnoj ceni. Treba prikazati samo distributere"
                + " koji ciji je prosek cena veci od 200 a manji od 700.");
        System.out.println("Naziv distributera | Prosecna cena");
        TypedQuery<Object[]> distributeriIPonude = em.createQuery(
                "SELECT p.distributer, AVG(p.cena) prosek "
                + "FROM Ponuda p "
                + "GROUP BY p.distributer "
                + "HAVING prosek > 200 AND prosek < 700 "
                + "ORDER BY prosek DESC", Object[].class);
        
        List<Object[]> rs2 = distributeriIPonude.getResultList();
        
        for (Object[] objects : rs2) {
            Distributer distributer = (Distributer) objects[0];
            double cena = (double) objects[1];
            System.out.println(distributer.getNaziv()+ " " + cena);
        }
        
        System.out.println("\nDistributeri sortirani po prosecnoj ceni njihovih ponuda:");
        System.out.println("Naziv distributera | Prosecna cena");
        query = em.createQuery("SELECT distributer.naziv, AVG(ponuda.cena) "
                + "FROM Materijal as materijal, Distributer as distributer, Ponuda ponuda "
                + "WHERE ponuda.materijal.id = materijal.id AND ponuda.distributer.id = distributer.id "
                + "GROUP BY distributer.id "
                + "ORDER BY AVG(ponuda.cena)");
        List<Object> rezultat = query.getResultList();
        for (Object object : rezultat) {
            Object[] oArray = (Object[]) object;
            System.out.println(oArray[0] + " " + oArray[1]);
        }
        
        System.out.println("\nMaterijal ponudjen od distributera sa id = 2:");
        Distributer d = em.find(Distributer.class, 2);
        List<Materijal> materijali = d.getMaterijaliPonudjeni();
        for (Materijal m : materijali) {
            System.out.println(m.getNaziv());
        }
        
        System.out.println("\nMaterijal:");
        query = em.createNamedQuery("materijal");
        List<Materijal> materijalLista = query.getResultList();
        for (Materijal m : materijalLista) {
            System.out.println(m.getNaziv());
        }
        
        Query nativeQuery = em.createNativeQuery("SELECT * FROM Projekat",Projekat.class);
        List<Projekat> projekti = nativeQuery.getResultList();
        
        System.out.println("\nProjekti");
        for (Projekat p : projekti) {
            System.out.println(p.getNaziv() + " " + p.getId());
        }
        
//        em.setFlushMode(FlushModeType.COMMIT);
//        em.getTransaction().begin();
//        query = em.createQuery("UPDATE Zaposleni z SET z.ime = 'Promenjeno' WHERE z.id = 1 ");
//        query.executeUpdate();
//        em.find(Materijal.class, 1).setNaziv("Promenjeno");
//        em.getTransaction().commit();
    }

    
    
}
