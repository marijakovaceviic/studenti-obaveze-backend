/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package idClass;

import java.io.Serializable;
import java.sql.Date;

/**
 *
 * @author stefan
 */
public class OcenaId implements Serializable{
    private RadioId radio;
    private Date datum;

    public OcenaId() {
    }

    public OcenaId(RadioId radio, Date datum) {
        this.radio = radio;
        this.datum = datum;
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int hashCode() {
        return super.hashCode(); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
