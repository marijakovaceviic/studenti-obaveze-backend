/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package idClass;

import entiteti.Projekat;
import entiteti.Radnik;
import java.io.Serializable;

/**
 *
 * @author stefan
 */
public class RadioId implements Serializable{
    private int projekat;
    private int radnik;

    public RadioId() {
    }

    public RadioId(int projekat, int radnik) {
        this.projekat = projekat;
        this.radnik = radnik;
    }

    public int getProjekat() {
        return projekat;
    }

    public void setProjekat(int projekat) {
        this.projekat = projekat;
    }

    public int getRadnik() {
        return radnik;
    }

    public void setRadnik(int radnik) {
        this.radnik = radnik;
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int hashCode() {
        return super.hashCode(); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
