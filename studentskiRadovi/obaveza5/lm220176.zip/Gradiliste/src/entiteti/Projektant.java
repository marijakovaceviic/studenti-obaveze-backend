/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entiteti;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author stefan
 */
@Entity
@Table(name = "projektant")
public class Projektant extends Zaposleni{
    
    @Column(name = "BrojProjekata")
    private int brojProjekata;
    
    @OneToMany(mappedBy = "projektant")
    private List<Projekat> projekti;

    public Projektant(){
    }

    public Projektant(String ime, String prezime, String jmbg, int brojProjekata) {
        super(ime, prezime, jmbg);
        this.brojProjekata = brojProjekata;
    }
    
    public int getBrojProjekata() {
        return brojProjekata;
    }

    public void setBrojProjekata(int brojProjekata) {
        this.brojProjekata = brojProjekata;
    }

    public List<Projekat> getProjekti() {
        return projekti;
    }

    public void setProjekti(List<Projekat> projekti) {
        this.projekti = projekti;
    }
    
    
}
