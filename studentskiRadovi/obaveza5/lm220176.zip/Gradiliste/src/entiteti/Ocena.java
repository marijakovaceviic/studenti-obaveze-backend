/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entiteti;

import idClass.OcenaId;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author stefan
 */
@Entity
@Table(name = "ocena")
@IdClass(OcenaId.class)
public class Ocena {
    
    @Id
    @ManyToOne
    @JoinColumns({
        @JoinColumn(name = "IdP", referencedColumnName = "IdP"),
        @JoinColumn(name = "IdR", referencedColumnName = "IdR")
    })
    private Radio radio;
    
    @Id
    @Column(name = "Datum")
    private Date datum;
    
    @Column(name = "Ocena")
    private int ocena;

    public Ocena() {
    }

    public Ocena(Radio radio, Date datum, int ocena) {
        this.radio = radio;
        this.datum = datum;
        this.ocena = ocena;
    }

    public Radio getRadio() {
        return radio;
    }

    public void setRadio(Radio radio) {
        this.radio = radio;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public int getOcena() {
        return ocena;
    }

    public void setOcena(int ocena) {
        this.ocena = ocena;
    }

    
    
}
