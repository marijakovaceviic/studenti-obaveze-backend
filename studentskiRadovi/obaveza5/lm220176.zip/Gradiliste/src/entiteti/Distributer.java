/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entiteti;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author stefan
 */
@Entity
@Table(name = "distributer")
public class Distributer {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private int id;
    
    @Column(name = "Naziv", length = 100, nullable = false, unique = true)
    private String naziv;
    
    @Column(name = "PIB", length = 50, nullable = false, unique = true)
    private String PIB;
    
    @OneToMany(mappedBy = "distributer", cascade = CascadeType.PERSIST)
    private List<Ponuda> ponude;
    
    @ManyToMany
    @JoinTable(
            name = "ponuda", 
            inverseJoinColumns = @JoinColumn(name = "IdM", referencedColumnName = "Id"),
            joinColumns = @JoinColumn(name = "IdD", referencedColumnName = "Id")
    )
    private List<Materijal> materijaliPonudjeni;
    
    @OneToMany(mappedBy = "distributer", cascade = CascadeType.PERSIST)
    private List<Kupljeno> kupljeno;
    
    @ManyToMany
    @JoinTable(
            name = "kupljeno", 
            inverseJoinColumns = @JoinColumn(name = "IdM", referencedColumnName = "Id"),
            joinColumns = @JoinColumn(name = "IdD", referencedColumnName = "Id")
    )
    private List<Materijal> materijaliKupljeni;

    public Distributer(){
        
    }
    
    public Distributer(String naziv, String PIB) {
        this.naziv = naziv;
        this.PIB = PIB;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getPIB() {
        return PIB;
    }

    public void setPIB(String PIB) {
        this.PIB = PIB;
    }

    public List<Ponuda> getPonude() {
        return ponude;
    }

    public void setPonude(List<Ponuda> ponude) {
        this.ponude = ponude;
    }

    public List<Materijal> getMaterijaliPonudjeni() {
        return materijaliPonudjeni;
    }

    public void setMaterijaliPonudjeni(List<Materijal> materijaliPonudjeni) {
        this.materijaliPonudjeni = materijaliPonudjeni;
    }

    public List<Kupljeno> getKupljeno() {
        return kupljeno;
    }

    public void setKupljeno(List<Kupljeno> kupljeno) {
        this.kupljeno = kupljeno;
    }

    public List<Materijal> getMaterijaliKupljeni() {
        return materijaliKupljeni;
    }

    public void setMaterijaliKupljeni(List<Materijal> materijaliKupljeni) {
        this.materijaliKupljeni = materijaliKupljeni;
    }

    
}
