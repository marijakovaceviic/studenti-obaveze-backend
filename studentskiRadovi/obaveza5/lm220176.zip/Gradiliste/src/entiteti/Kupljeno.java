/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entiteti;

import java.sql.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author stefan
 */
@Entity
@Table(name = "kupljeno")
public class Kupljeno {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private int id;
    
    @Column(name = "Cena", nullable = false)
    private int cena;
    
    @Column(name = "Datum", nullable = false)
    private Date datum;
    
    @Column(name = "Kolicina", nullable = false)
    private int kolicina;
    
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "IdM", nullable = false)
    private Materijal materijal;
    
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "IdD", nullable = false)
    private Distributer distributer;
    
    @OneToMany(mappedBy = "kupljeno")
    private List<Utroseno> utroseno;
    
    @ManyToMany
    @JoinTable(
            name = "utroseno", 
            joinColumns = @JoinColumn(name = "IdK", referencedColumnName = "Id"),
            inverseJoinColumns = @JoinColumn(name = "IdP", referencedColumnName = "Id")
    )
    private List<Projekat> projekti;

    public Kupljeno(){
        
    }

    public Kupljeno(int cena, Date datum, int kolicina, Materijal materijal, Distributer distributer) {
        this.cena = cena;
        this.datum = datum;
        this.kolicina = kolicina;
        this.materijal = materijal;
        this.distributer = distributer;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public int getKolicina() {
        return kolicina;
    }

    public void setKolicina(int kolicina) {
        this.kolicina = kolicina;
    }

    public Materijal getMaterijal() {
        return materijal;
    }

    public void setMaterijal(Materijal materijal) {
        this.materijal = materijal;
    }

    public Distributer getDistributer() {
        return distributer;
    }

    public void setDistributer(Distributer distributer) {
        this.distributer = distributer;
    }

    public List<Utroseno> getUtroseno() {
        return utroseno;
    }

    public void setUtroseno(List<Utroseno> utroseno) {
        this.utroseno = utroseno;
    }

    public List<Projekat> getProjekti() {
        return projekti;
    }

    public void setProjekti(List<Projekat> projekti) {
        this.projekti = projekti;
    }
    
    
}
