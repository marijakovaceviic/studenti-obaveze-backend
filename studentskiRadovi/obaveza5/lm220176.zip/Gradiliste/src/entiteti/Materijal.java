/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entiteti;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author stefan
 */
@Entity
@Table(name = "materijal")
@NamedQuery(name = "materijal",
        query = "SELECT m FROM Materijal as m"
)
public class Materijal {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private int id;
    
    @Column(name = "Naziv", nullable = false, unique = true, length = 50)
    private String naziv;
    
    @OneToMany(mappedBy = "materijal")
    private List<Ponuda> ponude;
    
    @ManyToMany
    @JoinTable(
            name = "ponuda", 
            joinColumns = @JoinColumn(name = "IdM", referencedColumnName = "Id"),
            inverseJoinColumns = @JoinColumn(name = "IdD", referencedColumnName = "Id")
    )
    private List<Distributer> distributeriPonudili;
    
    @OneToMany(mappedBy = "materijal")
    private List<Kupljeno> kupljeno;
    
    @ManyToMany
    @JoinTable(
            name = "ponuda", 
            joinColumns = @JoinColumn(name = "IdM", referencedColumnName = "Id"),
            inverseJoinColumns = @JoinColumn(name = "IdD", referencedColumnName = "Id")
    )
    private List<Distributer> distributeriProdali;

    public Materijal() {
        
    }
    
    public Materijal(String naziv) {
        this.naziv = naziv;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public List<Ponuda> getPonude() {
        return ponude;
    }

    public void setPonude(List<Ponuda> ponude) {
        this.ponude = ponude;
    }

    public List<Distributer> getDistributeriPonudili() {
        return distributeriPonudili;
    }

    public void setDistributeriPonudili(List<Distributer> distributeriPonudili) {
        this.distributeriPonudili = distributeriPonudili;
    }

    public List<Kupljeno> getKupljeno() {
        return kupljeno;
    }

    public void setKupljeno(List<Kupljeno> kupljeno) {
        this.kupljeno = kupljeno;
    }

    public List<Distributer> getDistributeriProdali() {
        return distributeriProdali;
    }

    public void setDistributeriProdali(List<Distributer> distributeriProdali) {
        this.distributeriProdali = distributeriProdali;
    }
    
    
}
