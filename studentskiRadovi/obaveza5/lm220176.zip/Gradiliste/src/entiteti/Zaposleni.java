/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entiteti;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author stefan
 */
@Entity
@Table(name = "zaposleni")
@Inheritance(strategy = InheritanceType.JOINED)
@NamedQuery(name = "sviZaposleni", query = "SELECT z FROM Zaposleni z")
public class Zaposleni {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private int id;
    
    @Column(name = "Ime", nullable = false, length = 50)
    private String ime;
    
    @Column(name = "Prezime", nullable = false, length = 50)
    private String prezime;
    
    @Column(name = "JMBG", nullable = false, unique = true, length = 13)
    private String JMBG;

    public Zaposleni() {
    }

    public Zaposleni(String ime, String prezime, String JMBG) {
        this.ime = ime;
        this.prezime = prezime;
        this.JMBG = JMBG;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getJMBG() {
        return JMBG;
    }

    public void setJMBG(String JMBG) {
        this.JMBG = JMBG;
    }
    
    
}
