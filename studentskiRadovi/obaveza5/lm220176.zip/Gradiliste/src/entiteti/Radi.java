/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entiteti;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

/**
 *
 * @author Stefan
 */
@Entity
public class Radi {
    
    @Id
    @OneToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "IdR", referencedColumnName = "Id")
    private Radnik radnik;
    
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "IdP", referencedColumnName = "Id")
    private Projekat projekat;

    public Radi() {
    }

    public Radi(Radnik radnik, Projekat projekat) {
        this.radnik = radnik;
        this.projekat = projekat;
    }
    
    public Radnik getRadnik() {
        return radnik;
    }

    public void setRadnik(Radnik radnik) {
        this.radnik = radnik;
    }

    public Projekat getProjekat() {
        return projekat;
    }

    public void setProjekat(Projekat projekat) {
        this.projekat = projekat;
    }
    
    
}
