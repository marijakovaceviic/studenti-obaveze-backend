/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entiteti;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author stefan
 */
@Entity
@Table(name = "radnik")
public class Radnik extends Zaposleni{
    @OneToMany(mappedBy = "radnik")
    private List<Radio> radioList;
    
    @ManyToMany
    @JoinTable(
            name = "radio", 
            inverseJoinColumns= @JoinColumn(name = "IdP", referencedColumnName = "Id"),
            joinColumns = @JoinColumn(name = "IdR", referencedColumnName = "Id")
    )
    private List<Projekat> projekti;
    
    @OneToOne(mappedBy = "radnik")
    Radi radi;
    
    @ManyToOne
    @JoinTable(
            name = "radi",
            inverseJoinColumns= @JoinColumn(name = "IdP", referencedColumnName = "Id"),
            joinColumns = @JoinColumn(name = "IdR", referencedColumnName = "Id")
    )
    Projekat projekat;

    public Radnik(){
        
    }
    
    public Radnik(String ime, String prezime, String JMBG) {
        super(ime, prezime, JMBG);
    }

    public List<Radio> getRadiList() {
        return radioList;
    }

    public void setRadiList(List<Radio> radiList) {
        this.radioList = radiList;
    }

    public List<Projekat> getProjekti() {
        return projekti;
    }

    public void setProjekti(List<Projekat> projekti) {
        this.projekti = projekti;
    }
    
    
}
