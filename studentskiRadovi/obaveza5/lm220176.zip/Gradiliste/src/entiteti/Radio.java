/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entiteti;

import idClass.RadioId;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author stefan
 */
@Entity
@Table(name = "radio")
@IdClass(RadioId.class)
public class Radio {
    
    @Id
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "IdP", referencedColumnName = "Id")
    private Projekat projekat;
    
    @Id
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "IdR", referencedColumnName = "Id")
    private Radnik radnik;
    
    @OneToMany(mappedBy = "radio")
    List<Ocena> ocene;

    public Radio() {
    }

    public Radio(Projekat projekat, Radnik radnik) {
        this.projekat = projekat;
        this.radnik = radnik;
    }

    public Projekat getProjekat() {
        return projekat;
    }

    public void setProjekat(Projekat projekat) {
        this.projekat = projekat;
    }

    public Radnik getRadnik() {
        return radnik;
    }

    public void setRadnik(Radnik radnik) {
        this.radnik = radnik;
    }

    public List<Ocena> getOcene() {
        return ocene;
    }

    public void setOcene(List<Ocena> ocene) {
        this.ocene = ocene;
    }
    
    
}
