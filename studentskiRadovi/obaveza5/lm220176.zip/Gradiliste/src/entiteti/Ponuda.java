/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entiteti;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author stefan
 */
@Entity
@Table(name = "ponuda")
public class Ponuda {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private int id;
    
    @Column(name = "Cena", nullable = false)
    private int cena;
    
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "IdM", nullable = false)
    Materijal materijal;
    
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "IdD", nullable = false)
    Distributer distributer;

    public Ponuda(){
        
    }

    public Ponuda(int cena) {
        this.cena = cena;
    }

    public Ponuda(int cena, Materijal materijal, Distributer distributer) {
        this.cena = cena;
        this.materijal = materijal;
        this.distributer = distributer;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }

    public Materijal getMaterijal() {
        return materijal;
    }

    public void setMaterijal(Materijal materijal) {
        this.materijal = materijal;
    }

    public Distributer getDistributer() {
        return distributer;
    }

    public void setDistributer(Distributer distributer) {
        this.distributer = distributer;
    }
    
    
}
