/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entiteti;

import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author stefan
 */
@Entity
@Table(name = "utroseno")
public class Utroseno {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private int id;
    
    @Column(name = "Kolicina", nullable = false)
    private int kolicina;
    
    @Column(name = "Datum", nullable = false)
    private Date datum;
    
    @ManyToOne
    @JoinColumn(name = "IdK", referencedColumnName = "Id", nullable = false)
    private Kupljeno kupljeno;
    
    @ManyToOne
    @JoinColumn(name = "IdP", referencedColumnName = "Id", nullable = false)
    private Projekat projekat;

    public Utroseno() {
    }

    public Utroseno(int kolicina, Date datum, Kupljeno kupljeno, Projekat projekat) {
        this.kolicina = kolicina;
        this.datum = datum;
        this.kupljeno = kupljeno;
        this.projekat = projekat;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getKolicina() {
        return kolicina;
    }

    public void setKolicina(int kolicina) {
        this.kolicina = kolicina;
    }

    public Date getDate() {
        return datum;
    }

    public void setDate(Date date) {
        this.datum = date;
    }

    public Kupljeno getKupljeno() {
        return kupljeno;
    }

    public void setKupljeno(Kupljeno kupljeno) {
        this.kupljeno = kupljeno;
    }

    public Projekat getProjekat() {
        return projekat;
    }

    public void setProjekat(Projekat projekat) {
        this.projekat = projekat;
    }
    
    
}
