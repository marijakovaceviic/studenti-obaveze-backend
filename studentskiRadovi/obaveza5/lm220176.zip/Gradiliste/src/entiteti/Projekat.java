/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entiteti;

import java.sql.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author stefan
 */
@Entity
@Table(name = "projekat")
public class Projekat {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private int id;
    
    @Column(name = "Naziv", nullable = false, unique = true, length=50)
    private String naziv;
    
    @Column(name = "DatumZavrsetka", nullable = false)
    private Date datumZavrsetka;
    
    @ManyToOne
    @JoinColumn(name = "IdP", nullable = false)
    Projektant projektant;
    
    @OneToMany(mappedBy = "projekat")
    private List<Utroseno> utroseno;
    
    @ManyToMany
    @JoinTable(
            name = "utroseno", 
            inverseJoinColumns = @JoinColumn(name = "IdK", referencedColumnName = "Id"),
            joinColumns = @JoinColumn(name = "IdP", referencedColumnName = "Id")
    )
    private List<Kupljeno> kupljeno;
    
    @OneToMany(mappedBy = "projekat")
    private List<Radio> radioList;
    
    @ManyToMany
    @JoinTable(
            name = "radio", 
            joinColumns = @JoinColumn(name = "IdP", referencedColumnName = "Id"),
            inverseJoinColumns = @JoinColumn(name = "IdR", referencedColumnName = "Id")
    )
    private List<Radnik> radniciRadili;
    
    @OneToMany(mappedBy = "projekat")
    private List<Radi> radiList;
    
    @OneToMany
    @JoinTable(
            name = "radi",
            joinColumns = @JoinColumn(name = "IdP", referencedColumnName = "Id"),
            inverseJoinColumns = @JoinColumn(name = "IdR", referencedColumnName = "Id")
    )
    private List<Radnik> radniciRade;
    
    public Projekat(){
        
    }

    public Projekat(String naziv, Date datumZavrsetka, Projektant projektant) {
        this.naziv = naziv;
        this.datumZavrsetka = datumZavrsetka;
        this.projektant = projektant;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public Date getDatumZavrsetka() {
        return datumZavrsetka;
    }

    public void setDatumZavrsetka(Date datumZavrsetka) {
        this.datumZavrsetka = datumZavrsetka;
    }

    public Projektant getProjektant() {
        return projektant;
    }

    public void setProjektant(Projektant projektant) {
        this.projektant = projektant;
    }

    public List<Utroseno> getUtroseno() {
        return utroseno;
    }

    public void setUtroseno(List<Utroseno> utroseno) {
        this.utroseno = utroseno;
    }

    public List<Kupljeno> getKupljeno() {
        return kupljeno;
    }

    public void setKupljeno(List<Kupljeno> kupljeno) {
        this.kupljeno = kupljeno;
    }

    public List<Radio> getRadiList() {
        return radioList;
    }

    public void setRadiList(List<Radio> radiList) {
        this.radioList = radiList;
    }

    public List<Radnik> getRadnici() {
        return radniciRadili;
    }

    public void setRadnici(List<Radnik> radnici) {
        this.radniciRadili = radnici;
    }
    
    
}
