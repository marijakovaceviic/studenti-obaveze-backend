package com.example.backend.db;

import java.util.List;

import com.example.backend.modeli.Rezervacija;

public interface RezervacijeRepoInterface {
    
    public int novaRezervacija(Rezervacija r);

    public int slobodanStoUIntervalu(Rezervacija r);

    public int rezervacijeUPoslednjih24h();

    public int rezervacijeUPoslednjih7dana();

    public int rezervacijeUPoslednjihMesecDana();

    public List<Rezervacija> neobradjeneRezervacije(String restoran);

    public int postaviStatus(int id, String status, String konobar, String komentar, int dodeljen_sto, int rb_stola);

    public List<Rezervacija> aktuelneRezervacije(String gost);

    public List<Rezervacija> istekleRezervacije(String gost);

    public List<Rezervacija> zaduzenjeKonobara(String konobar);

    public int gostDosao(Rezervacija r);

    public List<String> daniZaKonobara(String konobar);

    //broj gostiju za konobara za odredjeni dan
    public int brojGostijuZaKonobara(String konobar, String datum);

    // ukupan broj gostiju za konobara 
    public int ukupanBrojGostijuZaKonobara(String konobar);

    public double prosecanBrojRezervacijaPoDanu(String restoran, int danUNedelji);

    public List<Integer> zauzetiStolovi(Rezervacija r);

    
}
