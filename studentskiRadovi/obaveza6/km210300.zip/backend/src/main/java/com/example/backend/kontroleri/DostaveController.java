package com.example.backend.kontroleri;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.backend.db.DostaveRepo;
import com.example.backend.modeli.Dostava;

@RestController
@RequestMapping("/dostave")
@CrossOrigin(origins = "http://localhost:4200")
public class DostaveController {
    
    @PostMapping("/nova")
    public int novaDostava(@RequestBody Dostava d){
        return new DostaveRepo().novaDostava(d);
    }

    @GetMapping("/trenutne/{restoran}")
    public List<Dostava> trenutne(@PathVariable String restoran){
        return new DostaveRepo().trenutneNarudzbine(restoran);
    }

    @PostMapping("/potvrdiIliOdbaci")
    public int postaviStatus(@RequestBody Dostava d){
        return new DostaveRepo().potvrdiIliOdbaci(d);
    }

    @PostMapping("/postaviVremeDostave")
    public int postaviVremeDostave(@RequestBody Dostava d){
        return new DostaveRepo().postaviVremeDostave(d);
    }

    @GetMapping("/zaGosta/{gost}")
    public List<Dostava> dostaveGosta(@PathVariable String gost){
        return new DostaveRepo().dostaveZaGosta(gost);
    }
}
