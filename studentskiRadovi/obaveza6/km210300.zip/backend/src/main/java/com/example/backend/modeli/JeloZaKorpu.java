package com.example.backend.modeli;

public class JeloZaKorpu {
    private String gost;
    private String restoran;
    private String naziv_jela;
    private int kolicina;
    private double cena;
    
    public JeloZaKorpu(String gost, String restoran, String naziv_jela, int kolicina, double cena) {
        this.gost = gost;
        this.restoran = restoran;
        this.naziv_jela = naziv_jela;
        this.kolicina = kolicina;
        this.cena = cena;
    }
    public String getGost() {
        return gost;
    }
    public void setGost(String gost) {
        this.gost = gost;
    }
    public String getRestoran() {
        return restoran;
    }
    public void setRestoran(String restoran) {
        this.restoran = restoran;
    }
    public String getNaziv_jela() {
        return naziv_jela;
    }
    public void setNaziv_jela(String naziv_jela) {
        this.naziv_jela = naziv_jela;
    }
    public int getKolicina() {
        return kolicina;
    }
    public void setKolicina(int kolicina) {
        this.kolicina = kolicina;
    }
    public double getCena() {
        return cena;
    }
    public void setCena(double cena) {
        this.cena = cena;
    }

    
}
