package com.example.backend.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.example.backend.modeli.Rezervacija;


public class RezervacijeRepo implements RezervacijeRepoInterface {


    //@Override
    public int novaRezervacija(Rezervacija r) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "insert into rezervacije(restoran,gost,datum,broj_osoba,opis,status,kom_konobar,kom_gost,ocena,vreme_rezervacije,dosao) values(?,?,?,?,?,?,?,?,?,?,?)")) {
            
            stmt.setString(1, r.getRestoran());
            stmt.setString(2, r.getGost());
            stmt.setTimestamp(3, java.sql.Timestamp.valueOf(r.getDatum()));
            stmt.setInt(4, r.getBroj_osoba());
            stmt.setString(5, r.getOpis());
            stmt.setString(6, r.getStatus());
            stmt.setString(7, " ");
            stmt.setString(8, " ");
            stmt.setInt(9, 0);
            LocalDateTime d = LocalDateTime.now();
            stmt.setTimestamp(10, java.sql.Timestamp.valueOf(d));
            stmt.setString(11, "");
    
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public int slobodanStoUIntervalu(Rezervacija r) {
        int brojStolova = 0;
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select count(*) as broj from raspored where restoran = ? and brOsoba >= ?")) {

            stmt.setString(1, r.getRestoran());
            stmt.setInt(2, r.getBroj_osoba());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                brojStolova = rs.getInt("broj");    
               
               try(PreparedStatement stm1 = conn.prepareStatement(
                "select count(*) as zauzeto from rezervacije where broj_osoba >= ? and restoran = ? and datum > ? and datum < ?"
               )){
                    stm1.setInt(1, r.getBroj_osoba());
                    stm1.setString(2, r.getRestoran());
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                    LocalDateTime pocetak = LocalDateTime.parse(r.getDatum(), formatter);
                    LocalDateTime pocetakIntervala = pocetak.minusHours(3); 
                    LocalDateTime krajIntervala = pocetak.plusHours(3);
                    stm1.setTimestamp(3, java.sql.Timestamp.valueOf(pocetakIntervala));
                    stm1.setTimestamp(4, java.sql.Timestamp.valueOf(krajIntervala));

                    ResultSet rs1 = stm1.executeQuery();
                    if (rs1.next()){
                        brojStolova = brojStolova - rs1.getInt("zauzeto");
                    }
               }

            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (brojStolova > 1){
            return brojStolova;
        }
        else{
            return 0;
        }
    }

    @Override
    public int rezervacijeUPoslednjih24h() {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select count(*) as broj from rezervacije where vreme_rezervacije >= NOW() - INTERVAL 24 HOUR and vreme_rezervacije <= NOW()")) {
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()){
                return rs.getInt("broj");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }


    @Override
    public int rezervacijeUPoslednjih7dana() {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select count(*) as broj from rezervacije where vreme_rezervacije >= NOW() - INTERVAL 7 DAY and vreme_rezervacije <= NOW()")) {
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()){
                return rs.getInt("broj");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }
    
    
    @Override
    public int rezervacijeUPoslednjihMesecDana() {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select count(*) as broj from rezervacije where vreme_rezervacije >= NOW() - INTERVAL 1 MONTH and vreme_rezervacije <= NOW()")) {
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()){
                return rs.getInt("broj");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }


   // @Override
    public List<Rezervacija> neobradjeneRezervacije(String restoran) {
        List<Rezervacija> trenutne = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from rezervacije where status = 'u obradi' and restoran = ? order by datum")) {

            stmt.setString(1, restoran);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Rezervacija r = new Rezervacija(
                    rs.getInt("id"),
                    rs.getString("restoran"),
                    rs.getString("gost"),
                    rs.getTimestamp("datum").toString(),
                    rs.getInt("broj_osoba"),
                    rs.getString("opis"),
                    rs.getString("status")   
                );
                r.setKom_konobar(rs.getString("kom_konobar"));
                trenutne.add(r);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return trenutne;
    }

    @Override
    public int postaviStatus(int id, String status, String konobar, String komentar, int dodeljen_sto, int rb_stola) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "update rezervacije set status = ?, konobar = ?, kom_konobar = ?, dodeljen_sto = ?, rb_stola = ? where id = ?")) {
            
            stmt.setString(1, status);
            stmt.setString(2, konobar);
            stmt.setString(3, komentar);
            stmt.setInt(4, dodeljen_sto);
            stmt.setInt(5, rb_stola);
            stmt.setInt(6, id);
    
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public List<Rezervacija> aktuelneRezervacije(String gost) {
        List<Rezervacija> aktuelne = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from rezervacije where status = 'prihvaceno' and datum >= NOW() and gost = ? order by datum")) {

            stmt.setString(1, gost);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Rezervacija r = new Rezervacija(
                    rs.getInt("id"),
                    rs.getString("restoran"),
                    rs.getString("gost"),
                    rs.getTimestamp("datum").toString(),
                    rs.getInt("broj_osoba"),
                    rs.getString("opis"),
                    rs.getString("status")   
                );
                
                aktuelne.add(r);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return aktuelne;
    }

    @Override
    public List<Rezervacija> istekleRezervacije(String gost) {
        List<Rezervacija> istekle = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from rezervacije where status = 'prihvaceno' and datum < NOW() and gost = ? order by datum desc")) {

            stmt.setString(1, gost);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Rezervacija r = new Rezervacija(
                    rs.getInt("id"),
                    rs.getString("restoran"),
                    rs.getString("gost"),
                    rs.getTimestamp("datum").toString(),
                    rs.getInt("broj_osoba"),
                    rs.getString("opis"),
                    rs.getString("status")   
                );
                r.setKom_gost(rs.getString("kom_gost"));
                r.setOcena(rs.getInt("ocena"));
                istekle.add(r);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return istekle;
    }

    @Override
    public List<Rezervacija> zaduzenjeKonobara(String konobar) {
        List<Rezervacija> rezervacije = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from rezervacije where status = 'prihvaceno' and konobar = ? order by datum")) {

            stmt.setString(1, konobar);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Rezervacija r = new Rezervacija(
                    rs.getInt("id"),
                    rs.getString("restoran"),
                    rs.getString("gost"),
                    rs.getTimestamp("datum").toString(),
                    rs.getInt("broj_osoba"),
                    rs.getString("opis"),
                    rs.getString("status")   
                );
                r.setKonobar(rs.getString("konobar"));
                r.setDosao(rs.getString("dosao"));
                rezervacije.add(r);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rezervacije;
    }

    @Override
    public int gostDosao(Rezervacija r) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "update rezervacije set dosao = ? where id = ?")) {
            
            stmt.setString(1, r.getDosao());
            stmt.setInt(2, r.getId());
    
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public List<String> daniZaKonobara(String konobar) {
        List<String> datumi = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select distinct DATE(datum) as d from rezervacije where konobar = ? and status = 'prihvaceno' and dosao != 'ne' order by datum")) {

            stmt.setString(1, konobar);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                datumi.add( rs.getTimestamp("d").toString());
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return datumi;
    }

    @Override
    public int brojGostijuZaKonobara(String konobar, String datum) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select count(*) as broj from rezervacije where konobar = ? and DATE(datum) = ? and status = 'prihvaceno' and dosao != 'ne' order by datum")) {

            stmt.setString(1, konobar);
            stmt.setString(2, datum);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
               return rs.getInt("broj");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public int ukupanBrojGostijuZaKonobara(String konobar) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select count(*) as broj from rezervacije where konobar = ? and status = 'prihvaceno' and dosao != 'ne'")) {

            stmt.setString(1, konobar);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
               return rs.getInt("broj");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public double prosecanBrojRezervacijaPoDanu(String restoran, int danUNedelji) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
            "SELECT COUNT(*) AS broj " +
            "FROM rezervacije " +
            "WHERE datum >= NOW() - INTERVAL 24 MONTH  and datum <= NOW()" +
            "AND WEEKDAY(datum) = ? " +
            "AND restoran = ? ")) {

            stmt.setInt(1, danUNedelji);
            stmt.setString(2, restoran);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
               return rs.getInt("broj");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public List<Integer> zauzetiStolovi(Rezervacija r) {
        List<Integer> zauzeti = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select rb_stola from rezervacije where restoran = ? and datum > ? and datum < ? and rb_stola != 0")) {

            stmt.setString(1, r.getRestoran());
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss[.S]");
            LocalDateTime pocetak = LocalDateTime.parse(r.getDatum(), formatter);
            LocalDateTime pocetakIntervala = pocetak.minusHours(3); 
            LocalDateTime krajIntervala = pocetak.plusHours(3);
            stmt.setTimestamp(2, java.sql.Timestamp.valueOf(pocetakIntervala));
            stmt.setTimestamp(3, java.sql.Timestamp.valueOf(krajIntervala));

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                zauzeti.add( rs.getInt("rb_stola"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return zauzeti;
    }



   

    
    
}
