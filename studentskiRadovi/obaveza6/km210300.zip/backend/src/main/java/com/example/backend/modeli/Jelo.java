package com.example.backend.modeli;

public class Jelo {
    
    private String restoran;
    private String naziv;
    private String slika;
    private double cena;
    private String sastojci;
    
    public Jelo(String restoran, String naziv, String slika, double cena, String sastojci) {
        this.restoran = restoran;
        this.naziv = naziv;
        this.slika = slika;
        this.cena = cena;
        this.sastojci = sastojci;
    }
    public String getRestoran() {
        return restoran;
    }
    public void setRestoran(String restoran) {
        this.restoran = restoran;
    }
    public String getNaziv() {
        return naziv;
    }
    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }
    public String getSlika() {
        return slika;
    }
    public void setSlika(String slika) {
        this.slika = slika;
    }
    public double getCena() {
        return cena;
    }
    public void setCena(double cena) {
        this.cena = cena;
    }
    public String getSastojci() {
        return sastojci;
    }
    public void setSastojci(String sastojci) {
        this.sastojci = sastojci;
    }

    
}
