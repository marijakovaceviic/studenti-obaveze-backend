package com.example.backend.modeli;

public class RadnoVreme {
    private String naziv;
    private String dan;
    private String radi_od;
    private String radi_do;
    
    public RadnoVreme(String naziv, String dan, String radi_od, String radi_do) {
        this.naziv = naziv;
        this.dan = dan;
        this.radi_od = radi_od;
        this.radi_do = radi_do;
    }
    public String getNaziv() {
        return naziv;
    }
    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }
    public String getDan() {
        return dan;
    }
    public void setDan(String dan) {
        this.dan = dan;
    }
    public String getRadi_od() {
        return radi_od;
    }
    public void setRadi_od(String radi_od) {
        this.radi_od = radi_od;
    }
    public String getRadi_do() {
        return radi_do;
    }
    public void setRadi_do(String radi_do) {
        this.radi_do = radi_do;
    }
    
}
