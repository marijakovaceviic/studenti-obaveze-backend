package com.example.backend.modeli;

public class Zaposlen {
    
    private String restoran;
    private String korisnicko_ime;
    
    
    public Zaposlen(String restoran, String korisnicko_ime) {
        this.restoran = restoran;
        this.korisnicko_ime = korisnicko_ime;
    }

    public String getRestoran() {
        return restoran;
    }

    public void setRestoran(String restoran) {
        this.restoran = restoran;
    }

    public String getKorisnicko_ime() {
        return korisnicko_ime;
    }

    public void setKorisnicko_ime(String korisnicko_ime) {
        this.korisnicko_ime = korisnicko_ime;
    }

    
}
