package com.example.backend.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.backend.modeli.JeloZaKorpu;

public class KorpaRepo implements KorpaRepoInterface {

    @Override
    public int dodajUKorpu(JeloZaKorpu jelo) {
        
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
            "select * from korpa where gost =? and restoran = ? and naziv_jela = ?");){

            stmt.setString(1, jelo.getGost());
            stmt.setString(2, jelo.getRestoran());
            stmt.setString(3, jelo.getNaziv_jela());  
            ResultSet rs = stmt.executeQuery();

            if (rs.next()){
                try(PreparedStatement stm1 = conn.prepareStatement(
                    "update korpa set kolicina = kolicina + ? where gost = ? and restoran = ? and naziv_jela = ?")){
                    
                    stm1.setInt(1, jelo.getKolicina());
                    stm1.setString(2, jelo.getGost());
                    stm1.setString(3, jelo.getRestoran());
                    stm1.setString(4, jelo.getNaziv_jela());
                    return stm1.executeUpdate();
                    }
            }
            else{
                try(PreparedStatement stm2 = conn.prepareStatement(
                    "insert into korpa(gost,restoran,naziv_jela,kolicina,cena) values(?,?,?,?,?)");) {
                    
                    stm2.setString(1, jelo.getGost());
                    stm2.setString(2, jelo.getRestoran());
                    stm2.setString(3, jelo.getNaziv_jela());
                    stm2.setInt(4, jelo.getKolicina());
                    stm2.setDouble(5, jelo.getCena());
        
                    return stm2.executeUpdate();
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public List<JeloZaKorpu> dohvatiSadrzaj(String gost, String restoran) {
         List<JeloZaKorpu> korpa = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from korpa where gost = ? and restoran = ?")) {

            stmt.setString(1, gost);
            stmt.setString(2, restoran);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                JeloZaKorpu j = new JeloZaKorpu(
                        rs.getString("gost"),
                        rs.getString("restoran"),
                        rs.getString("naziv_jela"),
                        rs.getInt("kolicina"),
                        rs.getDouble("cena")
                        );
                korpa.add(j);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return korpa;
    }

    @Override
    public int izmenaKorpe(String gost, String restoran, String naziv_jela, int kolicina) {
        if(kolicina != 0){
            try (Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement(
             "update korpa set kolicina = ? where gost = ? and restoran = ? and naziv_jela = ?");) {

            stmt.setInt(1, kolicina);
            stmt.setString(2, gost);
            stmt.setString(3, restoran);
            stmt.setString(4, naziv_jela);

           return stmt.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return 0;    
        }
        else{
            try (Connection conn = DB.source().getConnection();
            PreparedStatement stmt = conn.prepareStatement(
             "delete from korpa where gost = ? and restoran = ? and naziv_jela = ?");) {

            stmt.setString(1, gost);
            stmt.setString(2, restoran);
            stmt.setString(3, naziv_jela);

           return stmt.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return 0;    
        }
        
    }


    @Override
    public double potvrdaPorudzbine(String gost, String restoran) {
        double iznos = 0;
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select sum(kolicina * cena) as ukupnaCena from korpa where gost = ? and restoran = ?")) {

            stmt.setString(1, gost);
            stmt.setString(2, restoran);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                iznos = rs.getDouble("ukupnaCena");
                
                try(PreparedStatement stmt1 = conn.prepareStatement(
                    "delete from korpa where gost = ? and restoran = ?")) {
            
                    stmt1.setString(1, gost);
                    stmt1.setString(2, restoran);
    
                    stmt1.executeUpdate();
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return iznos;
    }
    
}
