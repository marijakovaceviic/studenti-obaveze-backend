package com.example.backend.db;

import java.util.List;

import com.example.backend.modeli.Jelo;
import com.example.backend.modeli.Korisnik;
import com.example.backend.modeli.Raspored;
import com.example.backend.modeli.Restoran;
import com.example.backend.modeli.Zaposlen;

public interface RestoraniRepoInterface {
    
    public int brojRestorana();

    public List<Restoran> sviRestorani();

    public int dodavanjeRestorana(String naziv, String adresa, String tip, String opis, String telefon);

    public Restoran dohvatiRestoran(String naziv);

    public int dodajKonobara(Zaposlen zaposlen);

    public Restoran restoranUKomeRadi(String konobar);

    public List<Korisnik> zaposleniURestoranu(String restoran);

    public int dodajRadnoVreme(String restoran, String radi_od, String radi_do, String dan);

    public List<String> dohvatiRadnoVreme(String restoran, String dan);

    public int dodajElementRasporeda(Raspored raspored);

    public List<Raspored> dohvatiRaspored(String restoran);

    public int dodavanjeJela(Jelo jelo);

    public int postavljanjeSlikeJela(String restoran,String naziv,String putanja);
}
