package com.example.backend.kontroleri;

import java.io.File;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.backend.db.KorisniciRepo;
import com.example.backend.modeli.Korisnik;

@RestController
@RequestMapping("/korisnici")
@CrossOrigin(origins = "http://localhost:4200")
public class KorisniciController {
    
    @PostMapping("/prijava")
    public Korisnik prijava(@RequestBody Korisnik korisnik) {
        return new KorisniciRepo().prijava(korisnik);
    }

    @PostMapping("/promenaLozinke")
    public int promena(@RequestBody Korisnik korisnik){
        return new KorisniciRepo().promenaLozinke(korisnik);
    }

    @GetMapping("/brojRegistrovanihGostiju")
    public int brojKorisnika(){
        return new KorisniciRepo().brojRegistrovanihGostiju();
    }

    @PostMapping("/registracijaGosta")
    public int registracija(@RequestBody Korisnik k){
        return new KorisniciRepo().registracija(k);
    }

    @PostMapping("/dodavanjeProfilneSlike/{korIme}")
    public int dodavanjeProfilne(@RequestParam("slika") MultipartFile slika, @PathVariable String korIme){
        try {
            String putanja = "D:/pia/projekat/frontend/src/assets/" + slika.getOriginalFilename();
            File finalno = new File(putanja);
            slika.transferTo(finalno);
          
           return new KorisniciRepo().dodavanjeProfilne(korIme,slika.getOriginalFilename());
   
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;

    }

    @GetMapping("/podrazumevanaProfilna/{korIme}")
    public int podrazumevanaProfilna(@PathVariable String korIme){
       
       String putanja = "default.jpg";
        return new KorisniciRepo().dodavanjeProfilne(korIme, putanja);
    }

    @GetMapping("/promenaImena/{ime}/{korIme}")
    public int promenaImena(@PathVariable String ime, @PathVariable String korIme){
        return new KorisniciRepo().azuriranjeImena(ime, korIme);
    }

    @GetMapping("/promenaPrezimena/{prezime}/{korIme}")
    public int promenaPrezimena(@PathVariable String prezime, @PathVariable String korIme){
        return new KorisniciRepo().azurirajPrezime(prezime, korIme);
    }

    @GetMapping("/promenaAdrese/{adresa}/{korIme}")
    public int promenaAdrese(@PathVariable String adresa, @PathVariable String korIme){
        return new KorisniciRepo().azurirajAdresu(adresa, korIme);
    }

    @GetMapping("/promenaEmaila/{email}/{korIme}")
    public int promenaEmaila(@PathVariable String email, @PathVariable String korIme){
        return new KorisniciRepo().azurirajEmail(email, korIme);
    }

    @GetMapping("/promenaTelefona/{telefon}/{korIme}")
    public int promenaTelefona(@PathVariable String telefon, @PathVariable String korIme){
        return new KorisniciRepo().azurirajTelefon(telefon, korIme);
    }

    @PostMapping("/promenaProfilneSlike/{korIme}")
    public int promenaProfilne(@RequestParam("slika") MultipartFile slika, @PathVariable String korIme){
        try {
            String putanja = "D:/pia/projekat/frontend/src/assets/" + slika.getOriginalFilename();
            File finalno = new File(putanja);
            slika.transferTo(finalno);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new KorisniciRepo().promenaProfilne(korIme, slika.getOriginalFilename());
    }

    @GetMapping("/sviKorisnici")
    public List<Korisnik> sviKorisnici(){
        return new KorisniciRepo().sviKorisnici();
    }

    @GetMapping("/sviZahtevi")
    public List<Korisnik> sviZahtevi(){
        return new KorisniciRepo().sviZahtevi();
    }

    @PostMapping("/dodavanjeGosta")
    public int dodavanjeGosta(@RequestBody Korisnik k){
        return new KorisniciRepo().dodajKorisnika(k);
    }

    @GetMapping("/uklanjanjeZahteva/{korIme}")
    public int ukloniZahtev(@PathVariable String korIme){
        return new KorisniciRepo().ukloniZahtev(korIme);
    }

    @GetMapping("/zapamtiOdbijene/{korIme}/{email}")
    public int odbijeni(@PathVariable String korIme, @PathVariable String email){
        return new KorisniciRepo().zapamtiOdbijene(korIme, email);
    }

    @GetMapping("/dohvatiKorisnika/{korIme}")
    public Korisnik dohvatiKorisnika(@PathVariable String korIme){
        return new KorisniciRepo().dohvatiKorisnika(korIme);
    }

    @PostMapping("/dodavanjeProfilneSlikeKonobar/{korIme}")
    public int dodavanjeProfilneKonobar(@RequestParam("slika") MultipartFile slika, @PathVariable String korIme){
        try {
            String putanja = "D:/pia/projekat/frontend/src/assets/" + slika.getOriginalFilename();
            File finalno = new File(putanja);
            slika.transferTo(finalno);
      
           return new KorisniciRepo().dodavanjeProfilneKonobar(korIme,slika.getOriginalFilename());
   
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;

    }

    @GetMapping("/podrazumevanaProfilnaKonobar/{korIme}")
    public int podrazumevanaProfilnaKonobar(@PathVariable String korIme){
        
       String putanja = "default.jpg";
        return new KorisniciRepo().dodavanjeProfilneKonobar(korIme, putanja);
    }

    @PostMapping("/azuriranjePodataka")
    public int azuriranjePodataka(@RequestBody Korisnik k){
        return new KorisniciRepo().azuriranjePodataka(k);
    }

    @GetMapping("/odbijenaKorImena")
    public List<String> odbijenaKorImena(){
        return new KorisniciRepo().odbijenaKorImena();
    }

    @GetMapping("/odbijeniEmailovi")
    public List<String> odijeniEmailovi(){
        return new KorisniciRepo().odbijeniEmailovi();
    }
}
