package com.example.backend.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.example.backend.modeli.Jelo;
import com.example.backend.modeli.Korisnik;
import com.example.backend.modeli.Raspored;
import com.example.backend.modeli.Restoran;
import com.example.backend.modeli.Zaposlen;

public class RestoraniRepo implements RestoraniRepoInterface{

    @Override
    public int brojRestorana() {
       try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select count(*) as broj from restorani")) {

            ResultSet rs = stmt.executeQuery();
            if (rs.next()){
                return rs.getInt("broj");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public List<Restoran> sviRestorani() {
        List<Restoran> restorani = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from restorani")) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Restoran r = new Restoran(
                        rs.getInt("id"),
                        rs.getString("naziv"),
                        rs.getString("adresa"),
                        rs.getString("tip")
                        );
                        r.setOpis(rs.getString("opis"));
                        r.setTelefon(rs.getString("telefon"));
                restorani.add(r);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return restorani;
    }

    @Override
    public int dodavanjeRestorana(String naziv, String adresa, String tip, String opis, String telefon) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "insert into restorani(naziv,adresa,tip,opis,telefon) values(?,?,?,?,?)")) {
            
            stmt.setString(1, naziv);
            stmt.setString(2, adresa);
            stmt.setString(3, tip);
            stmt.setString(4, opis);
            stmt.setString(5, telefon);
    
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public Restoran dohvatiRestoran(String naziv) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from restorani where naziv = ?")) {

            stmt.setString(1, naziv);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Restoran r = new Restoran(
                        rs.getInt("id"),
                        rs.getString("naziv"),
                        rs.getString("adresa"),
                        rs.getString("tip")
                        );
                        r.setOpis(rs.getString("opis"));
                        r.setTelefon(rs.getString("telefon"));  
                        return r; 
            }
            

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public int dodajKonobara(Zaposlen zaposlen) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "insert into zaposleni(restoran,korisnicko_ime) values(?,?)")) {
            
            stmt.setString(1, zaposlen.getRestoran());
            stmt.setString(2, zaposlen.getKorisnicko_ime());
        
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public Restoran restoranUKomeRadi(String konobar) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from restorani r join zaposleni z on r.naziv = z.restoran where z.korisnicko_ime = ?")) {

            stmt.setString(1, konobar);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Restoran r = new Restoran(
                        rs.getInt("id"),
                        rs.getString("naziv"),
                        rs.getString("adresa"),
                        rs.getString("tip")
                        );
                        r.setOpis(rs.getString("opis"));
                        r.setTelefon(rs.getString("telefon"));  
                        return r; 
            }
            

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public List<Korisnik> zaposleniURestoranu(String restoran) {
        List<Korisnik> konobari = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from zaposleni z join korisnici k using (korisnicko_ime) where z.restoran = ? ")) {

            stmt.setString(1, restoran);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Korisnik k = new Korisnik(
                        rs.getString("korisnicko_ime"),
                        rs.getString("lozinka"),
                        rs.getString("tip"),
                        rs.getString("ime"),
                        rs.getString("prezime"),
                        rs.getString("pol"),
                        rs.getString("adresa"),
                        rs.getString("telefon"),
                        rs.getString("email"),
                        rs.getString("slika"),
                        rs.getString("broj_kartice"));
                konobari.add(k);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return konobari;
    }

    @Override
    public int dodajRadnoVreme(String restoran, String radi_od, String radi_do, String dan) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "insert into radno_vreme(restoran,od,do,dan) values(?,?,?,?)")) {

            LocalTime radiOdTime = LocalTime.parse(radi_od);
            LocalTime radiDoTime = LocalTime.parse(radi_do);
            
            stmt.setString(1, restoran);
            stmt.setTime(2, java.sql.Time.valueOf(radiOdTime));
            stmt.setTime(3, java.sql.Time.valueOf(radiDoTime));
            stmt.setString(4, dan);

            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public int dodajElementRasporeda(Raspored raspored) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "insert into raspored(restoran,element,x,y,sirina,visina,precnik,brOsoba) values(?,?,?,?,?,?,?,?)")) {
            
            stmt.setString(1, raspored.getRestoran());
            stmt.setString(2, raspored.getElement());
            stmt.setInt(3, raspored.getX());
            stmt.setInt(4, raspored.getY());
            stmt.setInt(5, raspored.getSirina());
            stmt.setInt(6, raspored.getVisina());
            stmt.setInt(7, raspored.getPrecnik());
            stmt.setInt(8, raspored.getBrOsoba());

            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

   // @Override
    public List<Raspored> dohvatiRaspored(String restoran) {
        List<Raspored> elementi = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from raspored where restoran = ? ")) {

            stmt.setString(1, restoran);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Raspored elem = new Raspored(
                        rs.getString("restoran"),
                        rs.getString("element"),
                        rs.getInt("x"),
                        rs.getInt("y"),
                        rs.getInt("sirina"),
                        rs.getInt("visina"),
                        rs.getInt("precnik"),
                        rs.getInt("brOsoba")
                );
                elementi.add(elem);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return elementi;
    }

    @Override
    public List<String> dohvatiRadnoVreme(String restoran, String dan) {
        List<String> radnoVreme = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from radno_vreme where restoran = ? and dan = ?")) {

            stmt.setString(1, restoran);
            stmt.setString(2, dan);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                radnoVreme.add(rs.getString("od"));
                radnoVreme.add(rs.getString("do"));
            }
            

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return radnoVreme;
    }

    @Override
    public int dodavanjeJela(Jelo jelo) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "insert into jela(restoran,naziv,slika,cena,sastojci) values(?,?,?,?,?)")) {
            
            stmt.setString(1, jelo.getRestoran());
            stmt.setString(2, jelo.getNaziv());
            stmt.setString(3, jelo.getSlika());
            stmt.setDouble(4, jelo.getCena());
            stmt.setString(5, jelo.getSastojci());
        
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public int postavljanjeSlikeJela(String restoran, String naziv, String putanja) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "update jela set slika = ? where restoran = ? and naziv = ?");) {

            stmt.setString(1, putanja);
            stmt.setString(2, restoran);
            stmt.setString(3, naziv);

           return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0; 
    }
    
}
