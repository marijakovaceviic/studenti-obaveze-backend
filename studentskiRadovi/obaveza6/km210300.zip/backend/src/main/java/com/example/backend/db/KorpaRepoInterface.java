package com.example.backend.db;

import java.util.List;

import com.example.backend.modeli.JeloZaKorpu;

public interface KorpaRepoInterface {
    
    public int dodajUKorpu(JeloZaKorpu jelo);

    public List<JeloZaKorpu> dohvatiSadrzaj(String gost, String restoran);

    public int izmenaKorpe(String gost, String restoran, String naziv_jela, int kolicina);

    public double potvrdaPorudzbine(String gost, String restoran);
}
