package com.example.backend.modeli;

public class Restoran {
    private int id;
    private String naziv;
    private String adresa;
    private String tip;
    private String opis;
    private String telefon;

   // private String radi_od;
   // private String radi_do;
   
    public Restoran(int id, String naziv, String adresa, String tip) {
        this.id = id;
        this.naziv = naziv;
        this.adresa = adresa;
        this.tip = tip;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }
    
    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

 /*    public String getRadi_od() {
        return radi_od;
    }

    public void setRadi_od(String radi_od) {
        this.radi_od = radi_od;
    }

    public String getRadi_do() {
        return radi_do;
    }

    public void setRadi_do(String radi_do) {
        this.radi_do = radi_do;
    }*/

    
    
}
