package com.example.backend.db;

import java.util.List;

import com.example.backend.modeli.Dostava;

public interface DostaveRepoInterface {
    
    public int novaDostava(Dostava dostava);

    public List<Dostava> trenutneNarudzbine(String restoran);

    public int potvrdiIliOdbaci(Dostava dostava);

    public int postaviVremeDostave(Dostava dostava);

    public List<Dostava> dostaveZaGosta(String gost);
}
