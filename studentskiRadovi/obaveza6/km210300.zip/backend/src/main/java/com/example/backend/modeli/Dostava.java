package com.example.backend.modeli;

import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;
//import org.springframework.format.annotation.DateTimeFormat.ISO;

public class Dostava {

    private String restoran;
    private String gost;
    private double iznos;
    
    //@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private LocalDateTime vreme_narucivanja;

    private String vreme_dostave;
    private String status;
    
    public Dostava(String restoran, String gost, double iznos, LocalDateTime vreme_narucivanja, String vreme_dostave,
            String status) {
        this.restoran = restoran;
        this.gost = gost;
        this.iznos = iznos;
        this.vreme_narucivanja = vreme_narucivanja;
        this.vreme_dostave = vreme_dostave;
        this.status = status;
    }

    public String getRestoran() {
        return restoran;
    }

    public void setRestoran(String restoran) {
        this.restoran = restoran;
    }

    public String getGost() {
        return gost;
    }

    public void setGost(String gost) {
        this.gost = gost;
    }

    public double getIznos() {
        return iznos;
    }

    public void setIznos(double iznos) {
        this.iznos = iznos;
    }

    public LocalDateTime getVreme_narucivanja() {
        return vreme_narucivanja;
    }

    public void setVreme_narucivanja(LocalDateTime vreme_narucivanja) {
        this.vreme_narucivanja = vreme_narucivanja;
    }

    public String getVreme_dostave() {
        return vreme_dostave;
    }

    public void setVreme_dostave(String vreme_dostave) {
        this.vreme_dostave = vreme_dostave;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    

    
}
