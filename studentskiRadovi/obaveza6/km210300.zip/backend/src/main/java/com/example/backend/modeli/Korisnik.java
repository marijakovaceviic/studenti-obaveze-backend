package com.example.backend.modeli;

public class Korisnik {
    private String korisnicko_ime;
    private String lozinka;
    private String tip; 
    private String ime;
    private String prezime;
    private String pol;
    private String adresa;
    private String telefon;
    private String email;
    private String slika;
    private String broj_kartice;
    
    //ipak bez slike?
    public Korisnik(String korisnicko_ime, String lozinka, String tip, String ime, String prezime, String pol,
            String adresa, String telefon, String email, String slika, String broj_kartice) {
        this.korisnicko_ime = korisnicko_ime;
        this.lozinka = lozinka;
        this.tip = tip;
        this.ime = ime;
        this.prezime = prezime;
        this.pol = pol;
        this.adresa = adresa;
        this.telefon = telefon;
        this.email = email;
        this.slika = slika;
        this.broj_kartice = broj_kartice;
    }
    public String getKorisnicko_ime() {
        return korisnicko_ime;
    }
    public void setKorisnicko_ime(String korisnicko_ime) {
        this.korisnicko_ime = korisnicko_ime;
    }
    public String getLozinka() {
        return lozinka;
    }
    public void setLozinka(String lozinka) {
        this.lozinka = lozinka;
    }
    public String getTip() {
        return tip;
    }
    public void setTip(String tip) {
        this.tip = tip;
    }
    public String getIme() {
        return ime;
    }
    public void setIme(String ime) {
        this.ime = ime;
    }
    public String getPrezime() {
        return prezime;
    }
    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }
    public String getPol() {
        return pol;
    }
    public void setPol(String pol) {
        this.pol = pol;
    }
    public String getAdresa() {
        return adresa;
    }
    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }
    public String getTelefon() {
        return telefon;
    }
    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getSlika() {
        return slika;
    }
    public void setSlika(String slika) {
        this.slika = slika;
    }
    public String getBroj_kartice() {
        return broj_kartice;
    }
    public void setBroj_kartice(String broj_kartice) {
        this.broj_kartice = broj_kartice;
    }
    
    
}
