package com.example.backend.kontroleri;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.backend.db.KorpaRepo;
import com.example.backend.modeli.JeloZaKorpu;

@RestController
@RequestMapping("/korpa")
@CrossOrigin(origins = "http://localhost:4200")
public class KorpaController {
    
    @PostMapping("/dodavanje")
    public int dodavanje(@RequestBody JeloZaKorpu jelo) {
        return new KorpaRepo().dodajUKorpu(jelo);
    }

    @GetMapping("/dohvatiSadrzaj/{gost}/{restoran}")
    public List<JeloZaKorpu> dohvatanje(@PathVariable String gost, @PathVariable String restoran){
        return new KorpaRepo().dohvatiSadrzaj(gost, restoran);
    }

    @PostMapping("/izmenaKorpe")
    public int postMethodName(@RequestBody JeloZaKorpu jelo) {
        return new KorpaRepo().izmenaKorpe(jelo.getGost(), jelo.getRestoran(), jelo.getNaziv_jela(), jelo.getKolicina());
    }

    @GetMapping("/potvrdaPorudzbine/{gost}/{restoran}")
    public double potvrda(@PathVariable String gost, @PathVariable String restoran){
        return new KorpaRepo().potvrdaPorudzbine(gost, restoran);
    }
    
}
