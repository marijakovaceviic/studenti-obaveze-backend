package com.example.backend.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.example.backend.modeli.Dostava;

public class DostaveRepo implements DostaveRepoInterface{

    @Override
    public int novaDostava(Dostava dostava) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "insert into dostave(restoran,gost,iznos,vreme_narucivanja,vreme_dostave,status) values(?,?,?,?,?,?)")) {
            
            stmt.setString(1, dostava.getRestoran());
            stmt.setString(2, dostava.getGost());
            stmt.setDouble(3, dostava.getIznos());
            System.out.println(dostava.getVreme_narucivanja());
            LocalDateTime d = LocalDateTime.now();
           stmt.setTimestamp(4, java.sql.Timestamp.valueOf(d));
            stmt.setString(5, "");
            stmt.setString(6, dostava.getStatus());
    
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public List<Dostava> trenutneNarudzbine(String restoran) {
        
        List<Dostava> trenutne = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from dostave where status = 'u obradi' and restoran = ?")) {

            stmt.setString(1, restoran);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Dostava s = new Dostava(
                    rs.getString("restoran"),
                    rs.getString("gost"),
                    rs.getDouble("iznos"),
                    rs.getTimestamp("vreme_narucivanja").toLocalDateTime(),
                    rs.getString("vreme_dostave"),
                    rs.getString("status")   
                );
                trenutne.add(s);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return trenutne;
    }

    @Override
    public int potvrdiIliOdbaci(Dostava dostava) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "update dostave set status = ? where restoran = ? and gost = ? and vreme_narucivanja = ?")) {
            
            stmt.setString(1, dostava.getStatus());
            stmt.setString(2, dostava.getRestoran());
            stmt.setString(3, dostava.getGost());
            stmt.setTimestamp(4, java.sql.Timestamp.valueOf(dostava.getVreme_narucivanja()));
    
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public int postaviVremeDostave(Dostava dostava) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "update dostave set vreme_dostave = ? where restoran = ? and gost = ? and vreme_narucivanja = ?")) {
            
            stmt.setString(1, dostava.getVreme_dostave());
            stmt.setString(2, dostava.getRestoran());
            stmt.setString(3, dostava.getGost());
            stmt.setTimestamp(4, java.sql.Timestamp.valueOf(dostava.getVreme_narucivanja()));
    
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public List<Dostava> dostaveZaGosta(String gost) {
        List<Dostava> dostave = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from dostave where gost = ? order by vreme_narucivanja desc")) {

            stmt.setString(1, gost);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Dostava s = new Dostava(
                    rs.getString("restoran"),
                    rs.getString("gost"),
                    rs.getDouble("iznos"),
                    rs.getTimestamp("vreme_narucivanja").toLocalDateTime(),
                    rs.getString("vreme_dostave"),
                    rs.getString("status")   
                );
                dostave.add(s);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return dostave;
    }
    
    
}
