package com.example.backend.db;

import java.util.List;

import com.example.backend.modeli.Jelo;

public interface NarudzbineRepoInterface {
    
    public List<Jelo> jelovnikRestorana(String restoran);
}
