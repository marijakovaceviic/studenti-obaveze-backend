package com.example.backend.kontroleri;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.backend.db.NarudzbineRepo;
import com.example.backend.modeli.Jelo;

@RestController
@RequestMapping("/narudzbine")
@CrossOrigin(origins = "http://localhost:4200")
public class NarudzbineController {
    
    @GetMapping("/jelovnik/{restoran}")
    public List<Jelo> jelovnik(@PathVariable String restoran){
        return new NarudzbineRepo().jelovnikRestorana(restoran);
    }
}
