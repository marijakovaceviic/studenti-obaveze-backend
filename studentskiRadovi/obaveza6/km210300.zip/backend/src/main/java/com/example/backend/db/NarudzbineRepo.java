package com.example.backend.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.backend.modeli.Jelo;


public class NarudzbineRepo implements NarudzbineRepoInterface{

    @Override
    public List<Jelo> jelovnikRestorana(String restoran) {

        List<Jelo> jelovnik = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from jela where restoran = ?")) {

            stmt.setString(1, restoran);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
               Jelo j = new Jelo(
                rs.getString("restoran"),
                rs.getString("naziv"),
                rs.getString("slika"),
                rs.getDouble("cena"),
                rs.getString("sastojci")
               );
                jelovnik.add(j);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return jelovnik;
    }
    
}
