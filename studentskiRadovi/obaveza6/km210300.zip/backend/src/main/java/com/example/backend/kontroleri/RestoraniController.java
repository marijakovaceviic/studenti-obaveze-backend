package com.example.backend.kontroleri;

import java.io.File;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.backend.db.RestoraniRepo;
import com.example.backend.modeli.Jelo;
import com.example.backend.modeli.Korisnik;
import com.example.backend.modeli.RadnoVreme;
import com.example.backend.modeli.Raspored;
import com.example.backend.modeli.Restoran;
import com.example.backend.modeli.Zaposlen;

@RestController
@RequestMapping("/restorani")
@CrossOrigin(origins = "http://localhost:4200")
public class RestoraniController {
    
    @GetMapping("/brojRestorana")
    public int brojRestorana(){
        return new RestoraniRepo().brojRestorana();
    }

    @GetMapping("/sviRestorani")
    public List<Restoran> sviRestorani(){
        return new RestoraniRepo().sviRestorani();
    }

    @PostMapping("/dodavanje")
    public int dodavanje(@RequestBody Restoran r){
        return new RestoraniRepo().dodavanjeRestorana(r.getNaziv(), r.getAdresa(), r.getTip(), r.getOpis(), r.getTelefon());
    }

    @GetMapping("/dohvatiRestoran/{naziv}")
    public Restoran dohvatiRestoran(@PathVariable String naziv){
        return new RestoraniRepo().dohvatiRestoran(naziv);
    }

    @PostMapping("/dodavanjeKonobara")
    public int dodavanjeKonobara(@RequestBody Zaposlen z){
        return new RestoraniRepo().dodajKonobara(z);
    }

    @GetMapping("/restoranUKomeRadi/{konobar}")
    public Restoran restoranKonobara(@PathVariable String konobar){
        return new RestoraniRepo().restoranUKomeRadi(konobar);
    }

    @GetMapping("/zaposleniURestoranu/{restoran}")
    public List<Korisnik> zaposleniRestoran(@PathVariable String restoran){
        return new RestoraniRepo().zaposleniURestoranu(restoran);
    }

    @PostMapping("/dodavanjeRadnogVremena")
    public int dodavanjeRadnogVremena(@RequestBody RadnoVreme r){
        return new RestoraniRepo().dodajRadnoVreme(r.getNaziv(), r.getRadi_od(), r.getRadi_do(), r.getDan());
    }

    @GetMapping("/dohvatiRadnoVreme/{restoran}/{dan}")
    public List<String> dohvatiRadnoVreme(@PathVariable String restoran, @PathVariable String dan){
        return new RestoraniRepo().dohvatiRadnoVreme(restoran,dan);
    }

    @PostMapping("/dodavanjeElemntaRasporeda")
    public int dodavanjeElemntaRasporeda(@RequestBody Raspored r){
        return new RestoraniRepo().dodajElementRasporeda(r);
    }

    @GetMapping("/dohvatiRaspored/{restoran}")
    public List<Raspored> dohvatiRaspored(@PathVariable String restoran){
        return new RestoraniRepo().dohvatiRaspored(restoran);
    }

    @PostMapping("/dodavanjeJela")
    public int dodavanjeJela(@RequestBody Jelo j){
        return new RestoraniRepo().dodavanjeJela(j);
    }

   

    @PostMapping("/dodavanjeSlikeJela/{restoran}/{naziv}")
    public int dodavanjeSlikeJela(@RequestParam("slika") MultipartFile slika, @PathVariable String restoran, @PathVariable String naziv){
        try {
            String putanja = "D:/pia/projekat/frontend/src/assets/" + slika.getOriginalFilename();
            File finalno = new File(putanja);
            slika.transferTo(finalno);
      
           return new RestoraniRepo().postavljanjeSlikeJela(restoran,naziv,slika.getOriginalFilename());
   
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}
