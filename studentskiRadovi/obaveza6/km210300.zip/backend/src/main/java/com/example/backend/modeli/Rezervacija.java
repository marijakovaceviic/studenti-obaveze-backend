package com.example.backend.modeli;

public class Rezervacija {
    private int id;
    private String restoran;
    private String gost;
    private String datum;
    private int broj_osoba;
    private String opis;
    private String status;
    private String kom_konobar;
    private String kom_gost;
    private int ocena;
    private String vreme_rezervacije;
    private String konobar;
    private String dosao;
    private int dodeljen_sto;
    private int rb_stola;

    public Rezervacija(int id,String restoran, String gost, String datum, int broj_osoba, String opis, String status) {
        this.id = id;
        this.restoran = restoran;
        this.gost = gost;
        this.datum = datum;
        this.broj_osoba = broj_osoba;
        this.opis = opis;
        this.status = status;
    }

    public String getRestoran() {
        return restoran;
    }

    public void setRestoran(String restoran) {
        this.restoran = restoran;
    }

    public String getGost() {
        return gost;
    }

    public void setGost(String gost) {
        this.gost = gost;
    }

    public String getDatum() {
        return datum;
    }

    public void setDatum(String datum) {
        this.datum = datum;
    }

    public int getBroj_osoba() {
        return broj_osoba;
    }

    public void setBroj_osoba(int broj_osoba) {
        this.broj_osoba = broj_osoba;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getKom_konobar() {
        return kom_konobar;
    }

    public void setKom_konobar(String kom_konobar) {
        this.kom_konobar = kom_konobar;
    }

    public String getKom_gost() {
        return kom_gost;
    }

    public void setKom_gost(String kom_gost) {
        this.kom_gost = kom_gost;
    }

    public int getOcena() {
        return ocena;
    }

    public void setOcena(int ocena) {
        this.ocena = ocena;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVreme_rezervacije() {
        return vreme_rezervacije;
    }

    public void setVreme_rezervacije(String vreme_rezervacije) {
        this.vreme_rezervacije = vreme_rezervacije;
    }

    public String getKonobar() {
        return konobar;
    }

    public void setKonobar(String konobar) {
        this.konobar = konobar;
    }

    public String getDosao() {
        return dosao;
    }

    public void setDosao(String dosao) {
        this.dosao = dosao;
    }

    public int getDodeljen_sto() {
        return dodeljen_sto;
    }

    public void setDodeljen_sto(int dodeljen_sto) {
        this.dodeljen_sto = dodeljen_sto;
    }

    public int getRb_stola() {
        return rb_stola;
    }

    public void setRb_stola(int rb_stola) {
        this.rb_stola = rb_stola;
    }
    
    
    
}
