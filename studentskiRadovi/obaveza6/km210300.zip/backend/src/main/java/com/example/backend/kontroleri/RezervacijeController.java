package com.example.backend.kontroleri;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.backend.db.RezervacijeRepo;
import com.example.backend.modeli.Rezervacija;

@RestController
@RequestMapping("/rezervacije")
@CrossOrigin(origins = "http://localhost:4200")
public class RezervacijeController {

    @PostMapping("/novaRezervacija")
    public int novaRezervacija(@RequestBody Rezervacija r){
        return new RezervacijeRepo().novaRezervacija(r);
    }

    @PostMapping("/slobodanSto")
    public int slobodanStoUIntervalu(@RequestBody Rezervacija r){
        return new RezervacijeRepo().slobodanStoUIntervalu(r);
    }

    @GetMapping("/uPoslednjih24h")
    public int uPoslednjih24h(){
        return new RezervacijeRepo().rezervacijeUPoslednjih24h();
    }

    @GetMapping("/uPoslednjih7dana")
    public int uPoslednjih7dana(){
        return new RezervacijeRepo().rezervacijeUPoslednjih7dana();
    }

    @GetMapping("/uPoslednjihMesecDana")
    public int rezervacijeUPoslednjihMesecDana(){
        return new RezervacijeRepo().rezervacijeUPoslednjihMesecDana();
    }

    @GetMapping("/neobradjeneRezervacije/{restoran}")
    public List<Rezervacija> neobradjene(@PathVariable String restoran){
        return new RezervacijeRepo().neobradjeneRezervacije(restoran);
    }

    @PostMapping("/postaviStatus")
    public int postaviStatus(@RequestBody Rezervacija r){
        return new RezervacijeRepo().postaviStatus(r.getId(),r.getStatus(),r.getKonobar(), r.getKom_konobar(), r.getDodeljen_sto(), r.getRb_stola());
    }

    @GetMapping("/aktuelneRezervacije/{gost}")
    public List<Rezervacija> aktuelne(@PathVariable String gost){
        return new RezervacijeRepo().aktuelneRezervacije(gost);
    }

    @GetMapping("/istekleRezervacije/{gost}")
    public List<Rezervacija> istekle(@PathVariable String gost){
        return new RezervacijeRepo().istekleRezervacije(gost);
    }

    @GetMapping("/zaduzenjeKonobara/{konobar}")
    public List<Rezervacija> zaduzenje(@PathVariable String konobar){
        return new RezervacijeRepo().zaduzenjeKonobara(konobar);
    }

    @PostMapping("/gostDosao")
    public int gostDosao(@RequestBody Rezervacija r){
        return new RezervacijeRepo().gostDosao(r);
    }

    @GetMapping("/daniZaKonobara/{konobar}")
    public List<String> daniZaKonobara(@PathVariable String konobar){
        return new RezervacijeRepo().daniZaKonobara(konobar);
    }

    @PostMapping("/brojGostijuZaKonobara")
    public int brojGostijuZaKonobara(@RequestBody Rezervacija r){
        return new RezervacijeRepo().brojGostijuZaKonobara(r.getKonobar(),r.getDatum());
    }

    @GetMapping("/ukupanBrojGostijuZaKonobara/{konobar}")
    public int ukupanBrojGostijuZaKonobara(@PathVariable String konobar){
        return new RezervacijeRepo().ukupanBrojGostijuZaKonobara(konobar);
    }

    @GetMapping("/prosecanBrojRezervacijaPoDanu/{restoran}/{dan}")
    public double prosecanBrojRezervacijaPoDanu(@PathVariable String restoran, @PathVariable int dan){
        return new RezervacijeRepo().prosecanBrojRezervacijaPoDanu(restoran,dan);
    }

    @PostMapping("/zauzetiStolovi")
    public List<Integer> zauzetiStolovi(@RequestBody Rezervacija r){
        return new RezervacijeRepo().zauzetiStolovi(r);
    }
}
