package com.example.backend.db;

import java.util.List;

import com.example.backend.modeli.Korisnik;

public interface KorisniciRepoInterface {
    
    public Korisnik prijava(Korisnik korisnik);

    public int registracija(Korisnik korisnik);

    public int promenaLozinke(Korisnik korisnik);

    public int brojRegistrovanihGostiju();

    public int dodavanjeProfilne(String korIme,String putanja);

    public int azuriranjeImena(String ime, String korIme);

    public int azurirajPrezime(String prezime, String korIme);

    public int azurirajAdresu(String adresa, String korIme);

    public int azurirajEmail(String email, String korIme);

    public int azurirajTelefon(String telefon, String korIme);

    public int promenaProfilne(String korIme,String putanja);

    public List<Korisnik> sviKorisnici();

    public List<Korisnik> sviZahtevi();

    public int dodajKorisnika(Korisnik korisnik);

    public int ukloniZahtev(String korIme);

    public int zapamtiOdbijene(String korIme, String email);

    public Korisnik dohvatiKorisnika(String korIme);

    public int dodavanjeProfilneKonobar(String korIme,String putanja);

    public int azuriranjePodataka(Korisnik k);

    public List<String> odbijenaKorImena();

    public List<String> odbijeniEmailovi();

}
