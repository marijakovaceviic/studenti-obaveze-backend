package com.example.backend.modeli;

public class Raspored {
    private String restoran;
    private String element;
    private int x;
    private int y;
    private int sirina;
    private int visina;
    private int precnik;
    private int brOsoba;

    public Raspored(String restoran, String element, int x, int y, int sirina, int visina, int precnik, int brOsoba) {
        this.restoran = restoran;
        this.element = element;
        this.x = x;
        this.y = y;
        this.sirina = sirina;
        this.visina = visina;
        this.precnik = precnik;
        this.brOsoba = brOsoba;
    }
    
    public String getRestoran() {
        return restoran;
    }
    public void setRestoran(String restoran) {
        this.restoran = restoran;
    }
    public String getElement() {
        return element;
    }
    public void setElement(String element) {
        this.element = element;
    }
    public int getX() {
        return x;
    }
    public void setX(int x) {
        this.x = x;
    }
    public int getY() {
        return y;
    }
    public void setY(int y) {
        this.y = y;
    }
    public int getSirina() {
        return sirina;
    }
    public void setSirina(int sirina) {
        this.sirina = sirina;
    }
    public int getVisina() {
        return visina;
    }
    public void setVisina(int visina) {
        this.visina = visina;
    }
    public int getPrecnik() {
        return precnik;
    }
    public void setPrecnik(int precnik) {
        this.precnik = precnik;
    }
    public int getBrOsoba() {
        return brOsoba;
    }
    public void setBrOsoba(int brOsoba) {
        this.brOsoba = brOsoba;
    }

    
}
