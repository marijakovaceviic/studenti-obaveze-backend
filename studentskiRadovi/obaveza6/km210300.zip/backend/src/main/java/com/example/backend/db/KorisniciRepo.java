package com.example.backend.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.backend.modeli.Korisnik;

public class KorisniciRepo implements KorisniciRepoInterface{

    @Override
    public Korisnik prijava(Korisnik korisnik) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from korisnici where korisnicko_ime = ? and lozinka = ? ")) {

            stmt.setString(1, korisnik.getKorisnicko_ime());
            stmt.setString(2, korisnik.getLozinka());

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Korisnik(
                        rs.getString("korisnicko_ime"),
                        rs.getString("lozinka"),
                        rs.getString("tip"),
                        rs.getString("ime"),
                        rs.getString("prezime"),
                        rs.getString("pol"),
                        rs.getString("adresa"),
                        rs.getString("telefon"),
                        rs.getString("email"),
                        rs.getString("slika"),
                        rs.getString("broj_kartice"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
       
    }

    @Override
    public int promenaLozinke(Korisnik korisnik) { 
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "update korisnici set lozinka = ? where korisnicko_ime = ?")) {
            
            stmt.setString(1, korisnik.getLozinka());
            stmt.setString(2, korisnik.getKorisnicko_ime());
    
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public int brojRegistrovanihGostiju() {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select count(*) as broj from korisnici where tip = 'gost' ")) {

            ResultSet rs = stmt.executeQuery();
            if (rs.next()){
                return rs.getInt("broj");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public int registracija(Korisnik korisnik) {

        try (Connection conn = DB.source().getConnection();
        PreparedStatement stm1 = conn.prepareStatement(
            "select * from korisnici where korisnicko_ime = ? ");){
                stm1.setString(1, korisnik.getKorisnicko_ime());
                ResultSet rs1 = stm1.executeQuery();
                if (rs1.next()){
                    return -7;
                }
                else{
                    try(PreparedStatement stm2 = conn.prepareStatement(
                        "select * from zahtevi where korisnicko_ime = ?");){
                            stm2.setString(1, korisnik.getKorisnicko_ime());
                            ResultSet rs2 = stm2.executeQuery();
                            if (rs2.next()){
                                return -7;
                            }
                            else{
                                try(PreparedStatement stm3 = conn.prepareStatement(
                                    "select * from korisnici where email = ?");){
                                        stm3.setString(1, korisnik.getEmail());
                                        ResultSet rs3 = stm3.executeQuery();
                                        if (rs3.next()){
                                            return -9;
                                        }
                                        else{
                                            try(PreparedStatement stm4 = conn.prepareStatement(
                                                "select * from zahtevi where email = ?");){
                                                    stm4.setString(1, korisnik.getEmail());
                                                    ResultSet rs4 = stm4.executeQuery();
                                                    if (rs4.next()){
                                                        return -9;
                                                    }
                                                    else{
                                                        try(PreparedStatement stmt = conn.prepareStatement(
                                                            "insert into zahtevi(korisnicko_ime,lozinka,tip,ime,prezime,pol,adresa,telefon,email,slika,broj_kartice) values(?,?,?,?,?,?,?,?,?,?,?)");) {
                                                    
                                                                stmt.setString(1, korisnik.getKorisnicko_ime());
                                                                stmt.setString(2, korisnik.getLozinka());
                                                                stmt.setString(3, korisnik.getTip());
                                                                stmt.setString(4, korisnik.getIme());
                                                                stmt.setString(5, korisnik.getPrezime());
                                                                stmt.setString(6, korisnik.getPol());
                                                                stmt.setString(7, korisnik.getAdresa());
                                                                stmt.setString(8, korisnik.getTelefon());
                                                                stmt.setString(9, korisnik.getEmail());
                                                                stmt.setString(10, "");
                                                                stmt.setString(11, korisnik.getBroj_kartice());
                                                    
                                                               return stmt.executeUpdate();
                                                        }
                                                    }
                                                }
                                        } 
                                    }
                            } 
                        } 
                    }    

            }catch (SQLException e) {
                e.printStackTrace();
            } 
        return 0; 
    }

    @Override
    public int dodavanjeProfilne(String korIme,String putanja) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "update zahtevi set slika = ? where korisnicko_ime = ?");) {

            stmt.setString(1, putanja);
            stmt.setString(2, korIme);

           return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;    
    }

    @Override
    public int azuriranjeImena(String ime, String korIme) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "update korisnici set ime = ? where korisnicko_ime = ?")) {
            
            stmt.setString(1, ime);
            stmt.setString(2, korIme);
    
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public int azurirajPrezime(String prezime, String korIme) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "update korisnici set prezime = ? where korisnicko_ime = ?")) {
            
            stmt.setString(1, prezime);
            stmt.setString(2, korIme);
    
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public int azurirajAdresu(String adresa, String korIme) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "update korisnici set adresa = ? where korisnicko_ime = ?")) {
            
            stmt.setString(1, adresa);
            stmt.setString(2, korIme);
    
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public int azurirajEmail(String email, String korIme) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "update korisnici set email = ? where korisnicko_ime = ?")) {
            
            stmt.setString(1, email);
            stmt.setString(2, korIme);
    
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public int azurirajTelefon(String telefon, String korIme) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "update korisnici set telefon = ? where korisnicko_ime = ?")) {
            
            stmt.setString(1, telefon);
            stmt.setString(2, korIme);
    
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public int promenaProfilne(String korIme, String putanja) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "update korisnici set slika = ? where korisnicko_ime = ?");) {

            stmt.setString(1, putanja);
            stmt.setString(2, korIme);

           return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;    
    }

    //@Override
    public List<Korisnik> sviKorisnici() {
        List<Korisnik> korisnici = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from korisnici where tip != 'admin' ")) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Korisnik k = new Korisnik(
                        rs.getString("korisnicko_ime"),
                        rs.getString("lozinka"),
                        rs.getString("tip"),
                        rs.getString("ime"),
                        rs.getString("prezime"),
                        rs.getString("pol"),
                        rs.getString("adresa"),
                        rs.getString("telefon"),
                        rs.getString("email"),
                        rs.getString("slika"),
                        rs.getString("broj_kartice"));
                korisnici.add(k);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return korisnici;
    }

   // @Override
    public List<Korisnik> sviZahtevi() {
        List<Korisnik> zahtevi = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from zahtevi ")) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Korisnik k = new Korisnik(
                        rs.getString("korisnicko_ime"),
                        rs.getString("lozinka"),
                        rs.getString("tip"),
                        rs.getString("ime"),
                        rs.getString("prezime"),
                        rs.getString("pol"),
                        rs.getString("adresa"),
                        rs.getString("telefon"),
                        rs.getString("email"),
                        rs.getString("slika"),
                        rs.getString("broj_kartice"));
                zahtevi.add(k);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return zahtevi;
    }

    @Override
    public int dodajKorisnika(Korisnik korisnik) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "insert into korisnici(korisnicko_ime,lozinka,tip,ime,prezime,pol,adresa,telefon,email,slika,broj_kartice) values(?,?,?,?,?,?,?,?,?,?,?)");) {

            stmt.setString(1, korisnik.getKorisnicko_ime());
            stmt.setString(2, korisnik.getLozinka());
            stmt.setString(3, korisnik.getTip());
            stmt.setString(4, korisnik.getIme());
            stmt.setString(5, korisnik.getPrezime());
            stmt.setString(6, korisnik.getPol());
            stmt.setString(7, korisnik.getAdresa());
            stmt.setString(8, korisnik.getTelefon());
            stmt.setString(9, korisnik.getEmail());
            stmt.setString(10, korisnik.getSlika());
            stmt.setString(11, korisnik.getBroj_kartice());

           return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int ukloniZahtev(String korIme) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "delete from zahtevi where korisnicko_ime = ? ")) {
            
            stmt.setString(1, korIme);
    
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public int zapamtiOdbijene(String korIme, String email) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "insert into odbijeni(korisnicko_ime,email) values(?,?)")) {
            
            stmt.setString(1, korIme);
            stmt.setString(2, email);
    
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public Korisnik dohvatiKorisnika(String korIme) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select * from korisnici where korisnicko_ime = ? ")) {

            stmt.setString(1, korIme);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Korisnik(
                        rs.getString("korisnicko_ime"),
                        rs.getString("lozinka"),
                        rs.getString("tip"),
                        rs.getString("ime"),
                        rs.getString("prezime"),
                        rs.getString("pol"),
                        rs.getString("adresa"),
                        rs.getString("telefon"),
                        rs.getString("email"),
                        rs.getString("slika"),
                        rs.getString("broj_kartice"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public int dodavanjeProfilneKonobar(String korIme, String putanja) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "update korisnici set slika = ? where korisnicko_ime = ?");) {

            stmt.setString(1, putanja);
            stmt.setString(2, korIme);

           return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;    
    }

    @Override
    public int azuriranjePodataka(Korisnik k) {
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "update korisnici set ime = ?, prezime = ?, adresa = ?, telefon = ?, broj_kartice = ? where korisnicko_ime = ?")) {
            
            stmt.setString(1, k.getIme());
            stmt.setString(2, k.getPrezime());
            stmt.setString(3, k.getAdresa());
            stmt.setString(4, k.getTelefon());
            stmt.setString(5, k.getBroj_kartice());
            stmt.setString(6, k.getKorisnicko_ime());
            
            return stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public List<String> odbijenaKorImena() {
        List<String> odbijeni = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select korisnicko_ime from odbijeni ")) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                odbijeni.add(rs.getString("korisnicko_ime"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return odbijeni;
    }

    @Override
    public List<String> odbijeniEmailovi() {
        List<String> odbijeni = new ArrayList<>();
        try (Connection conn = DB.source().getConnection();
        PreparedStatement stmt = conn.prepareStatement(
        "select email from odbijeni ")) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                odbijeni.add(rs.getString("email"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return odbijeni;
    }

  

    
}
