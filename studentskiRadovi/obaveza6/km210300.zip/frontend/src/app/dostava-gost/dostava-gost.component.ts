import { Component, OnInit } from '@angular/core';
import { DostaveService } from '../servisi/dostave.service';
import { Korisnik } from '../modeli/korisnik';
import { Dostava } from '../modeli/dostava';

@Component({
  selector: 'app-dostava-gost',
  templateUrl: './dostava-gost.component.html',
  styleUrls: ['./dostava-gost.component.css']
})
export class DostavaGostComponent implements OnInit{

  constructor(private dostaveS:DostaveService){}

  ulogovan:Korisnik = new Korisnik();
  sveDostave:Dostava[] = [];
  aktuelneDostave:Dostava[] = [];
  prethodneDostave:Dostava[] = [];
  
  ngOnInit(): void {
    let korisnik = localStorage.getItem("ulogovan");
    if(korisnik != null){
      this.ulogovan = JSON.parse(korisnik);

      this.dostaveS.dostaveZaGosta(this.ulogovan.korisnicko_ime).subscribe(
        data=>{
          this.sveDostave = data;

          for(let i =0; i<this.sveDostave.length; i++){
            if(this.sveDostave[i].vreme_dostave == "20-30 minuta"){
              this.sveDostave[i].najkasnijeDo = new Date(this.sveDostave[i].vreme_narucivanja);
              this.sveDostave[i].najkasnijeDo.setMinutes(this.sveDostave[i].najkasnijeDo.getMinutes() + 30);
            }
            else if(this.sveDostave[i].vreme_dostave == "30-40 minuta"){
              this.sveDostave[i].najkasnijeDo = new Date(this.sveDostave[i].vreme_narucivanja);
              this.sveDostave[i].najkasnijeDo.setMinutes(this.sveDostave[i].najkasnijeDo.getMinutes() + 40);
            }
            else if(this.sveDostave[i].vreme_dostave == "50-60 minuta"){
              this.sveDostave[i].najkasnijeDo = new Date(this.sveDostave[i].vreme_narucivanja);
              this.sveDostave[i].najkasnijeDo.setMinutes(this.sveDostave[i].najkasnijeDo.getMinutes() + 60);
            }
          }

          for(let i =0; i<this.sveDostave.length; i++){
            let trenutnoVreme = new Date(); 
            if(this.sveDostave[i].najkasnijeDo < trenutnoVreme){
              this.prethodneDostave.push(this.sveDostave[i]);
            }
            else{
              this.aktuelneDostave.push(this.sveDostave[i]);
            }
          }

        }
      )
    }
      
  }
}
