import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { GostComponent } from './gost/gost.component';
import { KonobarComponent } from './konobar/konobar.component';
import { AdminComponent } from './admin/admin.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { RegistracijaComponent } from './registracija/registracija.component';
import { PromenaLozinkeComponent } from './promena-lozinke/promena-lozinke.component';
import { ProfilComponent } from './profil/profil.component';
import { RestoraniComponent } from './restorani/restorani.component';
import { DetaljiORestoranuComponent } from './detalji-o-restoranu/detalji-o-restoranu.component';
import { KorpaComponent } from './korpa/korpa.component';
import { DostaveKonobarComponent } from './dostave-konobar/dostave-konobar.component';
import { DostavaGostComponent } from './dostava-gost/dostava-gost.component';
import { AzuriranjeKorisnikaComponent } from './azuriranje-korisnika/azuriranje-korisnika.component';
import { RezervacijeKonobarComponent } from './rezervacije-konobar/rezervacije-konobar.component';
import { RezervacijeGostComponent } from './rezervacije-gost/rezervacije-gost.component';
import { StatistikaComponent } from './statistika/statistika.component';
import { profiliGuard } from './guardovi/profili.guard';
import { adminGuard } from './guardovi/admin.guard';
import { konobariGuard } from './guardovi/konobari.guard';
import { gostiGuard } from './guardovi/gosti.guard';

const routes: Routes = [
  { path: "", component: LoginComponent },
  { path: "gost", component: GostComponent },
  { path: "konobar", component: KonobarComponent },
  { path: "adminlogin", component: AdminLoginComponent },
  { path: "admin", component: AdminComponent, canActivate:[adminGuard]},
  { path: "registracija", component: RegistracijaComponent },
  { path:"promenaLozinke", component:PromenaLozinkeComponent},
  { path:"profil", component:ProfilComponent, canActivate:[profiliGuard]},
  { path:"restorani", component:RestoraniComponent, canActivate:[gostiGuard]},
  { path:"restoran/:naziv", component: DetaljiORestoranuComponent, canActivate:[gostiGuard]},
  { path:"korpa/:naziv", component: KorpaComponent, canActivate:[gostiGuard]},
  { path:"dostaveKonobar", component: DostaveKonobarComponent, canActivate: [konobariGuard]},
  { path:"dostaveGost", component: DostavaGostComponent, canActivate:[gostiGuard]},
  { path:"azuriranje", component: AzuriranjeKorisnikaComponent, canActivate:[adminGuard]},
  { path:"rezervacijeKonobar", component: RezervacijeKonobarComponent, canActivate: [konobariGuard]},
  { path:"rezervacijeGost", component: RezervacijeGostComponent, canActivate:[gostiGuard]},
  { path:"statistika", component: StatistikaComponent, canActivate: [konobariGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
