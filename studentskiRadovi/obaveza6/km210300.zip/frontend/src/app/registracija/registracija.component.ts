import { Component } from '@angular/core';
import { KorisnikService } from '../servisi/korisnik.service';
import * as CryptoJS from 'crypto-js';


@Component({
  selector: 'app-registracija',
  templateUrl: './registracija.component.html',
  styleUrls: ['./registracija.component.css']
})
export class RegistracijaComponent {

  constructor(private korisnikS: KorisnikService){}

  korIme:string = "";
  lozinka: string = "";
  ime: string = "";
  prezime: string = "";
  pol: string = "";
  adresa: string = "";
  telefon: string = "";
  email: string = "";
  brKartice:string = "";
  pitanje:string = "";
  odgovor:string = "";
  greska: string = "";

  izabranaSlika:boolean = false;
  dodataSlika!: File;
 
  registracija(){
    this.greska = "";
    if (this.pol == ""){
      this.greska = "Nije izabran pol";
    }
    else{
      let regexLozinka = /^(?=[a-zA-Z])(?=.*\d)(?=.*[A-Z])(?=(?:.*[a-z]){3,})(?=.*[!@#$%^&*])[A-Za-z][A-Za-z\d!@#$%^&*]{6,10}$/;
      
      let regexBrKartice = /^(\d{16}|\d{4} \d{4} \d{4} \d{4})$/;

      let regexTelefon = /^06\d\s?\d{4}\s?\d{3}$/;

      let regexEmail = /^[a-z][a-z0-9._%+-]*@[a-z0-9.-]+\.[a-z]{2,}$/;

      if(!regexLozinka.test(this.lozinka)){
        this.greska = "Lozinka mora pocinjati slovom i mora imati od 6 do 10 karaktera, od toga bar jedno veliko slovo, tri mala, jedan broj i jedan specijalni karakter"
      }
      else if(!regexBrKartice.test(this.brKartice)){
        this.greska = "Broj kreditne kartice mora biti u formatu xxxx xxxx xxxx xxxx ili xxxxxxxxxxxxxxxx"
      }
      else if(!regexTelefon.test(this.telefon)){
        this.greska = "Broj telefona mora biti u formatu 06x xxxx xxx ili 06x xxxxxxx ili 06xxxxxxxx"
      }
      else if(!regexEmail.test(this.email)){
        this.greska = "Email nije u odgovarajucem formatu"
      }
      else{
        this.korisnikS.odbijenaKorImena().subscribe(
          odb=>{
            if (odb.includes(this.korIme)){
              this.greska = "Uneto korisnicko ime je odbijeno i ne moze se koristiti"
            }
            else{
              this.korisnikS.odbijeniEmailovi().subscribe(
                odbEm=>{
                  if (odbEm.includes(this.email)){
                    this.greska = "Uneta email adresa je odbijena i ne moze se koristiti"
                  }
                  else{
                    const hesiranaLozinka = CryptoJS.SHA256(this.lozinka).toString();
                    this.korisnikS.registracijaGosta(this.korIme,hesiranaLozinka,this.ime,this.prezime,"gost",this.pol,this.adresa,
                    this.telefon,this.email,this.brKartice).subscribe(
                      data=>{
                        if(data > 0){
                          if (this.izabranaSlika){

                            const formData = new FormData();
                            formData.append('slika',this.dodataSlika);
                            this.korisnikS.dodavanjeProfilneSlike(this.korIme,formData).subscribe(
                              p=>{
                                if (p != 0){
                                  this.resetujFormu();
                                  this.greska = "Vas zahtev je upamcen!";
                                }
                              }
                            )
                          }
                          else{
                            this.korisnikS.postavljanjePodrazumevaneProfilne(this.korIme).subscribe(
                              r=>{
                                if (r != 0){
                                  this.resetujFormu();
                                  this.greska = "Vas zahtev je upamcen!";
                                }
                              }
                            )
                          }

                          localStorage.setItem("pitanjeKorisnika" + this.korIme, this.pitanje); 
                          localStorage.setItem("odgovorKorisnika" + this.korIme, this.odgovor);
                        }
                        else if(data == -7){
                          this.greska =  "Uneto korisnicko ime je zauzeto";
                        }
                        else if(data == -9){
                          this.greska = "Email adresa je vec koriscena";
                        }
                      }
                    )
                  }
                }
              )
            }
          }
        )
    }
    }
  }

  sacuvajSliku(event: any){
   
    this.dodataSlika = event.target.files[0];
    if (this.dodataSlika && (this.dodataSlika.type == 'image/jpeg' || this.dodataSlika.type == 'image/png')) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const img = new Image(); 
        img.onload = () => {
          if (img.width >= 100 && img.width <= 300 && img.height >= 100 && img.height <= 300) {
            this.izabranaSlika = true;
          }
          else{
            this.greska = "Izabrana slika nije u odgovarajucih dimenzija"
          }
        };
        img.src = e.target.result;
      };

      reader.readAsDataURL(this.dodataSlika);
    }
    else{
      this.greska = "Izabrana slika nije u odgovarajucem formatu fajla"
    }
  }

  resetujFormu(){
    this.korIme = "";
    this.lozinka = "";
    this.ime = "";
    this.prezime = "";
    this.pol = "";
    this.adresa = "";
    this.telefon = "";
    this.email = "";
    this.brKartice = "";
    this.pitanje = "";
    this.odgovor = "";
  }
}
