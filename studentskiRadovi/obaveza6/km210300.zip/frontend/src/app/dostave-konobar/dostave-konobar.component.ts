import { Component, OnInit } from '@angular/core';
import { DostaveService } from '../servisi/dostave.service';
import { Dostava } from '../modeli/dostava';
import { RestoraniService } from '../servisi/restorani.service';
import { Korisnik } from '../modeli/korisnik';
import { Restoran } from '../modeli/restoran';

@Component({
  selector: 'app-dostave-konobar',
  templateUrl: './dostave-konobar.component.html',
  styleUrls: ['./dostave-konobar.component.css']
})
export class DostaveKonobarComponent implements OnInit{

  constructor(private dostaveS:DostaveService, private restoraniS:RestoraniService){}

  trenutneNarudzbine:Dostava[] = [];
  ulogovan:Korisnik = new Korisnik();
  restoran:Restoran = new Restoran();

  ngOnInit(): void {
    let x = localStorage.getItem("ulogovan");
    if(x != null){
      this.ulogovan = JSON.parse(x);

      this.restoraniS.restoranUKomeRadi(this.ulogovan.korisnicko_ime).subscribe(
        data=>{
          if (data != null){
            this.restoran = data; 

            this.dostaveS.trenutneNarudzbine(this.restoran.naziv).subscribe(
              data=>{
                this.trenutneNarudzbine = data;
              }
            )
          }
        }
      )
    }
    
  }

  potvrdaNarudzbine(dostava:Dostava){
    dostava.prihvaceno = true;
  }

  odbaciNarudzbinu(dostava:Dostava){
    dostava.status = "odbijeno";
    this.dostaveS.potvrdiIliOdbaci(dostava).subscribe(
      data=>{
        if (data > 0){
          this.ngOnInit();
        }
      }
    );
  }
  
  greska:string = "";

  finalnaPotvrda(dostava:Dostava){
    if (dostava.vreme_dostave == ""){
      this.greska = "Niste uneli potrebno vreme";
    }
    else{
      dostava.status = "prihvaceno";
      this.dostaveS.potvrdiIliOdbaci(dostava).subscribe(
        data=>{
          if (data > 0){
            this.dostaveS.postaviVremeDostave(dostava).subscribe(
              p=>{
                if (p > 0){
                  this.ngOnInit();
                }
              }
            );
          }
        }
      );
    }
  }
}
