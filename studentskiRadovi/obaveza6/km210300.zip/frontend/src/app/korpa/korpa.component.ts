import { Component, OnInit } from '@angular/core';
import { Korisnik } from '../modeli/korisnik';
import { ActivatedRoute } from '@angular/router';
import { KorpaService } from '../servisi/korpa.service';
import { JeloZaKorpu } from '../modeli/jeloZaKorpu';
import { DostaveService } from '../servisi/dostave.service';

@Component({
  selector: 'app-korpa',
  templateUrl: './korpa.component.html',
  styleUrls: ['./korpa.component.css']
})
export class KorpaComponent implements OnInit{

  constructor(private router:ActivatedRoute, private korpaS:KorpaService, private dostaveS:DostaveService){}
  
  ulogovan:Korisnik = new Korisnik();
  restoran:string="";
  sadrzaj:JeloZaKorpu[] = [];
  nazad = "../../restoran/"+this.restoran

  ngOnInit(): void {
    let x = this.router.snapshot.paramMap.get('naziv'); 
    if(x != null){
      this.restoran = x;
    }

    let korisnik = localStorage.getItem("ulogovan");
    if(korisnik != null){
      this.ulogovan = JSON.parse(korisnik);

      this.korpaS.dohvatiSadrzaj(this.ulogovan.korisnicko_ime,this.restoran).subscribe(
        data=>{
          this.sadrzaj = data;
        }
      )
    }

  }

  potvrdaPorudzbine(){
    //dodajemo u tabelu narudzbine
    //povezati polja sa ngModel ...
    let iznos ;
    this.korpaS.potvrdaPorudzbine(this.ulogovan.korisnicko_ime,this.restoran).subscribe(
      data=>{
        if (data > 0){
          iznos = data;
          this.korpaS.dohvatiSadrzaj(this.ulogovan.korisnicko_ime,this.restoran).subscribe(
            data=>{
              this.sadrzaj = data;
            }
          );

          this.dostaveS.novaDostava(this.restoran,this.ulogovan.korisnicko_ime,iznos).subscribe(
            
          )
        }
      }
    )
  
  }

  izmenaKorpePlus(jelo:JeloZaKorpu){
    this.korpaS.izmenaKorpe(jelo.gost,jelo.restoran,jelo.naziv_jela,jelo.kolicina + 1).subscribe(
      data=>{
        if(data>0){
          this.korpaS.dohvatiSadrzaj(this.ulogovan.korisnicko_ime,this.restoran).subscribe(
            s=>{
              this.sadrzaj = s;
            }
          )
        }
      }
    );
  }

  izmenaKorpeMinus(jelo:JeloZaKorpu){
    this.korpaS.izmenaKorpe(jelo.gost,jelo.restoran,jelo.naziv_jela,jelo.kolicina - 1).subscribe(
      data=>{
        if(data>0){
          this.korpaS.dohvatiSadrzaj(this.ulogovan.korisnicko_ime,this.restoran).subscribe(
            s=>{
              this.sadrzaj = s;
            }
          )
        }
      }
    );
  }

  brisanjeIzKorpe(jelo:JeloZaKorpu){
    this.korpaS.izmenaKorpe(jelo.gost,jelo.restoran,jelo.naziv_jela,0).subscribe(
      data=>{
        if(data>0){
          this.korpaS.dohvatiSadrzaj(this.ulogovan.korisnicko_ime,this.restoran).subscribe(
            s=>{
              this.sadrzaj = s;
            }
          )
        }
      }
    );
  }
}
