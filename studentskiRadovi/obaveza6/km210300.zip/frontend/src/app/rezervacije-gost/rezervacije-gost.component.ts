import { Component, OnInit } from '@angular/core';
import { RezervacijeService } from '../servisi/rezervacije.service';
import { Korisnik } from '../modeli/korisnik';
import { Restoran } from '../modeli/restoran';
import { Rezervacija } from '../modeli/rezervacija';
import { RestoraniService } from '../servisi/restorani.service';

@Component({
  selector: 'app-rezervacije-gost',
  templateUrl: './rezervacije-gost.component.html',
  styleUrls: ['./rezervacije-gost.component.css']
})
export class RezervacijeGostComponent implements OnInit{

  constructor(private rezervacijeS:RezervacijeService, private restoraniS:RestoraniService){}

  aktuelne:Rezervacija[] = [];
  istekle:Rezervacija[] =[];
  ulogovan:Korisnik = new Korisnik();
  restoran:Restoran = new Restoran();
  
  ngOnInit(): void {
    let x = localStorage.getItem("ulogovan");
    if(x != null){
      this.ulogovan = JSON.parse(x);

      this.rezervacijeS.aktuelneRezervacije(this.ulogovan.korisnicko_ime).subscribe(
        data=>{
          this.aktuelne = data;

          this.aktuelne.forEach(a=>{
            this.restoraniS.dohvatiRestoran(a.restoran).subscribe(
              rest=>{
                a.adresaRestorana = rest.adresa;
              }
            )
          })
        }
      ) 
    }

    this.rezervacijeS.istekleRezervacije(this.ulogovan.korisnicko_ime).subscribe(
      ist=>{
        this.istekle = ist; 
      }
    )
  }
}
