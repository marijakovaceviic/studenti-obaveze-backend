import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-konobar',
  templateUrl: './konobar.component.html',
  styleUrls: ['./konobar.component.css']
})
export class KonobarComponent {

  constructor(private router:Router){}

  logout(){
    localStorage.removeItem('ulogovan');
    this.router.navigate(['']);
  }
}
