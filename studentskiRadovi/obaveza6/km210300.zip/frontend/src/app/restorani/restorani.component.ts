import { Component, OnInit } from '@angular/core';
import { RestoraniService } from '../servisi/restorani.service';
import { Restoran } from '../modeli/restoran';

@Component({
  selector: 'app-restorani',
  templateUrl: './restorani.component.html',
  styleUrls: ['./restorani.component.css']
})
export class RestoraniComponent implements OnInit{

  constructor(private restoraniS:RestoraniService){}

  sviRestorani:Restoran[] =[];
  nazivPretraga:string = "";
  adresaPretraga:string = "";
  tipPretraga:string = "";
  rezultatPretrage:Restoran[] = [];

  ngOnInit(): void {
    this.restoraniS.sviRestorani().subscribe(
      svi=>{
        this.sviRestorani = svi;
      }
    )
  }

  rastucePoNazivu(){
    this.sviRestorani = this.restoraniS.sortirajRastucePoNazivu(this.sviRestorani);
  }

  opadajucePoNazivu(){
    this.sviRestorani = this.restoraniS.sortirajOpadajucePoNazivu(this.sviRestorani);
  }

  rastucePoAdresi(){
    this.sviRestorani = this.restoraniS.sortirajRastucePoAdresi(this.sviRestorani);
  }

  opadajucePoAdresi(){
    this.sviRestorani = this.restoraniS.sortirajOpadajucePoAdresi(this.sviRestorani);
  }

  rastucePoTipu(){
    this.sviRestorani = this.restoraniS.sortirajRastucePoTipu(this.sviRestorani);
  }

  opadajucePoTipu(){
    this.sviRestorani = this.restoraniS.sortirajOpadajucePoTipu(this.sviRestorani);
  }

  pretraga(){
    this.rezultatPretrage = this.restoraniS.pretraga(this.sviRestorani,this.nazivPretraga,this.adresaPretraga,this.tipPretraga);
  }
}
