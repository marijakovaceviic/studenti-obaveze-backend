import { Component, OnInit } from '@angular/core';
import { RezervacijeService } from '../servisi/rezervacije.service';
import { Korisnik } from '../modeli/korisnik';
import { ChartConfiguration, ChartOptions } from 'chart.js';
import { combineLatest, forkJoin, map, switchMap } from 'rxjs';
import { RestoraniService } from '../servisi/restorani.service';
import { Restoran } from '../modeli/restoran';

@Component({
  selector: 'app-statistika',
  templateUrl: './statistika.component.html',
  styleUrls: ['./statistika.component.css']
})
export class StatistikaComponent implements OnInit{

  constructor(private rezervacijeS:RezervacijeService, private restoraniS:RestoraniService){}

  daniKonobar:string[]=[]
  brojGostiju:number[]=[]
  ulogovan:Korisnik = new Korisnik()
  restoran:Restoran = new Restoran();
  zaposleni:string[]=[]
  ukupnoGostijuZaKonob:number[]=[];
  rezervacije24Mes:number[]=[]
  daniUNedelji:string[]=[]


  barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true
  };
  barChartType = 'bar';
  barChartLegend = true;

  
  public barChartData: ChartConfiguration<'bar'>['data'] = {
    labels: [],
    datasets: [
      { data: [], label: 'Broj gostiju' }
    ]
  };

  ngOnInit(): void {
    let x = localStorage.getItem("ulogovan");
    if (x != null) {
      this.ulogovan = JSON.parse(x);

      const daniObservable = this.rezervacijeS.daniZaKonobara(this.ulogovan.korisnicko_ime);
      const brojObservable = daniObservable.pipe(
        switchMap(dani => forkJoin(dani.map(d => this.rezervacijeS.brojGostijuZaKonobara(this.ulogovan.korisnicko_ime, d))))
      );

      forkJoin([daniObservable, brojObservable]).subscribe(([dani, brojevi]) => {
        this.daniKonobar = dani.map(date => date.split(' ')[0]);
        this.brojGostiju = brojevi;

        this.barChartData.labels = this.daniKonobar;
        this.barChartData.datasets[0].data = this.brojGostiju;
      });


      this.restoraniS.restoranUKomeRadi(this.ulogovan.korisnicko_ime).subscribe(
        rest=>{
          if (rest != null){
            this.restoran = rest; 

            const zaposleniObservable = this.restoraniS.zaposleniURestoranu(this.restoran.naziv);
            console.log(zaposleniObservable)
            const imenaKonobara = zaposleniObservable.pipe(
              map(konobari => konobari.map(k => k.korisnicko_ime))
            );
            const ukupnoGostiju = imenaKonobara.pipe(
              switchMap(imena => forkJoin(imena.map(i => this.rezervacijeS.ukupanBrojGostijuZaKonobara(i))))
            )

            forkJoin([imenaKonobara,ukupnoGostiju]).subscribe(
              ([imen,ukup]) =>{
                this.zaposleni = imen;
                this.ukupnoGostijuZaKonob = ukup;

                this.pieChartData.labels = this.zaposleni;
                this.pieChartData.datasets[0].data = this.ukupnoGostijuZaKonob;
              }
            )
            
            const daniUNedelji = [0, 1, 2, 3, 4, 5, 6]; 
            forkJoin(
              daniUNedelji.map(dan=> this.rezervacijeS.prosecanBrojRezervacijaPoDanu(this.restoran.naziv,dan))
            ).subscribe(
              rez=>{
                this.rezervacije24Mes = rez.map(value => value / 104); 

                this.histogramChartData.datasets[0].data = this.rezervacije24Mes;
                this.daniUNedelji =  ['PON', 'UTO', 'SRE', 'ČET', 'PET', 'SUB', 'NED']
   
              }
            )
          }
        }
      )
      
    }
  }

  public pieChartOptions: ChartConfiguration<'pie'>['options'] = {
    responsive: true
  };

  public pieChartData: ChartConfiguration<'pie'>['data'] = {
    labels: [],
    datasets: [{
      data: [],
      label: 'Raspodela gostiju'
    }]
  };

  pieChartLegend = true;

  histogramChartOptions : ChartOptions = {
    responsive: true,
    scales: {
      x: {
        type: 'category',
      },
      y: {
        beginAtZero: true,
        stacked: true
      }
    },

  };
  histogramChartType = 'bar';
  histogramChartLegend = true;

  
  public histogramChartData: ChartConfiguration<'bar'>['data'] = {
    labels:  ['PON', 'UTO', 'SRE', 'ČET', 'PET', 'SUB', 'NED'],
    datasets: [
      { data: [], label: 'Prosecan broj rezervacija' , barPercentage: 1.0, categoryPercentage: 1.0}
    ]
  };

}
