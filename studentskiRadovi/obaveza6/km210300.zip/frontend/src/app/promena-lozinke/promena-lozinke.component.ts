import { Component } from '@angular/core';
import { KorisnikService } from '../servisi/korisnik.service';
import { Router } from '@angular/router';
import * as CryptoJS from 'crypto-js';


@Component({
  selector: 'app-promena-lozinke',
  templateUrl: './promena-lozinke.component.html',
  styleUrls: ['./promena-lozinke.component.css']
})
export class PromenaLozinkeComponent {

  constructor(private korisnikS:KorisnikService, private router:Router){}

  znaStaru:string = "";
  stara:string = "";
  nova:string = "";
  potvrdaNove:string = "";
  korIme:string = "";
  pitanje:string = "";
  odgovor: string = "";
  greska:string = "";
  korak2:boolean = false;
  korak3:boolean = false;

  korIme2:string = "";
  nova2:string = "";
  potvrdaNove2:string = "";
  greska2:string = "";

  promena1(){
    let regexLozinka = /^(?=[a-zA-Z])(?=.*\d)(?=.*[A-Z])(?=(?:.*[a-z]){3,})(?=.*[!@#$%^&*])[A-Za-z][A-Za-z\d!@#$%^&*]{6,10}$/;
    if (this.korIme == "") {
      this.greska = "Nije uneto korisnicko ime";
    }
    else{
      this.korisnikS.dohvatiKorisnika(this.korIme).subscribe(
        postoji=>{
          if (postoji == null){
            this.greska = "Ne postoji korisnik sa tim korisnickim imenom"
          }
          else{
            if (this.stara == "") {
              this.greska = "Nije uneta stara lozinka";
            }
            else if(this.nova == ""){
              this.greska = "Nije uneta nova lozinka";
            }
            else if(this.potvrdaNove == ""){
              this.greska = "Nije uneta potvrda nove lozinke";
            }
            else if (!regexLozinka.test(this.nova)){
              this.greska = "Nova lozinka nije u dobrom formatu"
            }
            else if (this.nova != this.potvrdaNove){
              this.greska = "Potvrda lozinke se razlikuje od unete nove lozinke";
            }
            else{  
              const hesiranaLozinka = CryptoJS.SHA256(this.stara).toString();
              this.korisnikS.prijava(this.korIme, hesiranaLozinka).subscribe(
                data=>{
                  if (data == null){
                    this.greska = "Netacna stara lozinka";
                  }
                  else{ 
                    const novaHesiranaLozinka = CryptoJS.SHA256(this.nova).toString();
                    this.korisnikS.promenaLozinke(this.korIme,novaHesiranaLozinka).subscribe(
                      p=>{
                        if (p > 0){
                          console.log(this.nova);
                          this.router.navigate(['']); //treba li nesto da sacuvam?
                        }
                      }
                    );
                  }
                }
              )
            }
          }
        }
      )
    }
   
  }

  sacuvanOdgovor:string = "";
  postaviPitanje(){ 
  
    this.korisnikS.dohvatiKorisnika(this.korIme2).subscribe(
      postoji=>{
        if (postoji == null){
          this.greska2 = "Ne postoji korisnik sa tim korisnickim imenom"
        }
        else{
          let p = localStorage.getItem("pitanjeKorisnika" + this.korIme2); 
          if (p != null){
            this.pitanje = p;
          }
          let o = localStorage.getItem("odgovorKorisnika" + this.korIme2);
          if (o != null){
            this.sacuvanOdgovor = o;
          }
          this.korak2 = true;
        }
      }
    )

  }

  dalje(){
    if (this.odgovor == this.sacuvanOdgovor){
      this.korak3 = true;
    }
    else{
      this.greska2 = "Netacan odgovor"
    }
  }

  promena2(){
    let regexLozinka = /^(?=[a-zA-Z])(?=.*\d)(?=.*[A-Z])(?=(?:.*[a-z]){3,})(?=.*[!@#$%^&*])[A-Za-z][A-Za-z\d!@#$%^&*]{6,10}$/;
    if(this.nova2 == ""){
      this.greska2 = "Nije uneta nova lozinka";
    }
    else if(this.potvrdaNove2 == ""){
      this.greska2 = "Nije uneta potvrda nove lozinke";
    }
    else if (!regexLozinka.test(this.nova2)){
      this.greska2 = "Nova lozinka nije u dobrom formatu"
    }
    else if (this.nova2 != this.potvrdaNove2){
      this.greska2 = "Unesenova nova lozinka se ne slaze sa njenom potvrdom";
    }
    else{  
      const hesiranaLozinka = CryptoJS.SHA256(this.nova2).toString();
      this.korisnikS.promenaLozinke(this.korIme2,hesiranaLozinka).subscribe(
        p=>{
          if (p > 0){
            this.router.navigate(['']); //treba li nesto da sacuvam?
          }
        }
      );
    }

  }
}
