import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { GostComponent } from './gost/gost.component';
import { KonobarComponent } from './konobar/konobar.component';
import { AdminComponent } from './admin/admin.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { RegistracijaComponent } from './registracija/registracija.component';
import { PromenaLozinkeComponent } from './promena-lozinke/promena-lozinke.component';
import { ProfilComponent } from './profil/profil.component';
import { RestoraniComponent } from './restorani/restorani.component';
import { DetaljiORestoranuComponent } from './detalji-o-restoranu/detalji-o-restoranu.component';
import { KorpaComponent } from './korpa/korpa.component';
import { DostaveKonobarComponent } from './dostave-konobar/dostave-konobar.component';
import { DostavaGostComponent } from './dostava-gost/dostava-gost.component';
import { AzuriranjeKorisnikaComponent } from './azuriranje-korisnika/azuriranje-korisnika.component';
import { RezervacijeKonobarComponent } from './rezervacije-konobar/rezervacije-konobar.component';
import { RezervacijeGostComponent } from './rezervacije-gost/rezervacije-gost.component';
import { StatistikaComponent } from './statistika/statistika.component'
import { NgChartsModule } from 'ng2-charts';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    GostComponent,
    KonobarComponent,
    AdminComponent,
    AdminLoginComponent,
    RegistracijaComponent,
    PromenaLozinkeComponent,
    ProfilComponent,
    RestoraniComponent,
    DetaljiORestoranuComponent,
    KorpaComponent,
    DostaveKonobarComponent,
    DostavaGostComponent,
    AzuriranjeKorisnikaComponent,
    RezervacijeKonobarComponent,
    RezervacijeGostComponent,
    StatistikaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgChartsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
