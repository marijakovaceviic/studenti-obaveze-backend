import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { RestoraniService } from '../servisi/restorani.service';
import { Restoran } from '../modeli/restoran';
import { KorisnikService } from '../servisi/korisnik.service';
import { Korisnik } from '../modeli/korisnik';
import * as CryptoJS from 'crypto-js';
import { Router } from '@angular/router';
import { TimeInterval, timeInterval } from 'rxjs/internal/operators/timeInterval';

interface Element {
  x: number;
  y: number;
  sirina: number;
  visina:number;
  precnik:number;
  maksBrLjudi: number;
}


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit{

  constructor(private restoraniS:RestoraniService, private korisniciS:KorisnikService, private ruter:Router){}

  sviRestorani:Restoran[] = [];
  sviKorisnici:Korisnik[] = [];
  sviZahtevi:Korisnik[] = [];
  konobari:Korisnik[] = [];
  gosti:Korisnik[] = [];

  nazivRestorana:string = "";
  adresaRestorana:string = "";
  tipRestorana:string = "";
  opisRestorana:string = "";
  kontaktRestorana:string = "";

  konobarRestoran:string = "";
  konobarKorIme:string = "";
  konobarLozinka: string = "";
  konobarIme: string = "";
  konobarPrezime: string = "";
  konobarPol: string = "";
  konobarAdresa: string = "";
  konobarTelefon: string = "";
  konobarEmail: string = "";
  konobarBrKartice:string = "";
  pitanje:string = "";
  odgovor:string = "";
  greskaKonobar: string = "";
  izabranaSlika:boolean = false;
  dodataSlika!: File;

  daniUNedelji: string[] = ['ponedeljak', 'utorak', 'sreda', 'cetvrtak', 'petak', 'subota', 'nedelja'];
 

  ngOnInit(): void {
    
    this.korisniciS.sviKorisnici().subscribe(
      registrovani=>{
        this.sviKorisnici = registrovani;

        this.konobari = this.sviKorisnici.filter(k =>
          k.tip != 'gost'
        )

        this.gosti = this.sviKorisnici.filter(k =>
          k.tip != 'konobar'
        )
      }
    );

    this.korisniciS.sviZahtevi().subscribe(
      zahtevi=>{
        this.sviZahtevi = zahtevi;
      }
    )

    this.restoraniS.sviRestorani().subscribe(
      data=>{
        this.sviRestorani = data;
      }
    )
  }

  dodavanjeRestorana(){
    this.restoraniS.dodavanje(this.nazivRestorana,this.adresaRestorana,this.tipRestorana,this.opisRestorana,this.kontaktRestorana).subscribe(
      data=>{
        if (data > 0){
          this.nazivRestorana= "";
          this.adresaRestorana = "";
          this.tipRestorana = "";
          this.opisRestorana = "";
          this.kontaktRestorana = "";
        }
      }
    )
  }

  dodajGosta(gost:Korisnik){
    this.korisniciS.dodajKorisnika(gost).subscribe(
      status=>{
        if (status > 0){
          this.korisniciS.ukloniZahtev(gost.korisnicko_ime).subscribe(
            s=>{
              if (s >0){
                this.ngOnInit();
              }
            }
          );
        }
      }
    )
  }

  odbaciGosta(gost:Korisnik){
    this.korisniciS.zapamtiOdbijene(gost.korisnicko_ime,gost.email).subscribe(
      stat=>{
        if (stat > 0){
          this.korisniciS.ukloniZahtev(gost.korisnicko_ime).subscribe(
            s=>{
              if (s >0){
                this.korisniciS.sviZahtevi().subscribe(
                  zahtevi=>{
                    this.sviZahtevi = zahtevi;
                  }
                )
              }
            }
          )
        }
      }
    )
  }

  dodajKonobara(){
    this.greskaKonobar = "";
    if (this.konobarPol == ""){
      this.greskaKonobar = "Nije izabran pol";
    }
    else{
      let regexLozinka = /^(?=[a-zA-Z])(?=.*\d)(?=.*[A-Z])(?=(?:.*[a-z]){3,})(?=.*[!@#$%^&*])[A-Za-z][A-Za-z\d!@#$%^&*]{6,10}$/;
      
      let regexBrKartice = /^(\d{16}|\d{4} \d{4} \d{4} \d{4})$/;

      let regexTelefon = /^06\d\s?\d{4}\s?\d{3}$/;

      let regexEmail = /^[a-z][a-z0-9._%+-]*@[a-z0-9.-]+\.[a-z]{2,}$/;

      if(!regexLozinka.test(this.konobarLozinka)){
        this.greskaKonobar = "Lozinka mora pocinjati slovom i mora imati od 6 do 10 karaktera, od toga bar jedno veliko slovo, tri mala, jedan broj i jedan specijalni karakter"
      }
      else if(!regexBrKartice.test(this.konobarBrKartice)){
        this.greskaKonobar = "Broj kreditne kartice mora biti u formatu xxxx xxxx xxxx xxxx ili xxxxxxxxxxxxxxxx"
      }
      else if(!regexTelefon.test(this.konobarTelefon)){
        this.greskaKonobar = "Broj telefona mora biti u formatu 06x xxxx xxx ili 06x xxxxxxx ili 06xxxxxxxx"
      }
      else if(!regexEmail.test(this.konobarEmail)){
        this.greskaKonobar = "Email nije u odgovarajucem formatu"
      }
      else{
        this.restoraniS.dohvatiRestoran(this.konobarRestoran).subscribe(
          ima=>{
            if (ima != null){
              
              this.korisniciS.odbijenaKorImena().subscribe(
                odb=>{
                  if (odb.includes(this.konobarKorIme)){
                    this.greskaKonobar = "Uneto korisnicko ime je odbijeno i ne moze se koristiti"
                  }
                  else{
                    this.korisniciS.odbijeniEmailovi().subscribe(
                      odbEm=>{
                        if (odbEm.includes(this.konobarEmail)){
                          this.greskaKonobar = "Uneta email adresa je odbijena i ne moze se koristiti"
                        }
                        else{
                          const hesiranaLozinka = CryptoJS.SHA256(this.konobarLozinka).toString();
                          let konobar = new Korisnik();
                          konobar.korisnicko_ime = this.konobarKorIme;
                          konobar.lozinka = hesiranaLozinka;
                          konobar.tip = "konobar";
                          konobar.ime = this.konobarIme;
                          konobar.prezime = this.konobarPrezime;
                          konobar.adresa = this.konobarAdresa;
                          konobar.pol = this.konobarPol;
                          konobar.telefon = this.konobarTelefon;
                          konobar.email = this.konobarEmail;
                          konobar.broj_kartice = this.konobarBrKartice;
                          konobar.slika = "";

                          this.korisniciS.dodajKorisnika(konobar).subscribe(
                            data=>{
                              if(data > 0){
                                if (this.izabranaSlika){
                
                                  const formData = new FormData();
                                  formData.append('slika',this.dodataSlika);
                                  this.korisniciS.dodavanjeProfilneSlikeKonobar(this.konobarKorIme,formData).subscribe()
                                }
                                else{
                                  this.korisniciS.postavljanjePodrazumevaneProfilneKonobar(this.konobarKorIme).subscribe()
                                }
                
                                localStorage.setItem("pitanjeKorisnika" + this.konobarKorIme, this.pitanje); 
                                localStorage.setItem("odgovorKorisnika" + this.konobarKorIme, this.odgovor);
                                
                                this.restoraniS.dodavanjeKonobara(this.konobarRestoran,this.konobarKorIme).subscribe()
                              }
                              else {
                                this.greskaKonobar =  "Korisnicko ime i email moraju biti jedinstveni";
                              }
                            }
                          )
                        }
                      }
                    )
                  }
                }
              )              
            }
            else{
              this.greskaKonobar = "Uneti restoran ne postoji";
            }
          }
        )
      }
    }
  }

  sacuvajSliku(event: any){
   
    this.dodataSlika = event.target.files[0];
    if (this.dodataSlika && (this.dodataSlika.type == 'image/jpeg' || this.dodataSlika.type == 'image/png')) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const img = new Image(); 
        img.onload = () => {
          if (img.width >= 100 && img.width <= 300 && img.height >= 100 && img.height <= 300) {
            this.izabranaSlika = true;
          }
          else{
            this.greskaKonobar = "Izabrana slika nije u odgovarajucih dimenzija"
          }
        };
        img.src = e.target.result;
      };

      reader.readAsDataURL(this.dodataSlika);
    }
    else{
      this.greskaKonobar = "Izabrana slika nije u odgovarajucem formatu fajla"
    }
  }

  azuriraj(korisnik:Korisnik){
    localStorage.setItem("azuriranje",JSON.stringify(korisnik));
    this.ruter.navigate(['/azuriranje']);
  }

  postaviRadnoVreme(restoran:Restoran){
    this.restoraniS.dodavanjeRadnogVremena(restoran.naziv,restoran.radi_od,restoran.radi_do,restoran.izabranDan).subscribe(

    )
  }

  nazivRestoranaCanvas : string = ""
  dodajRaspored(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const fajl = input.files[0];
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target && e.target.result) {
          const sadrzajFajla = e.target.result as string;
          const raspored = JSON.parse(sadrzajFajla).raspored;
          const imeRest = JSON.parse(sadrzajFajla).restoran;
          this.nazivRestoranaCanvas= imeRest;

          raspored.kuhinje.forEach((kuhinja:Element)=>{
            this.restoraniS.cuvanjElementaRasporeda(imeRest,"kuhinja",kuhinja.x,kuhinja.y,kuhinja.sirina,kuhinja.visina,0,0).subscribe(

            )
          })

          raspored.toaleti.forEach((toalet:Element)=>{
            this.restoraniS.cuvanjElementaRasporeda(imeRest,"toalet",toalet.x,toalet.y,toalet.sirina,toalet.visina,0,0).subscribe(

            )
          })

          raspored.stolovi.forEach((sto:Element)=>{
            this.restoraniS.cuvanjElementaRasporeda(imeRest,"sto",sto.x,sto.y,0,0,sto.precnik,sto.maksBrLjudi).subscribe(

            )
          })  

          this.crtanjeRasporeda(raspored);
        }
      };
      reader.readAsText(fajl);
    }
  }

  @ViewChild('canvas', { static: true }) canvas!: ElementRef<HTMLCanvasElement>;
  crtanjeRasporeda(raspored: any): void {
    const canvas = this.canvas.nativeElement;
    const ctx = canvas.getContext('2d');

    if (ctx) {
     
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      ctx.strokeStyle = 'black';
      ctx.lineWidth = 2;
      ctx.strokeRect(5, 5, canvas.width - 10, canvas.height - 10);

      ctx.fillStyle = '#e3dac9'; 
      ctx.fillRect(20, 10, 250, 40);
      ctx.strokeStyle = 'black';
      ctx.strokeRect(20, 10, 250, 40);

      ctx.font = '20px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = 'black';
      ctx.fillText(this.nazivRestoranaCanvas, 145, 30);

      ctx.strokeStyle = 'black';
      ctx.lineWidth = 2;
      ctx.strokeRect(20, 70, canvas.width - 40, canvas.height - 90);

      ctx.fillStyle = 'brown';
      ctx.strokeStyle = 'black';
      raspored.kuhinje.forEach((kuhinja: Element) => {
        ctx.strokeRect(kuhinja.x, kuhinja.y, kuhinja.sirina, kuhinja.visina);
        ctx.font = '16px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('Kuhinja', kuhinja.x + kuhinja.sirina / 2, kuhinja.y + kuhinja.visina / 2);
      });

      ctx.fillStyle = 'brown';
      ctx.strokeStyle = 'black';
      raspored.toaleti.forEach((toalet: Element) => {
        ctx.strokeRect(toalet.x, toalet.y, toalet.sirina, toalet.visina);
        ctx.font = '16px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('Toalet', toalet.x + toalet.sirina / 2, toalet.y + toalet.visina / 2);
      });

      ctx.fillStyle = 'brown';
      ctx.strokeStyle = 'black';
      raspored.stolovi.forEach((sto: Element) => {
        ctx.beginPath();
        ctx.arc(sto.x, sto.y, sto.precnik, 0, 2 * Math.PI);
        ctx.stroke();
        ctx.closePath();
        ctx.font = '16px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(sto.maksBrLjudi.toString(), sto.x, sto.y);
      });
    } else {
      
    }
  }

  logout(){
    localStorage.removeItem('ulogovan');
  }

  restoranJelovnik:string = "";
  nazivJela:string = "";
  cenaJela:number = 0;
  sastojci:string = "";
  dodavanjeJelovnika(){
    this.restoraniS.dodavanjeJela(this.restoranJelovnik,this.nazivJela,"",this.cenaJela,this.sastojci).subscribe(
      data=>{
        if(data > 0){
          if (this.izabranaSlikaJela){

            const formData = new FormData();
            formData.append('slika',this.dodataSlikaJela);
            this.restoraniS.dodavanjeSlikeJela(this.restoranJelovnik,this.nazivJela,formData).subscribe()
          }
        }
      }
    )
  }

  izabranaSlikaJela:boolean = false;
  dodataSlikaJela!: File;
  greskaJelovnik:string="";
  sacuvajSlikuJela(event: any){
   
    this.dodataSlikaJela = event.target.files[0];
    if (this.dodataSlikaJela && (this.dodataSlikaJela.type == 'image/jpeg' || this.dodataSlikaJela.type == 'image/png')) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const img = new Image(); 
        img.onload = () => {
          if (img.width >= 100 && img.width <= 300 && img.height >= 100 && img.height <= 300) {
            this.izabranaSlikaJela = true;
          }
          else{
            this.greskaJelovnik = "Izabrana slika nije u odgovarajucih dimenzija"
          }
        };
        img.src = e.target.result;
      };

      reader.readAsDataURL(this.dodataSlikaJela);
    }
    else{
      this.greskaJelovnik = "Izabrana slika nije u odgovarajucem formatu fajla"
    }
  }
}
