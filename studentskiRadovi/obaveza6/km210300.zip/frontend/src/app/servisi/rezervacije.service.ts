import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Rezervacija } from '../modeli/rezervacija';
import { forkJoin } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RezervacijeService {

  constructor(private http:HttpClient) { }

  url = 'http://localhost:8080/rezervacije';

  neradniDani(restoran:string){
    return this.http.get<string[]>(`${this.url}/neradniDani/${restoran}`);
  }

  novaRezervacija(restoran:string,gost:string,datum:string,broj_osoba:number,opis:string,status:string){
    const data={
      restoran:restoran,
      gost:gost,
      datum:datum,
      broj_osoba:broj_osoba,
      opis:opis,
      status:status
    }
    return this.http.post<number>(`${this.url}/novaRezervacija`,data)
  }

  slobodanSto(restoran:string,gost:string,datum:string,broj_osoba:number){
    const data={
      restoran:restoran,
      gost:gost,
      datum:datum,
      broj_osoba:broj_osoba
    }
    return this.http.post<number>(`${this.url}/slobodanSto`,data)
  }

  rezervacijeUPoslednjih24h(){
    return this.http.get<number>(`${this.url}/uPoslednjih24h`);
  }

  rezervacijeUPoslednjih7dana(){
    return this.http.get<number>(`${this.url}/uPoslednjih7dana`);
  }

  rezervacijeUPoslednjihMesecDana(){
    return this.http.get<number>(`${this.url}/uPoslednjihMesecDana`);
  }

  neobradjeneRezervacije(restoran:string){
    return this.http.get<Rezervacija[]>(`${this.url}/neobradjeneRezervacije/${restoran}`);
  }

  postaviStatus(rezervacija:Rezervacija){
    return this.http.post<number>(`${this.url}/postaviStatus`,rezervacija);
  }

  aktuelneRezervacije(gost:string){
    return this.http.get<Rezervacija[]>(`${this.url}/aktuelneRezervacije/${gost}`);
  }

  istekleRezervacije(gost:string){
    return this.http.get<Rezervacija[]>(`${this.url}/istekleRezervacije/${gost}`);
  }

  zaduzenjeKonobara(konobar:string){
    return this.http.get<Rezervacija[]>(`${this.url}/zaduzenjeKonobara/${konobar}`);
  }

  gostDosao(rezervacija:Rezervacija){
    return this.http.post<number>(`${this.url}/gostDosao`,rezervacija);
  }

  daniZaKonobara(konobar:string){
    return this.http.get<string[]>(`${this.url}/daniZaKonobara/${konobar}`);
  }

  brojGostijuZaKonobara(konobar:string, datum:string){
    const data={
      konobar:konobar,
      datum:datum
    }
    return this.http.post<number>(`${this.url}/brojGostijuZaKonobara`,data);
  }

  ukupanBrojGostijuZaKonobara(konobar:string){
    return this.http.get<number>(`${this.url}/ukupanBrojGostijuZaKonobara/${konobar}`);
  }

  uPoslednjih24Meseca(restoran:string){
    return this.http.get<Rezervacija[]>(`${this.url}/uPoslednjih24Meseca/${restoran}`);
  }

  
  prosecanBrojRezervacijaPoDanu(restoran:string,dan:number){
    return this.http.get<number>(`${this.url}/prosecanBrojRezervacijaPoDanu/${restoran}/${dan}`);
  }

  zauzetiStolovi(rezervacija:Rezervacija){
    return this.http.post<number[]>(`${this.url}/zauzetiStolovi`,rezervacija);
  }


}
