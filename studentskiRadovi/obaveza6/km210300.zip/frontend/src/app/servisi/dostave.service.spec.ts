import { TestBed } from '@angular/core/testing';

import { DostaveService } from './dostave.service';

describe('DostaveService', () => {
  let service: DostaveService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DostaveService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
