import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Jelo } from '../modeli/jelo';

@Injectable({
  providedIn: 'root'
})
export class NarudzbineService {

  constructor(private http:HttpClient) { }

  url = 'http://localhost:8080/narudzbine';

  jelovnikRestorana(restoran:string){
    return this.http.get<Jelo[]>(`${this.url}/jelovnik/${restoran}`);
  }
}
