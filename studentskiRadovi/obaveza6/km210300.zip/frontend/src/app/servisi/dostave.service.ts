import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Dostava } from '../modeli/dostava';

@Injectable({
  providedIn: 'root'
})
export class DostaveService {

  constructor(private http:HttpClient) { }

  url = 'http://localhost:8080/dostave';

  novaDostava(restoran:string,gost:string,iznos:number){
    //let vreme = new Date(); 
    const data={
      restoran:restoran,
      gost:gost,
      iznos:iznos,
      //vreme_narucivanja: new Date(),
      status:"u obradi"
    }
    return this.http.post<number>(`${this.url}/nova`,data);
  }

  trenutneNarudzbine(restoran:string){
    return this.http.get<Dostava[]>(`${this.url}/trenutne/${restoran}`);
  }

  potvrdiIliOdbaci(d:Dostava){
    return this.http.post<number>(`${this.url}/potvrdiIliOdbaci`,d);
  }

  postaviVremeDostave(d:Dostava){
    return this.http.post<number>(`${this.url}/postaviVremeDostave`,d);
  }

  dostaveZaGosta(gost:string){
    return this.http.get<Dostava[]>(`${this.url}/zaGosta/${gost}`);
  }
  
}
