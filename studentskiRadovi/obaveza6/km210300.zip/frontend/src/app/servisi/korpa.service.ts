import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { JeloZaKorpu } from '../modeli/jeloZaKorpu';

@Injectable({
  providedIn: 'root'
})
export class KorpaService {

  constructor(private http:HttpClient) { }

  url = 'http://localhost:8080/korpa';

  dodavanje(gost: string, restoran: string, jelo:string, kolicina:number,cena:number) {
    const data = {
      gost: gost,
      restoran: restoran,
      naziv_jela:jelo,
      kolicina:kolicina,
      cena:cena
    };
    return this.http.post<number>(`${this.url}/dodavanje`, data);
  }

  dohvatiSadrzaj(gost:string,restoran:string){
    return this.http.get<JeloZaKorpu[]>(`${this.url}/dohvatiSadrzaj/${gost}/${restoran}`);
  }

  izmenaKorpe(gost: string, restoran: string, jelo:string, kolicina:number) {
    const data = {
      gost: gost,
      restoran: restoran,
      naziv_jela:jelo,
      kolicina:kolicina
    };
    return this.http.post<number>(`${this.url}/izmenaKorpe`, data);
  }

  potvrdaPorudzbine(gost:string,restoran:string){
    return this.http.get<number>(`${this.url}/potvrdaPorudzbine/${gost}/${restoran}`);
  }
}
