import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Korisnik } from '../modeli/korisnik';

@Injectable({
  providedIn: 'root'
})
export class KorisnikService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:8080/korisnici';

  prijava(username: string, password: string) {
    const data = {
      korisnicko_ime: username,
      lozinka: password
    };
    return this.http.post<Korisnik>(`${this.url}/prijava`, data);
  }

  promenaLozinke(username: string, password: string) {
    const data = {
      korisnicko_ime: username,
      lozinka: password
    };
    return this.http.post<number>(`${this.url}/promenaLozinke`, data);
  }

  brojRegistrovanihGostiju(){
    return this.http.get<number>(`${this.url}/brojRegistrovanihGostiju`);
  }

  registracijaGosta(username:string, password:string, ime:string, prezime:string, tip:string,pol:string,adresa:string,telefon:string,email:string,brKartice:string){
    const data={
      korisnicko_ime:username,
      lozinka:password,
      ime:ime,
      prezime:prezime,
      tip:tip,
      pol:pol,
      adresa:adresa,
      telefon:telefon,
      email:email,
      broj_kartice:brKartice
    }
    return this.http.post<number>(`${this.url}/registracijaGosta`, data);
  }

  dodavanjeProfilneSlike(username:string, profilna:FormData){
    return this.http.post<number>(`${this.url}/dodavanjeProfilneSlike/${username}`, profilna);
  }

  postavljanjePodrazumevaneProfilne(username:string){
    return this.http.get<number>(`${this.url}/podrazumevanaProfilna/${username}`);
  }

  azurirajIme(ime:string, korIme:string){
    return this.http.get<number>(`${this.url}/promenaImena/${ime}/${korIme}`);
  }

  azurirajPrezime(prezime:string, korIme:string){
    return this.http.get<number>(`${this.url}/promenaPrezimena/${prezime}/${korIme}`);
  }

  azurirajAdresu(adresa:string, korIme:string){
    return this.http.get<number>(`${this.url}/promenaAdrese/${adresa}/${korIme}`);
  }

  azurirajEmail(email:string, korIme:string){
    return this.http.get<number>(`${this.url}/promenaEmaila/${email}/${korIme}`);
  }

  azurirajTelefon(telefon:string, korIme:string){
    return this.http.get<number>(`${this.url}/promenaTelefona/${telefon}/${korIme}`);
  }

  promenaProfilneSlike(username:string, profilna:FormData){
    return this.http.post<number>(`${this.url}/promenaProfilneSlike/${username}`, profilna);
  }

  sviKorisnici(){
    return this.http.get<Korisnik[]>(`${this.url}/sviKorisnici`);
  }

  sviZahtevi(){
    return this.http.get<Korisnik[]>(`${this.url}/sviZahtevi`);
  }

  dodajKorisnika(korisnik:Korisnik){
    return this.http.post<number>(`${this.url}/dodavanjeGosta`, korisnik);
  }

  ukloniZahtev(korIme:string){
    return this.http.get<number>(`${this.url}/uklanjanjeZahteva/${korIme}`);
  }

  zapamtiOdbijene(korIme:string, email:string){
    return this.http.get<number>(`${this.url}/zapamtiOdbijene/${korIme}/${email}`);
  }

  dohvatiKorisnika(korIme:string){
    return this.http.get<Korisnik>(`${this.url}/dohvatiKorisnika/${korIme}`);
  }

  dodavanjeProfilneSlikeKonobar(username:string, profilna:FormData){
    return this.http.post<number>(`${this.url}/dodavanjeProfilneSlikeKonobar/${username}`, profilna);
  }

  postavljanjePodrazumevaneProfilneKonobar(username:string){
    return this.http.get<number>(`${this.url}/podrazumevanaProfilnaKonobar/${username}`);
  }

  azuriranjePodataka(k:Korisnik){
    return this.http.post<number>(`${this.url}/azuriranjePodataka`, k);
  }

  odbijenaKorImena(){
    return this.http.get<string[]>(`${this.url}/odbijenaKorImena`);
  }

  odbijeniEmailovi(){
    return this.http.get<string[]>(`${this.url}/odbijeniEmailovi`);
  }

}
