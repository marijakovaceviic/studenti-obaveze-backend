import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Restoran } from '../modeli/restoran';
import { Korisnik } from '../modeli/korisnik';
import { Raspored } from '../modeli/raspored';

@Injectable({
  providedIn: 'root'
})
export class RestoraniService {

  constructor(private http:HttpClient) { }

  url = 'http://localhost:8080/restorani';

  brojRestorana(){
    return this.http.get<number>(`${this.url}/brojRestorana`);
  }

  sviRestorani(){
    return this.http.get<Restoran[]>(`${this.url}/sviRestorani`);
  }

  sortirajRastucePoNazivu(restorani:Restoran[]){
    return restorani.sort((r1,r2)=>{
      if (r1.naziv < r2.naziv) {
        return -1;
      }
      if (r1.naziv > r2.naziv) {
        return 1;
      }
      return 0;
    })
  }

  sortirajOpadajucePoNazivu(restorani:Restoran[]){
    return restorani.sort((r1,r2)=>{
      if (r1.naziv < r2.naziv) {
        return 1;
      }
      if (r1.naziv > r2.naziv) {
        return -1;
      }
      return 0;
    })
  }

  sortirajRastucePoAdresi(restorani:Restoran[]){
    return restorani.sort((r1,r2)=>{
      if (r1.adresa < r2.adresa) {
        return -1;
      }
      if (r1.adresa > r2.adresa) {
        return 1;
      }
      return 0;
    })
  }

  sortirajOpadajucePoAdresi(restorani:Restoran[]){
    return restorani.sort((r1,r2)=>{
      if (r1.adresa < r2.adresa) {
        return 1;
      }
      if (r1.adresa > r2.adresa) {
        return -1;
      }
      return 0;
    })
  }

  sortirajRastucePoTipu(restorani:Restoran[]){
    return restorani.sort((r1,r2)=>{
      if (r1.tip < r2.tip) {
        return -1;
      }
      if (r1.tip > r2.tip) {
        return 1;
      }
      return 0;
    })
  }

  sortirajOpadajucePoTipu(restorani:Restoran[]){
    return restorani.sort((r1,r2)=>{
      if (r1.tip < r2.tip) {
        return 1;
      }
      if (r1.tip > r2.tip) {
        return -1;
      }
      return 0;
    })
  }

  rezultatPretrage:Restoran[] = [];

  pretraga(restorani:Restoran[], naziv:string,adresa:string,tip:string){
    this.rezultatPretrage = restorani;
    if (naziv != ""){
      this.rezultatPretrage = restorani.filter(
        restoran=> restoran.naziv.toLowerCase().includes(naziv.toLowerCase())
      );
    }
    if (adresa != ""){
      this.rezultatPretrage = this.rezultatPretrage.filter(
        restoran=> restoran.adresa.toLowerCase().includes(adresa.toLowerCase())
      );
    }
    if (tip != ""){
      this.rezultatPretrage = this.rezultatPretrage.filter(
        restoran=> restoran.tip.toLowerCase().includes(tip.toLowerCase())
      );
    }
    return this.rezultatPretrage;
    
  }

  dodavanje(naziv:string,adresa:string,tip:string,opis:string,telefon:string){
    const data={
      naziv:naziv,
      adresa:adresa,
      tip:tip,
      opis:opis,
      telefon:telefon
    }
    return this.http.post<number>(`${this.url}/dodavanje`,data)
  }

  dohvatiRestoran(naziv:string){
    return this.http.get<Restoran>(`${this.url}/dohvatiRestoran/${naziv}`);
  }

  dodavanjeKonobara(restoran:String,korIme:string){
    const data={
      restoran:restoran,
      korisnicko_ime:korIme
    }
    return this.http.post<number>(`${this.url}/dodavanjeKonobara`,data);
  }

  restoranUKomeRadi(konobar:string){
    return this.http.get<Restoran>(`${this.url}/restoranUKomeRadi/${konobar}`);
  }

  zaposleniURestoranu(restoran:string){
    return this.http.get<Korisnik[]>(`${this.url}/zaposleniURestoranu/${restoran}`);
  }

  dodavanjeRadnogVremena(restoran:string,radi_od:string,radi_do:string,dan:string){
    const data={
      naziv:restoran,
      radi_od:radi_od,
      radi_do:radi_do,
      dan:dan
    }
    return this.http.post<number>(`${this.url}/dodavanjeRadnogVremena`,data)
  }

  dohvatiRadnoVreme(restoran:string,dan:string){
    return this.http.get<string[]>(`${this.url}/dohvatiRadnoVreme/${restoran}/${dan}`);
  }

  cuvanjElementaRasporeda(restoran:string,element:string,x:number,y:number,sirina:number,visina:number,precnik:number,brOsoba:number){
    const data={
      restoran:restoran,
      element:element,
      x:x,
      y:y,
      sirina:sirina,
      visina:visina,
      precnik:precnik,
      brOsoba:brOsoba
    }
    return this.http.post<number>(`${this.url}/dodavanjeElemntaRasporeda`,data)

  }

  dohvatiRaspored(restoran:string){
    return this.http.get<Raspored[]>(`${this.url}/dohvatiRaspored/${restoran}`);
  }

  dodavanjeJela(restoran:string,naziv:string,slika:string,cena:number,sastojci:string){
    const data={
      restoran:restoran,
      naziv:naziv,
      slika:slika,
      cena:cena,
      sastojci:sastojci
    }
    return this.http.post<number>(`${this.url}/dodavanjeJela`,data)
  }

  dodavanjeSlikeJela(restoran:string, naziv:string, slika:FormData){
    return this.http.post<number>(`${this.url}/dodavanjeSlikeJela/${restoran}/${naziv}`, slika);
  }


}
