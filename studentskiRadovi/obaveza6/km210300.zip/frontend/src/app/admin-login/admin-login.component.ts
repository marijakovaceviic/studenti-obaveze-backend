import { Component } from '@angular/core';
import { KorisnikService } from '../servisi/korisnik.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent {

  constructor(private korisnikS:KorisnikService, private router:Router){}

  username: string = "";
  password: string = "";
  greska: string = "";

  login(){
    if (this.username == "") {
      this.greska = "Nije uneto korisnicko ime";
    }
    else if (this.password == "") {
      this.greska = "Nije uneta lozinka";
    }
    else{
      this.korisnikS.prijava(this.username,this.password).subscribe(
        data=>{
          if (data == null) {
            this.greska = 'Takav korisnik ne postoji u bazi';
          } else {
            localStorage.setItem('ulogovan', JSON.stringify(data));
            this.router.navigate(['/admin']);
          }
        }
      )
    }
  }

  promenaLozinke(){
    this.router.navigate(['/promenaLozinke'])
  }
}
