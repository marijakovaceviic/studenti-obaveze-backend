import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-gost',
  templateUrl: './gost.component.html',
  styleUrls: ['./gost.component.css']
})
export class GostComponent  {
  constructor(private router:Router){}

  logout(){
    localStorage.removeItem('ulogovan');
    this.router.navigate(['']);
  }

}
