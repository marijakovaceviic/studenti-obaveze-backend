import { CanActivateFn } from '@angular/router';
import { Korisnik } from '../modeli/korisnik';

export const gostiGuard: CanActivateFn = (route, state) => {
  const ulogovanJson = localStorage.getItem("ulogovan");

  if (ulogovanJson != null) {
    const ulogovan: Korisnik = JSON.parse(ulogovanJson);

    if (ulogovan.tip == 'gost') {
      return true;
    }
  }

  alert("Nemate pristup")
  return false;
};
