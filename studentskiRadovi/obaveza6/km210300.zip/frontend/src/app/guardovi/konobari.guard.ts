import { CanActivateFn } from '@angular/router';
import { Korisnik } from '../modeli/korisnik';

export const konobariGuard: CanActivateFn = (route, state) => {
  const ulogovanJson = localStorage.getItem("ulogovan");

  if (ulogovanJson != null) {
    const ulogovan: Korisnik = JSON.parse(ulogovanJson);

    if (ulogovan.tip == 'konobar') {
      return true;
    }
  }

  alert("Nemate pristup")
  return false;
};
