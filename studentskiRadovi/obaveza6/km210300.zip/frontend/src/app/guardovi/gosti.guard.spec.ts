import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';

import { gostiGuard } from './gosti.guard';

describe('gostiGuard', () => {
  const executeGuard: CanActivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => gostiGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
