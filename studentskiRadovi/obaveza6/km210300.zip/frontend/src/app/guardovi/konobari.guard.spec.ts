import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';

import { konobariGuard } from './konobari.guard';

describe('konobariGuard', () => {
  const executeGuard: CanActivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => konobariGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
