import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';

import { profiliGuard } from './profili.guard';

describe('profiliGuard', () => {
  const executeGuard: CanActivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => profiliGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
