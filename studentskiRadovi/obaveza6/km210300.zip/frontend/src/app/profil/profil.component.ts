import { Component, OnInit } from '@angular/core';
import { Korisnik } from '../modeli/korisnik';
import { KorisnikService } from '../servisi/korisnik.service';

@Component({
  selector: 'app-profil',
  templateUrl: './profil.component.html',
  styleUrls: ['./profil.component.css']
})
export class ProfilComponent implements OnInit {

  constructor(private korisnikS:KorisnikService){}
  ulogovan:Korisnik = new Korisnik();
  slika:string="";

  promenaImena:boolean = false;
  novoIme:string = "";
  greskaIme:string = "";
  promenaPrezimena:boolean = false;
  novoPrezime:string = "";
  greskaPrezime:string = "";
  promenaAdrese:boolean = false;
  novaAdresa:string = "";
  greskaAdresa:string = "";
  promenaEmaila:boolean = false;
  noviEmail:string = "";
  greskaEmail:string = "";
  promenaTelefona:boolean = false;
  noviTelefon:string = "";
  greskaTelefon:string = "";

  ngOnInit(): void {
    let x = localStorage.getItem("ulogovan");
    if (x != null) {
      this.ulogovan = JSON.parse(x);

      this.korisnikS.prijava(this.ulogovan.korisnicko_ime,this.ulogovan.lozinka).subscribe(
        data=>{
          if(data != null){
            this.ulogovan = data;

            this.slika = "assets/" + this.ulogovan.slika;
          }
        }
      )
      //this.slika = "assets/" + this.ulogovan.slika;
    }
  }

  azurirajIme(){
    this.greskaIme = "";
    if(this.novoIme == ""){
      this.greskaIme = "Morate uneti novo ime";
    }
    else{
      this.korisnikS.azurirajIme(this.novoIme,this.ulogovan.korisnicko_ime).subscribe(
        data=>{
          if (data >0){
            this.promenaImena = false;
            //this.ulogovan.ime = this.novoIme;
            this.novoIme = "";
            this.ngOnInit();
          }
        }
      );
    }
  }
  
  azurirajPrezime(){
    this.greskaPrezime = "";
    if(this.novoPrezime == ""){
      this.greskaPrezime = "Morate uneti novo prezime";
    }
    else{
      this.korisnikS.azurirajPrezime(this.novoPrezime,this.ulogovan.korisnicko_ime).subscribe(
        data=>{
          if (data >0){
            this.promenaPrezimena = false;
            //this.ulogovan.prezime = this.novoPrezime;
            this.novoPrezime = "";
            this.ngOnInit();
          }
        }
      );
    }
  }

  azurirajAdresu(){
    this.greskaAdresa = "";
    if(this.novaAdresa == ""){
      this.greskaAdresa = "Morate uneti novu adresu";
    }
    else{
      this.korisnikS.azurirajAdresu(this.novaAdresa,this.ulogovan.korisnicko_ime).subscribe(
        data=>{
          if (data >0){
            this.promenaAdrese = false;
           // this.ulogovan.adresa = this.novaAdresa;
            this.novaAdresa = "";
            this.ngOnInit();
          }
        }
      );
    }
  }
  azurirajEmail(){
    this.greskaEmail = "";
    let regexEmail = /^[a-z][a-z0-9._%+-]*@[a-z0-9.-]+\.[a-z]{2,}$/;

    if(this.noviEmail == ""){
      this.greskaEmail = "Morate uneti novu email adresu";
    }
    else if(!regexEmail.test(this.noviEmail)){
      this.greskaEmail = "Email nije u dobrom formatu"
    }
    else{
      this.korisnikS.azurirajEmail(this.noviEmail,this.ulogovan.korisnicko_ime).subscribe(
        data=>{
          if (data >0){
            this.promenaEmaila = false;
            //this.ulogovan.email = this.noviEmail;
            this.noviEmail = "";
            this.ngOnInit();
          }
        }
      );
    }
  }

  azurirajTelefon(){
    let regexTelefon = /^06\d\s?\d{4}\s?\d{3}$/;
    this.greskaTelefon = "";
    if(this.noviTelefon == ""){
      this.greskaTelefon = "Morate uneti novi broj telefona";
    }
    else if(!regexTelefon.test(this.noviTelefon)){
      this.greskaTelefon = "Broj telefona mora biti u formatu 06x xxxx xxx ili 06x xxxxxxx ili 06xxxxxxxx"
    }
    else{
      this.korisnikS.azurirajTelefon(this.noviTelefon,this.ulogovan.korisnicko_ime).subscribe(
        data=>{
          if (data >0){
            this.promenaTelefona = false;
            //this.ulogovan.telefon = this.noviTelefon;
            this.noviTelefon = "";
            this.ngOnInit();
          }
        }
      );
    }
  }
  izabranaSlika:boolean = false;
  dodataSlika!: File;
  greskaSlika:string = "";

  promeniSliku(event:any){ 
    this.dodataSlika = event.target.files[0];
    if (this.dodataSlika && (this.dodataSlika.type == 'image/jpeg' || this.dodataSlika.type == 'image/png')) {
      const reader = new FileReader();
      reader.onload = (e: any) => { 
        const img = new Image(); 
        img.onload = () => { 
          if (img.width >= 100 && img.width <= 300 && img.height >= 100 && img.height <= 300) {
            this.izabranaSlika = true; 
          }
          else{
            this.greskaSlika = "Izabrana slika nije odgovarajucih dimenzija"
          }
        };
        img.src = e.target.result;
      };

      reader.readAsDataURL(this.dodataSlika);
    }
    else{
      this.greskaSlika = "Izabrana slika nije u odgovarajucem formatu fajla"
    }
  }

  sacuvajPromenu(){
    if(this.izabranaSlika){        
      const formData = new FormData();
      formData.append('slika',this.dodataSlika);
      this.korisnikS.promenaProfilneSlike(this.ulogovan.korisnicko_ime,formData).subscribe(
        data=>{
          if(data>0){
            this.slika = "assets/" + this.dodataSlika.name;
          }
        }
      );
    }
  }
}
