import { Component, OnInit } from '@angular/core';
import { Korisnik } from '../modeli/korisnik';
import { KorisnikService } from '../servisi/korisnik.service';

@Component({
  selector: 'app-azuriranje-korisnika',
  templateUrl: './azuriranje-korisnika.component.html',
  styleUrls: ['./azuriranje-korisnika.component.css']
})
export class AzuriranjeKorisnikaComponent implements OnInit{

  korisnik:Korisnik = new Korisnik();
  poruka:string = "";

  constructor(private korisniciS:KorisnikService){}

  ngOnInit(): void {
      let x = localStorage.getItem("azuriranje");
      if (x != null){
        this.korisnik = JSON.parse(x);
      }
  }

  azuriraj(){
    this.poruka = "";
    this.korisniciS.azuriranjePodataka(this.korisnik).subscribe(
      data=>{
        if (data > 0){
          this.poruka = "Podaci su uspesno azurirani!";
        }
      }
    )
  }
}
