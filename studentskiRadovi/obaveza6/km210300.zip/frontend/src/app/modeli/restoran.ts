import { Time } from "@angular/common";
import { Korisnik } from "./korisnik";

export class Restoran{
    id:number = 0;
    naziv: string = "";
    adresa: string = "";
    tip: string = "";
    opis:string = "";
    telefon:string = "";

    zaposleni:Korisnik[] = [];
    radi_od:string = "";
    radi_do:string = "";
    izabranDan:string = "";
}