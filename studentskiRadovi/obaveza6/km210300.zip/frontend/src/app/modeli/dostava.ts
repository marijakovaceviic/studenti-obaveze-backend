export class Dostava{
    restoran:string = "";
    gost:string = "";
    iznos:number = 0;
    vreme_narucivanja:Date = new Date();
    vreme_dostave: string = "";
    status:string ="";

    prihvaceno:boolean = false;
    najkasnijeDo:Date = new Date();
}