export class JeloZaKorpu{
    gost:string ="";
    restoran:string = "";
    naziv_jela:string = "";
    kolicina: number = 0;
    cena: number = 0;
}