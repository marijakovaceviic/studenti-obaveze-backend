export class Rezervacija{
    id:number = 0;
    restoran:string="";
    gost:string="";
    datum:string="";
    broj_osoba:number = 0;
    opis:string="";
    status:string="";
    konobar:string="";
    kom_konobar:string="";
    kom_gost:string="";
    ocena:number = 0;
    dosao:string = "";
    dodeljen_sto:number = 0;
    rb_stola:number = 0;


    adresaRestorana:string = "";
    proslo30min:boolean = false;
}