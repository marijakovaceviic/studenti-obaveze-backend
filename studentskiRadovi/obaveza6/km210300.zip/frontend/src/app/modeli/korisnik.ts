export class Korisnik{
    korisnicko_ime: string = "";
    lozinka: string = "";
    tip: string = "";
    ime:string = "";
    prezime:string = "";
    pol:string = "";
    adresa:string = "";
    telefon:string = "";
    email:string = "";
    slika:string = "";
    broj_kartice:string = "";
}