export class Raspored{
    restoran:string = "";
    element:string = "";
    x: number = 0;
    y: number = 0;
    sirina: number = 0;
    visina:number = 0;
    precnik:number = 0;
    brOsoba: number = 0;

    rb:number = 0;
}