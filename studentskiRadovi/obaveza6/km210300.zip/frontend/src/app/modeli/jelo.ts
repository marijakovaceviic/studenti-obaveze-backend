export class Jelo{
    restoran:string="";
    naziv:string="";
    slika:string="";
    cena:number = 0;
    sastojci:string="";

    kolicina:number=0;
}