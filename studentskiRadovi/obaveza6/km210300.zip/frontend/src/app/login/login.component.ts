import { Component, OnInit } from '@angular/core';
import { KorisnikService } from '../servisi/korisnik.service';
import { Router } from '@angular/router';
import * as CryptoJS from 'crypto-js';
import { RestoraniService } from '../servisi/restorani.service';
import { Restoran } from '../modeli/restoran';
import { RezervacijeService } from '../servisi/rezervacije.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{

  constructor(private korisnikS:KorisnikService, private router:Router, private restoraniS:RestoraniService, 
    private rezervacijeS:RezervacijeService
  ){}

  username: string = "";
  password: string = "";
  greska: string = "";

  brojRegistrovanih:number = 0;
  brojRestorana:number = 0;
  rezervacije24h: number = 0;
  rezervacije7dana: number = 0;
  rezervacijeMesecDana: number = 0;
  sviRestorani:Restoran[] =[];

  nazivPretraga:string = "";
  adresaPretraga:string = "";
  tipPretraga:string = "";
  rezultatPretrage:Restoran[] = [];

  ngOnInit(): void {
      this.korisnikS.brojRegistrovanihGostiju().subscribe(
        data=>{
          this.brojRegistrovanih = data;
        }
      );

      this.restoraniS.brojRestorana().subscribe(
        res=>{
          this.brojRestorana = res;
        }
      )

      this.rezervacijeS.rezervacijeUPoslednjih24h().subscribe(
        rez=>{
          this.rezervacije24h = rez;
        }
      )

      this.rezervacijeS.rezervacijeUPoslednjih7dana().subscribe(
        kol=>{
          this.rezervacije7dana = kol;
        }
      )

      this.rezervacijeS.rezervacijeUPoslednjihMesecDana().subscribe(
        mes=>{
          this.rezervacijeMesecDana = mes;
        }
      )

      this.restoraniS.sviRestorani().subscribe(
        svi=>{
          this.sviRestorani = svi;

          this.sviRestorani.forEach((r) => {
            this.restoraniS.zaposleniURestoranu(r.naziv).subscribe(
              zaposleni=>{
                if (zaposleni)
                  r.zaposleni = zaposleni;
              }
            )

          })
        }
      )
  }

  login(){
    if (this.username == "") {
      this.greska = "Nije uneto korisnicko ime";
    }
    else if (this.password == "") {
      this.greska = "Nije uneta lozinka";
    }
    else{
      const hesiranaLozinka = CryptoJS.SHA256(this.password).toString();
      this.korisnikS.prijava(this.username,hesiranaLozinka).subscribe(
        data=>{
          if (data == null) {
            this.greska = 'Takav korisnik ne postoji u bazi';
          } else {
            localStorage.setItem('ulogovan', JSON.stringify(data));
            if (data.tip == 'gost') {  
              this.router.navigate(['/profil']);
            } else if (data.tip == 'konobar') { 
              this.router.navigate(['/profil']);
            } else {
              this.greska = 'Takav korisnik ne postoji u bazi';
              localStorage.removeItem("ulogovan");
            }
          }
        }
      )
    }
  }
  

  promenaLozinke(){
    this.router.navigate(['/promenaLozinke']);
  }

  registracija(){
    this.router.navigate(['/registracija']);
  }

  rastucePoNazivu(){
    this.sviRestorani = this.restoraniS.sortirajRastucePoNazivu(this.sviRestorani);
  }

  opadajucePoNazivu(){
    this.sviRestorani = this.restoraniS.sortirajOpadajucePoNazivu(this.sviRestorani);
  }

  rastucePoAdresi(){
    this.sviRestorani = this.restoraniS.sortirajRastucePoAdresi(this.sviRestorani);
  }

  opadajucePoAdresi(){
    this.sviRestorani = this.restoraniS.sortirajOpadajucePoAdresi(this.sviRestorani);
  }

  rastucePoTipu(){
    this.sviRestorani = this.restoraniS.sortirajRastucePoTipu(this.sviRestorani);
  }

  opadajucePoTipu(){
    this.sviRestorani = this.restoraniS.sortirajOpadajucePoTipu(this.sviRestorani);
  }

  pretraga(){
    this.rezultatPretrage = this.restoraniS.pretraga(this.sviRestorani,this.nazivPretraga,this.adresaPretraga,this.tipPretraga);
  }
}
