import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { RezervacijeService } from '../servisi/rezervacije.service';
import { Korisnik } from '../modeli/korisnik';
import { Restoran } from '../modeli/restoran';
import { Rezervacija } from '../modeli/rezervacija';
import { RestoraniService } from '../servisi/restorani.service';
import { Raspored } from '../modeli/raspored';

interface Element {
  x: number;
  y: number;
  sirina?: number;
  visina?: number;
  precnik?: number;
  maksBrLjudi?: number;
}

@Component({
  selector: 'app-rezervacije-konobar',
  templateUrl: './rezervacije-konobar.component.html',
  styleUrls: ['./rezervacije-konobar.component.css']
})
export class RezervacijeKonobarComponent implements OnInit{

  constructor(private rezervacijeS:RezervacijeService, private restoraniS:RestoraniService){}

  neobradjene:Rezervacija[] = [];
  ulogovan:Korisnik = new Korisnik();
  restoran:Restoran = new Restoran();
  zaduzenje:Rezervacija[] = [];
  raspored:Raspored[]=[];
  kuhinje:Raspored[]=[];
  toaleti:Raspored[]=[];
  stolovi:Raspored[]=[];
  izabranSto:Raspored = new Raspored();
  odabranSto:boolean = false;

  ngOnInit(): void {
    let x = localStorage.getItem("ulogovan");
    if(x != null){
      this.ulogovan = JSON.parse(x);

      this.restoraniS.restoranUKomeRadi(this.ulogovan.korisnicko_ime).subscribe(
        data=>{
          if (data != null){
            this.restoran = data; 

            this.rezervacijeS.neobradjeneRezervacije(this.restoran.naziv).subscribe(
              rez=>{
                this.neobradjene = rez;
              }
            )

            this.restoraniS.dohvatiRaspored(this.restoran.naziv).subscribe(
              rasp=>{
                this.raspored = rasp;
                let i = 0;

                this.raspored.forEach(elem =>{
                  if(elem.element == "kuhinja"){
                    this.kuhinje.push(elem)
                  }
                  else if(elem.element == "sto"){
                    elem.rb = ++i;
                    this.stolovi.push(elem)
                  }
                  else{
                    this.toaleti.push(elem)
                  }
                })
                this.crtanjeRasporeda();
              }
            )
            
          }
        }
      )

      this.rezervacijeS.zaduzenjeKonobara(this.ulogovan.korisnicko_ime).subscribe(
        zad=>{
          this.zaduzenje = zad;

          this.zaduzenje.forEach(
            z=>{
              let trenutno = new Date();
              let vremeRez = new Date(z.datum)
              
              let proslo = (trenutno.getTime() - vremeRez.getTime()) / 6000;
              if (proslo >= 30) {
                  z.proslo30min = true;
              }
            }
          )
        }
      )
    }
  }
  poruka:string=""
  prihvati(rezervacija:Rezervacija){
    if(this.odabranSto == false){this.poruka="Niste izabrali sto"}
    else{
      rezervacija.status = "prihvaceno";
      rezervacija.kom_konobar = "";
      rezervacija.konobar = this.ulogovan.korisnicko_ime;
      rezervacija.dodeljen_sto = this.izabranSto.brOsoba;
      rezervacija.rb_stola = this.izabranSto.rb;
      this.rezervacijeS.postaviStatus(rezervacija).subscribe(
        data=>{
          if (data > 0){
            //this.ngOnInit();
            this.rezervacijeS.neobradjeneRezervacije(this.restoran.naziv).subscribe(
              rez=>{
                this.neobradjene = rez;
              }
            )
            this.zauzetiStolovi.push(this.izabranSto.rb);
            this.crtanjeRasporeda();
          }
        }
      )
    }
  }

  unosKomentara:string = "";

  odbaci(rezervacija:Rezervacija){
    this.unosKomentara = "";
    rezervacija.status = "odbijeno"; 
    rezervacija.konobar = this.ulogovan.korisnicko_ime;
    rezervacija.dodeljen_sto = 0;
    rezervacija.rb_stola = 0;
    if (rezervacija.kom_konobar == " "){ 
      this.unosKomentara = "Unesite komentar";
    }
    else{
      this.rezervacijeS.postaviStatus(rezervacija).subscribe(
        data=>{
          if(data > 0){
            this.unosKomentara = "";
            this.ngOnInit();
          }
        }
      )
    }
  }
  
  greska:string = "";

  daLiSePojavio(rezervacija:Rezervacija){
    this.rezervacijeS.gostDosao(rezervacija).subscribe(
     
    )
  }

  @ViewChild('canvas', { static: true }) canvas!: ElementRef<HTMLCanvasElement>;

  crtanjeRasporeda(): void {
    const canvas = this.canvas.nativeElement;
    const ctx = canvas.getContext('2d');

    if (ctx) {
     
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      
      ctx.strokeStyle = 'black';
      ctx.lineWidth = 2;
      ctx.strokeRect(5, 5, canvas.width - 10, canvas.height - 10);

      ctx.fillStyle = '#e3dac9'; 
      ctx.fillRect(20, 10, 250, 40);
      ctx.strokeStyle = 'black';
      ctx.strokeRect(20, 10, 250, 40);

      ctx.font = '20px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = 'black';
      ctx.fillText(this.restoran.naziv, 145, 30);

      ctx.strokeStyle = 'black';
      ctx.lineWidth = 2;
      ctx.strokeRect(20, 70, canvas.width - 40, canvas.height - 90);

      ctx.fillStyle = 'brown';
      ctx.strokeStyle = 'black';
      this.kuhinje.forEach((kuhinja: Raspored) => {
        ctx.strokeRect(kuhinja.x, kuhinja.y, kuhinja.sirina, kuhinja.visina);
        ctx.font = '16px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle'; 
        ctx.fillText('Kuhinja', kuhinja.x + kuhinja.sirina! / 2, kuhinja.y + kuhinja.visina / 2);
      });

     
      ctx.fillStyle = 'brown';
      ctx.strokeStyle = 'black';
      this.toaleti.forEach((toalet: Raspored) => {
        ctx.strokeRect(toalet.x, toalet.y, toalet.sirina, toalet.visina);
        ctx.font = '16px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('Toalet', toalet.x + toalet.sirina / 2, toalet.y + toalet.visina / 2);
      });

    
      this.stolovi.forEach((sto: Raspored) => {
        ctx.beginPath();
        ctx.arc(sto.x, sto.y, sto.precnik, 0, 2 * Math.PI);

        if (this.izabranSto == sto) { 
          ctx.fillStyle = 'orange'; 
        }  else {
          ctx.fillStyle = 'white'; 
        }
        if (this.zauzetiStolovi.includes(sto.rb)) {
          ctx.fillStyle = 'red'; 
        } 

        ctx.fill();
        ctx.lineWidth = 1;
        ctx.strokeStyle = 'black'; 
        ctx.stroke();
        ctx.closePath();

        ctx.font = '16px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = 'black'; 
        ctx.fillText(sto.brOsoba.toString(), sto.x, sto.y);

      });
    } else {
      
    }

  }
  
  odaberiSto(): void {
    this.odabranSto = true;
    this.crtanjeRasporeda();
  }

  zauzetiStolovi:number[] = [];
  izaberi(rezervacija:Rezervacija){
    this.zauzetiStolovi = [];
    this.rezervacijeS.zauzetiStolovi(rezervacija).subscribe(
      data=>{
        this.zauzetiStolovi = data;

        this.crtanjeRasporeda();
        this.izabranSto =  new Raspored();
      }
    )
  }
}
