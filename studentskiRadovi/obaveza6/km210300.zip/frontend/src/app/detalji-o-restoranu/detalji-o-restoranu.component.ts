import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NarudzbineService } from '../servisi/narudzbine.service';
import { Jelo } from '../modeli/jelo';
import { Korisnik } from '../modeli/korisnik';
import { KorpaService } from '../servisi/korpa.service';
import { RestoraniService } from '../servisi/restorani.service';
import { Restoran } from '../modeli/restoran';
import { RezervacijeService } from '../servisi/rezervacije.service';

@Component({
  selector: 'app-detalji-o-restoranu',
  templateUrl: './detalji-o-restoranu.component.html',
  styleUrls: ['./detalji-o-restoranu.component.css']
})
export class DetaljiORestoranuComponent implements OnInit{

  constructor(private router:ActivatedRoute, private narudzbineS:NarudzbineService, private korpaS:KorpaService, private restoraniS:RestoraniService,
      private rezervacijeS:RezervacijeService){}

  restoran:Restoran = new Restoran();

  prikazJelovnika:boolean = false;
  jelovnik:Jelo[] =[];
  ulogovan:Korisnik = new Korisnik();

  ngOnInit(): void {
    let x = this.router.snapshot.paramMap.get('naziv'); 
    if(x != null){
      let naziv = x; 

      this.restoraniS.dohvatiRestoran(naziv).subscribe(
        data=>{
          if (data != null){
            this.restoran = data;
          }
        }
      )
    }

    let korisnik = localStorage.getItem("ulogovan");
    if(korisnik != null){
      this.ulogovan = JSON.parse(korisnik);
    }
  }

  prikaziJelovnik(){
    if (this.prikazJelovnika){
      this.narudzbineS.jelovnikRestorana(this.restoran.naziv).subscribe(
        data=>{
          this.jelovnik = data;
        }
      )
    }
  }

  dodajUKorpu(jelo:Jelo){
    if (jelo.kolicina <= 0 || jelo.kolicina == null) {return;}
    this.korpaS.dodavanje(this.ulogovan.korisnicko_ime,this.restoran.naziv,jelo.naziv,jelo.kolicina,jelo.cena).subscribe(
    )
  }

  datumIVreme:string = "";
  brOsoba:number = 0;
  dodatno:string ="";
  poruka:string = "";
  rezervacija(){
    this.poruka = "";
    if (this.datumIVreme == ""){
      this.poruka = "Niste odabrali datum i vreme rezervacije"
    }
    else if (this.brOsoba == 0){
      this.poruka = "Niste uneli broj osoba za koje vrsite rezervaciju"
    }
    else{
      let pocetakRezervacije = new Date(this.datumIVreme);
      let krajRezervacije = new Date(pocetakRezervacije);
      krajRezervacije.setHours(krajRezervacije.getHours() + 3);

      const vremeP = this.dohvatiVreme(pocetakRezervacije);
      const vremeK = this.dohvatiVreme(krajRezervacije);
      const danP = this.dohvatiDanUNedelji(pocetakRezervacije);
      const danK = this.dohvatiDanUNedelji(krajRezervacije);
      const samoDatum = this.dohvatiDatum(pocetakRezervacije);

      let datumRezervacije = samoDatum + " " + vremeP;
      let danasnji = new Date();
      let rezervisano = new Date(datumRezervacije);
      if (rezervisano < danasnji){     
        this.poruka = "Datum rezervacije mora biti u buducnosti!"
      }
      else{
        this.restoraniS.dohvatiRadnoVreme(this.restoran.naziv,danP).subscribe(
          radi=>{ 
            if (danP != danK){
              this.restoraniS.dohvatiRadnoVreme(this.restoran.naziv,danK).subscribe(
                drugi=>{
                  if (vremeP < radi[0] || vremeP > radi[1] || vremeK < drugi[0]){
                    this.poruka = "Rezervacija nije u okviru radnog vremena restorana"
                  }
                  else{
                    this.rezervacijeS.slobodanSto(this.restoran.naziv,this.ulogovan.korisnicko_ime,datumRezervacije,this.brOsoba).subscribe(
                      ima=>{
                        if (ima == 0){
                          this.poruka = "Nema slobodnog stola za taj broj osoba u tom periodu"
                        }
                        else{
                          this.rezervacijeS.novaRezervacija(this.restoran.naziv,this.ulogovan.korisnicko_ime,datumRezervacije,this.brOsoba,this.dodatno,"u obradi").subscribe(
                            data=>{
                              this.poruka = "Vasa rezervacija je zapamcena"
                            }
                          )
                        }
                      }
                    )  
                  }
                }
              )
            }
            else{
              if (vremeP < radi[0] || vremeP > radi[1] || vremeK > radi[1]){
                this.poruka = "Rezervacija nije u okviru radnog vremena restorana"
              }
              else{
                this.rezervacijeS.slobodanSto(this.restoran.naziv,this.ulogovan.korisnicko_ime,datumRezervacije,this.brOsoba).subscribe(
                  ima=>{
                    if (ima == 0){
                      this.poruka = "Nema slobodnog stola za taj broj osoba u tom periodu"
                    }
                    else{
                      this.rezervacijeS.novaRezervacija(this.restoran.naziv,this.ulogovan.korisnicko_ime,datumRezervacije,this.brOsoba,this.dodatno,"u obradi").subscribe(
                      )
                    }
                  }
                )  
              }
            }
          }
        ) 
      }
    }
  }

  private dohvatiVreme(datum: Date): string {
    return datum.toTimeString().split(' ')[0]; 
  }

  private dohvatiDanUNedelji(datum: Date): string {
    const dani = ["nedelja", "ponedeljak", "utorak", "sreda", "cetvrtak", "petak", "subota"];
    return dani[datum.getDay()];
  }

  private dohvatiDatum(datum: Date): string {
    const dan = String(datum.getDate()).padStart(2, '0');
    const mesec = String(datum.getMonth() + 1).padStart(2, '0'); 
    const godina = datum.getFullYear();
    return `${godina}-${mesec}-${dan}`; 
  }

}
