import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetaljiORestoranuComponent } from './detalji-o-restoranu.component';

describe('DetaljiORestoranuComponent', () => {
  let component: DetaljiORestoranuComponent;
  let fixture: ComponentFixture<DetaljiORestoranuComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DetaljiORestoranuComponent]
    });
    fixture = TestBed.createComponent(DetaljiORestoranuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
