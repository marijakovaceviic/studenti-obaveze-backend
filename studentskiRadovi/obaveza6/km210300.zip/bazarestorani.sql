CREATE DATABASE  IF NOT EXISTS `bazarestorani` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bazarestorani`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: b1
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dostave`
--

DROP TABLE IF EXISTS `dostave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dostave` (
  `restoran` varchar(50) NOT NULL,
  `gost` varchar(50) NOT NULL,
  `iznos` double NOT NULL,
  `vreme_narucivanja` datetime NOT NULL,
  `vreme_dostave` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`restoran`,`gost`,`vreme_narucivanja`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dostave`
--

LOCK TABLES `dostave` WRITE;
/*!40000 ALTER TABLE `dostave` DISABLE KEYS */;
INSERT INTO `dostave` VALUES ('Bizu','mica',1240,'2024-07-01 02:51:12','','odbijeno'),('Dve Lipe','ana',2106.5,'2024-05-30 10:19:32','30-40 minuta','prihvaceno'),('Dve Lipe','ana',2969.5,'2024-05-30 14:26:23','30-40 minuta','prihvaceno'),('Dve Lipe','ana',2203,'2024-05-30 14:27:41','','u obradi'),('Dve Lipe','ana',1533,'2024-05-30 14:27:56','','odbijeno'),('Dve Lipe','ana',1533,'2024-05-30 20:14:58','20-30 minuta','prihvaceno'),('Dve Lipe','ljubo',1533,'2024-06-28 04:17:12','','u obradi'),('Dve Lipe','nina',1533,'2024-07-03 16:48:06','20-30 minuta','prihvaceno'),('Valter','nina',1280,'2024-07-01 02:45:06','30-40 minuta','prihvaceno'),('Valter','nina',1120,'2024-07-01 02:47:06','','u obradi');
/*!40000 ALTER TABLE `dostave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jela`
--

DROP TABLE IF EXISTS `jela`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jela` (
  `restoran` varchar(50) NOT NULL,
  `naziv` varchar(50) NOT NULL,
  `slika` varchar(100) NOT NULL,
  `cena` double NOT NULL,
  `sastojci` varchar(100) NOT NULL,
  PRIMARY KEY (`restoran`,`naziv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jela`
--

LOCK TABLES `jela` WRITE;
/*!40000 ALTER TABLE `jela` DISABLE KEYS */;
INSERT INTO `jela` VALUES ('Bizu','Miso supa','pikacu.png',450,'miso pasta,tofu'),('Bizu','sushi','cvet.jpg',620,'pirinac,sargarepa,susam'),('Dve Lipe','Cezar salata','pikacu.png',766.5,'piletina,zelena salata,slanina,sos,pradajz'),('Dve Lipe','Karadjordjeva snicla','cvet.jpg',670,'slanina, kajmak,'),('Dve Lipe','Pastmrka na zaru','pikacu.png',800,'pastrmka,so,ulje,brasno'),('Valter','10 cevapa u lepinji','cvet.jpg',720,'junece meso,luk,kajmak'),('Valter','5 cevapa u lepinji','cvet.jpg',560,'junece meso,luk,kajmak'),('Wang','Meso sa nudlama','cvet.jpg',576,'povrce,sampinjoni,nudle');
/*!40000 ALTER TABLE `jela` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `korisnici`
--

DROP TABLE IF EXISTS `korisnici`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `korisnici` (
  `korisnicko_ime` varchar(50) NOT NULL,
  `lozinka` varchar(100) NOT NULL,
  `tip` varchar(45) NOT NULL,
  `ime` varchar(45) NOT NULL,
  `prezime` varchar(45) NOT NULL,
  `pol` varchar(45) NOT NULL,
  `adresa` varchar(45) NOT NULL,
  `telefon` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `slika` varchar(225) NOT NULL,
  `broj_kartice` varchar(45) NOT NULL,
  PRIMARY KEY (`korisnicko_ime`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `korisnici`
--

LOCK TABLES `korisnici` WRITE;
/*!40000 ALTER TABLE `korisnici` DISABLE KEYS */;
INSERT INTO `korisnici` VALUES ('ana','5b73a24676247932de3dffe9e66f13ae26bd131b49c1bfe183c297f40953b5f6','gost','Ana','Andric','zenski','Pozeska 12','062 1346 456','ana@gmail.com','skvrtl.png','1987 6789 5462 2346'),('dunja','0c592eb35cade4bfeacce430f6044dff2c30b8741ea1843cf3e40341e1f533d3','konobar','Dunja','Dunjic','zenski','Zlatiborska 28','061 2345 876','dunja@gmail.rs','pikacu.png','1234 7896 1234 1234'),('dzoni','f33a285f5f599df67a896748d109c106f65484fce5148501bac26d0b5aea7a18','gost','Nikola','Petrovic','muski','Milutina Milankovica 11','065 1235 166','dzoni@gmail.com','caramander.png','9995 7734 8098 5678'),('jova','44d53196dab9239fd40656a9d7b97c3b5c9ec122cfa9d90f6486dd774126c348','konobar','Jovan','Jovanovic','muski','Vojvode Stepe 15','065 4567 177','jova@gmail.com','default.jpg','1235 7893 5678 2356'),('lana','7021aceb3e90b4ce49860995e0cfe6dc29e50dca6e03bc3d9950a19f08cd62da','konobar','Lana','Vasic','zenski','Kraljice Natalije 2','062 6745 123','lana12@gmail.com','caramander.png','1987 4812 5462 2346'),('ljubo','04d6d04b9cdf7797e5ba047ad31a72405ecd9681b67baf50654e27f64c54437a','gost','Ljubo','Ljubicic','muski','Svetosavska 23','065 3765456','ljubo@gmail.com','skvrtl.png','1234 1234 1234 1234'),('mica','7a8a774b8b0ad8b254c8d92a7332470ac4e17660eb17eeeaa5905c34f4cb117f','gost','Milica','Nikolic','zenski','Branka Copica 22','062 1834 787','mica123@gmail.com','cvet.jpg','7895 5466 7895 6543'),('mile','c514e6262758f0e9da22ac03a7ec1399af70375ff4182b3eb80a0ea5919ed683','konobar','Milan','Milovanovic','muski','Ustanicka 15','064 5673 567','mile@gmail.com','default.jpg','1987 6789 5555 2346'),('mire','183e342309b082329cef3170b990b2013a69c0bba671a2c6ae1e6bd877cc3e25','konobar','Miroslav','Jakovljevic','muski','Cvijiceva 12','061 1111 775','mire34@gmail.com','default.jpg','4678 8888 5454 1221'),('miso','miso123M$','admin','Milos','Pavlovic','muski','Nemanjina 18','0641813946','km14@gmail.com','pikacu.jpg','1234123412341234'),('nina','a7227061e93f5ae3a245d83dd5fb620824564b9172e6827524fc09e9cf42a3fb','gost','Nikolina','Bojovic','zenski','Dalmatinska 6','065 3246 989','nina@gmail.com','default.jpg','1235 3433 5643 2356'),('pera','5a8981cc21e1817e057e5c19ed783bece1a9a424ce84fe2d93749be552cb0f13','konobar','Petar','Peric','muski','Vojislava Ilica 14','064 1236 879','pera@gmail.com','zalazak.jpg','1238 4567 9876 3456'),('sanja','9a4b693d38cfe6f66f714f322f5d32a252fab7d417c83cd30e4ce441afccc5d5','konobar','Sanja','Peric','zenski','Visnjicka 77','062 1234 127','sanjaper@gmail.rs','default.jpg','6677 6789 8822 2346'),('sara','86463e24388cf66e740f83dc415941228fedad6330105642cf1e0360b251bea9','gost','Sara','Pavlovic','zenski','Kralja Petra 18','063 4568 999','sara@gmail.com','caramander.png','1967 2222 5462 2346'),('zika','9ea926a220a5e96fa6f59af2395aaad398f3af5b97b74980d934610cec32c79f','konobar','Zivorad','Jovic','muski','Geteova 11','062 1551 365','zika@gmail.rs','default.jpg','1987 6789 6789 4567');
/*!40000 ALTER TABLE `korisnici` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `korpa`
--

DROP TABLE IF EXISTS `korpa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `korpa` (
  `gost` varchar(50) NOT NULL,
  `restoran` varchar(50) NOT NULL,
  `naziv_jela` varchar(50) NOT NULL,
  `kolicina` int NOT NULL,
  `cena` double NOT NULL,
  PRIMARY KEY (`gost`,`restoran`,`naziv_jela`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `korpa`
--

LOCK TABLES `korpa` WRITE;
/*!40000 ALTER TABLE `korpa` DISABLE KEYS */;
INSERT INTO `korpa` VALUES ('ana','Dve Lipe','Cezar salata',1,766.5),('ljubo','Dve Lipe','Cezar salata',2,766.5);
/*!40000 ALTER TABLE `korpa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `odbijeni`
--

DROP TABLE IF EXISTS `odbijeni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `odbijeni` (
  `korisnicko_ime` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`korisnicko_ime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `odbijeni`
--

LOCK TABLES `odbijeni` WRITE;
/*!40000 ALTER TABLE `odbijeni` DISABLE KEYS */;
INSERT INTO `odbijeni` VALUES ('djole','djole@gmail.com'),('sasa','sale@gmail.com');
/*!40000 ALTER TABLE `odbijeni` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radno_vreme`
--

DROP TABLE IF EXISTS `radno_vreme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `radno_vreme` (
  `restoran` varchar(50) NOT NULL,
  `od` time NOT NULL,
  `do` time NOT NULL,
  `dan` varchar(45) NOT NULL,
  PRIMARY KEY (`restoran`,`dan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radno_vreme`
--

LOCK TABLES `radno_vreme` WRITE;
/*!40000 ALTER TABLE `radno_vreme` DISABLE KEYS */;
INSERT INTO `radno_vreme` VALUES ('Bizu','11:25:00','18:25:00','ponedeljak'),('Bizu','08:00:00','17:30:00','utorak'),('Dve Lipe','07:00:00','16:00:00','cetvrtak'),('Dve Lipe','08:00:00','17:00:00','nedelja'),('Dve Lipe','09:00:00','23:00:00','petak'),('Dve Lipe','12:00:00','23:00:00','ponedeljak'),('Dve Lipe','12:00:00','23:00:00','sreda'),('Dve Lipe','08:00:00','17:00:00','subota'),('Dve Lipe','09:00:00','17:30:00','utorak'),('Valter','09:00:00','17:00:00','cetvrtak'),('Valter','09:00:00','17:00:00','petak'),('Valter','10:15:00','22:15:00','ponedeljak'),('Valter','12:00:00','23:15:00','sreda'),('Valter','10:15:00','22:15:00','utorak'),('Wang','10:00:00','18:30:00','ponedeljak'),('Wang','11:00:00','21:30:00','utorak');
/*!40000 ALTER TABLE `radno_vreme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `raspored`
--

DROP TABLE IF EXISTS `raspored`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `raspored` (
  `restoran` varchar(50) NOT NULL,
  `element` varchar(45) NOT NULL,
  `x` int NOT NULL,
  `y` int NOT NULL,
  `sirina` int NOT NULL,
  `visina` int NOT NULL,
  `precnik` int NOT NULL,
  `brOsoba` int NOT NULL,
  PRIMARY KEY (`restoran`,`element`,`x`,`y`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `raspored`
--

LOCK TABLES `raspored` WRITE;
/*!40000 ALTER TABLE `raspored` DISABLE KEYS */;
INSERT INTO `raspored` VALUES ('Bizu','kuhinja',30,80,100,50,0,0),('Bizu','sto',60,170,0,0,25,4),('Bizu','sto',60,230,0,0,25,4),('Bizu','sto',120,230,0,0,25,4),('Bizu','sto',190,230,0,0,25,3),('Bizu','sto',280,230,0,0,25,3),('Bizu','sto',350,230,0,0,25,4),('Bizu','sto',410,170,0,0,25,4),('Bizu','sto',410,230,0,0,25,4),('Bizu','toalet',380,80,50,50,0,0),('Dve Lipe','kuhinja',30,80,100,50,0,0),('Dve Lipe','sto',60,170,0,0,25,4),('Dve Lipe','sto',60,230,0,0,25,4),('Dve Lipe','sto',120,170,0,0,25,4),('Dve Lipe','sto',120,230,0,0,25,4),('Dve Lipe','sto',330,170,0,0,25,4),('Dve Lipe','sto',330,230,0,0,25,4),('Dve Lipe','sto',390,170,0,0,25,4),('Dve Lipe','sto',390,230,0,0,25,4),('Dve Lipe','toalet',360,80,50,50,0,0),('Valter','kuhinja',30,80,100,50,0,0),('Valter','sto',60,170,0,0,25,4),('Valter','sto',60,230,0,0,25,4),('Valter','sto',120,170,0,0,25,4),('Valter','sto',120,230,0,0,25,4),('Valter','sto',190,230,0,0,25,3),('Valter','sto',280,230,0,0,25,3),('Valter','sto',350,170,0,0,25,4),('Valter','sto',350,230,0,0,25,4),('Valter','sto',410,170,0,0,25,4),('Valter','sto',410,230,0,0,25,4),('Valter','toalet',380,80,50,50,0,0);
/*!40000 ALTER TABLE `raspored` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restorani`
--

DROP TABLE IF EXISTS `restorani`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restorani` (
  `id` int NOT NULL AUTO_INCREMENT,
  `naziv` varchar(50) NOT NULL,
  `adresa` varchar(50) NOT NULL,
  `tip` varchar(45) NOT NULL,
  `opis` varchar(100) NOT NULL,
  `telefon` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restorani`
--

LOCK TABLES `restorani` WRITE;
/*!40000 ALTER TABLE `restorani` DISABLE KEYS */;
INSERT INTO `restorani` VALUES (2,'Dve Lipe','Nikole Pasica 7','domaca kuhinja','Domaci specilijateti uz najbolju ribu iz naseg ribnjaka.','065 3451 125'),(3,'Bizu','Alibunarska 6','japanski','Najbolji sushi u gradu!','061 8986 898'),(6,'Valter','Sarajevska 14','domaca kuhinja','Sarajevska hrana','063 5678 476'),(7,'Wang','Prvomajska 18','kineski','Najbolja kineska hrana u Beogradu!','064 7894 675');
/*!40000 ALTER TABLE `restorani` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rezervacije`
--

DROP TABLE IF EXISTS `rezervacije`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rezervacije` (
  `id` int NOT NULL AUTO_INCREMENT,
  `restoran` varchar(50) NOT NULL,
  `gost` varchar(45) NOT NULL,
  `datum` datetime NOT NULL,
  `broj_osoba` int NOT NULL,
  `opis` varchar(100) DEFAULT NULL,
  `status` varchar(45) NOT NULL,
  `konobar` varchar(45) DEFAULT NULL,
  `kom_konobar` varchar(100) DEFAULT NULL,
  `kom_gost` varchar(100) DEFAULT NULL,
  `ocena` int DEFAULT NULL,
  `vreme_rezervacije` datetime NOT NULL,
  `dosao` varchar(45) DEFAULT NULL,
  `dodeljen_sto` int DEFAULT '0',
  `rb_stola` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rezervacije`
--

LOCK TABLES `rezervacije` WRITE;
/*!40000 ALTER TABLE `rezervacije` DISABLE KEYS */;
INSERT INTO `rezervacije` VALUES (1,'Dve Lipe','ljubo','2024-06-08 13:34:00',3,'poslovni rucak','prihvaceno','dunja','','',0,'2024-06-05 12:13:00','da',0,0),(2,'Dve Lipe','ljubo','2024-06-12 12:50:00',3,'rodjendan','prihvaceno','sveta','','',0,'2024-06-02 14:03:00','',0,0),(3,'Dve Lipe','ljubo','2024-06-12 13:43:00',3,'','odbijeno','dunja','',' ',0,'2024-06-10 11:43:44','',0,0),(4,'Dve Lipe','ljubo','2024-06-12 12:48:00',3,'','prihvaceno','dunja','',' ',0,'2024-06-10 11:44:55','',0,0),(5,'Dve Lipe','ljubo','2024-06-12 13:50:00',3,'','prihvaceno','dunja','',' ',0,'2024-06-10 11:45:18','',4,0),(7,'Dve Lipe','ljubo','2024-06-18 11:21:00',3,'','u obradi',NULL,' ',' ',0,'2024-06-16 01:22:23','',0,0),(8,'Dve Lipe','ljubo','2024-06-20 12:31:00',4,'','prihvaceno','dunja','',' ',0,'2024-06-16 01:31:46','ne',4,0),(9,'Dve Lipe','ljubo','2024-07-02 13:30:00',3,'','prihvaceno','dunja','',' ',0,'2024-06-27 23:31:14','',4,0),(10,'Dve Lipe','nina','2024-07-08 13:15:00',3,'','prihvaceno','jova','',' ',0,'2024-07-01 16:06:46','',4,4),(11,'Dve Lipe','nina','2024-07-08 13:15:00',4,'','prihvaceno','jova','',' ',0,'2024-07-01 16:07:21','',4,7),(12,'Dve Lipe','nina','2024-07-08 13:15:00',4,'Slavim rodjendan,pa mi trebaju 3 stola','u obradi',NULL,' ',' ',0,'2024-07-01 16:08:30','',0,0),(13,'Dve Lipe','ana','2024-07-01 13:15:00',4,'','prihvaceno','pera','',' ',0,'2024-07-02 18:19:22','',4,6),(14,'Bizu','ana','2024-07-02 10:25:00',3,'','u obradi',NULL,' ',' ',0,'2024-07-02 18:24:24','',0,0),(15,'Dve Lipe','ana','2024-06-27 12:00:00',3,'','u obradi',NULL,' ',' ',0,'2024-07-02 19:02:42','',0,0),(16,'Dve Lipe','dzoni','2024-06-28 15:10:00',3,'','prihvaceno','pera','',' ',0,'2024-07-02 19:11:24','',4,1),(17,'Dve Lipe','dzoni','2024-06-30 09:10:00',2,'','odbijeno','jova',' Ne mozemo prihvatiti vasu rezervaciju',' ',0,'2024-07-02 19:11:56','',0,0),(18,'Dve Lipe','mica','2024-06-28 14:15:00',3,'','u obradi',NULL,' ',' ',0,'2024-07-02 19:16:40','',0,0),(19,'Dve Lipe','sara','2024-06-28 13:20:00',2,'','prihvaceno','jova','',' ',0,'2024-07-03 04:21:22','',4,6),(20,'Dve Lipe','nina','2024-06-28 13:40:00',4,'Ako moze blize terasi.','prihvaceno','jova','',' ',0,'2024-07-03 16:57:44','',4,2),(21,'Dve Lipe','mica','2024-06-30 13:05:00',2,'','prihvaceno','dunja','',' ',0,'2024-07-03 17:05:50','',4,7);
/*!40000 ALTER TABLE `rezervacije` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zahtevi`
--

DROP TABLE IF EXISTS `zahtevi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `zahtevi` (
  `korisnicko_ime` varchar(50) NOT NULL,
  `lozinka` varchar(150) NOT NULL,
  `tip` varchar(45) NOT NULL,
  `ime` varchar(45) NOT NULL,
  `prezime` varchar(45) NOT NULL,
  `pol` varchar(45) NOT NULL,
  `adresa` varchar(45) NOT NULL,
  `telefon` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `slika` varchar(225) NOT NULL,
  `broj_kartice` varchar(45) NOT NULL,
  PRIMARY KEY (`korisnicko_ime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zahtevi`
--

LOCK TABLES `zahtevi` WRITE;
/*!40000 ALTER TABLE `zahtevi` DISABLE KEYS */;
INSERT INTO `zahtevi` VALUES ('joca','12d45eb827e5faab8a9a362d73397ba1788eee6e58de83f0e7aa905e66cb1038','gost','Jovana','Dukic','zenski','Zeleznicka 14','062 1223 434','joca@gmail.com','default.jpg','1987 5444 5462 2346'),('mika','1613707d1e568302262543ce599c789d102a7646cde919d8eb439644be6062f3','gost','Miroslav','Jovanovic','muski','adresa12345','065 1235 132','mika@gmail.com','default.jpg','1987 6789 5462 2365');
/*!40000 ALTER TABLE `zahtevi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zaposleni`
--

DROP TABLE IF EXISTS `zaposleni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `zaposleni` (
  `restoran` varchar(50) NOT NULL,
  `korisnicko_ime` varchar(45) NOT NULL,
  PRIMARY KEY (`korisnicko_ime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zaposleni`
--

LOCK TABLES `zaposleni` WRITE;
/*!40000 ALTER TABLE `zaposleni` DISABLE KEYS */;
INSERT INTO `zaposleni` VALUES ('Dve Lipe','dunja'),('Dve Lipe','jova'),('Bizu','lana'),('Wang','mile'),('Valter','mire'),('Dve Lipe','pera'),('Wang','sanja'),('Bizu','zika');
/*!40000 ALTER TABLE `zaposleni` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-06  1:05:07
