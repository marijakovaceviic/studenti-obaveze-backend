module timer #(
	parameter second = 50_000_000
)(
	input clk,
	input rst_n,
	output [9:0] out
);

    reg [9:0] out_next, out_reg;
    integer timer_next, timer_reg;

    assign out = out_reg;

    always @(posedge clk, negedge rst_n)
        if (!rst_n) begin
            out_reg <= 10'h000;
            timer_reg <= 0;
        end
        else begin
            out_reg <= out_next;
            timer_reg <= timer_next;
        end

    always @(*) begin
        out_next = out_reg;
        timer_next = timer_reg;
        if (timer_reg == second) begin
            out_next = out_reg + 1'b1;
            timer_next = 0;
        end
        else
            timer_next = timer_reg + 1;
    end

endmodule
