package rs.ac.bg.etf.pp1;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import rs.ac.bg.etf.pp1.ast.*;
import rs.ac.bg.etf.pp1.ast.VisitorAdaptor;
import rs.etf.pp1.mj.runtime.Code;
import rs.etf.pp1.symboltable.Tab;
import rs.etf.pp1.symboltable.concepts.Obj;
import rs.etf.pp1.symboltable.concepts.Struct;

public class CodeGenerator extends VisitorAdaptor {
	
	public CodeGenerator() {
		//len nema u predefinisanim imenima ali ima u tabeli simbola
		Obj obj = Tab.find("len");
		obj.setAdr(Code.pc);
		Code.put(Code.enter);
		Code.put(obj.getLevel());
		Code.put(obj.getLocalSymbols().size());
		Code.put(Code.load_n);
		Code.put(Code.arraylength);
		Code.put(Code.exit);
		Code.put(Code.return_);
		
		obj = Tab.find("chr");
		obj.setAdr(Code.pc);
		Code.put(Code.enter);
		Code.put(obj.getLevel());
		Code.put(obj.getLocalSymbols().size());
		Code.put(Code.load_n);
		Code.put(Code.exit);
		Code.put(Code.return_);
		
		obj = Tab.find("ord");
		obj.setAdr(Code.pc);
		Code.put(Code.enter);
		Code.put(obj.getLevel());
		Code.put(obj.getLocalSymbols().size());
		Code.put(Code.load_n);
		Code.put(Code.exit);
		Code.put(Code.return_);
		
		obj = Tab.find("add");
		obj.setAdr(Code.pc);
		Code.put(Code.enter);
		Code.put(obj.getLevel());
		Code.put(obj.getLocalSymbols().size());
		
		//ako je skup prazan odmah dodajem, bez provere da li elem postoji u skupu
		Code.loadConst(0);
		Code.put(Code.load_n);
		Code.loadConst(0);
		Code.put(Code.aload);
		Code.putFalseJump(Code.ne, 0);
		int dodajOdmah = Code.pc - 2;
		
		int adr = Code.pc;
		//inicijalizacija brojaca (i inkrementiranje)
		Code.put(Code.load_2);
		Code.loadConst(1);
		Code.put(Code.add);
		Code.put(Code.store_2); //i = 1
		
		//provera da li elem postoji u skupu
		Code.put(Code.load_1); 
		Code.put(Code.load_n);
		Code.put(Code.load_2); 
		Code.put(Code.aload);
		//stek: b set[1]
		
		Code.putFalseJump(Code.ne, 0); //prekidamo dodavanje, elem vec postoji u skupu
		int mestoPrepravke = Code.pc - 2;
		
		//provera da li smo novi elem uporedili sa svim elementima skupa
		Code.put(Code.load_n);
		Code.loadConst(0);
		Code.put(Code.aload);
		Code.put(Code.load_2);
		Code.putFalseJump(Code.eq, adr);
		
		Code.fixup(dodajOdmah);
		//dodajem novi element (na poziciju set[0]+1 tj i+1)
		Code.put(Code.load_n);
		Code.put(Code.load_2);
		Code.loadConst(1);
		Code.put(Code.add);
		Code.put(Code.load_1);
		Code.put(Code.astore);
		
		//inkrementiram brojac elemenata u setu (set[0])
	    Code.put(Code.load_n);
	    Code.loadConst(0);
	    Code.put(Code.dup2);
	    Code.put(Code.aload);
		Code.loadConst(1);
		Code.put(Code.add);
		Code.put(Code.astore);
		
		Code.fixup(mestoPrepravke);
		Code.put(Code.exit);
		Code.put(Code.return_);
	
		obj = Tab.find("addAll");
		obj.setAdr(Code.pc);
		Code.put(Code.enter);
		Code.put(obj.getLevel());
		Code.put(obj.getLocalSymbols().size());
		int adrAll = Code.pc;
		Code.put(Code.load_n); //set
		Code.put(Code.load_1);
		Code.put(Code.load_2);
		Code.put(Code.aload);
		int offset = Tab.find("add").getAdr() - Code.pc;
		Code.put(Code.call);
		Code.put2(offset);
		
		Code.put(Code.load_2);
		Code.loadConst(1);
		Code.put(Code.add);
		Code.put(Code.store_2);
		
		Code.put(Code.load_2);
		Code.put(Code.load_1);
		Code.put(Code.arraylength);
		Code.putFalseJump(Code.eq, adrAll);
		Code.put(Code.exit);
		Code.put(Code.return_);
	}

	private int mainPc;
	private boolean returnFound = false;
	private Obj currMeth; 
	
	public int getMainPc() {
		return mainPc;
	}
	Obj currSet;
	
	@Override 
	public void visit(MethodType method) {
		currMeth = method.obj;
		// kada pocne definicija metode - to je njena adresa
		// na nju cemo skakati kada pozovemo fju
		method.obj.setAdr(Code.pc); // obavezno pre enter intsrukcije!! 
		if (method.getMethName().equalsIgnoreCase("main")) {
			this.mainPc = Code.pc;
		}
		Code.put(Code.enter);
		Code.put(method.obj.getLevel());
		Code.put(method.obj.getLocalSymbols().size());
	}
	
	@Override 
	public void visit(MethodVoid method) {
		currMeth = method.obj;
		method.obj.setAdr(Code.pc); 
		if (method.getMethName().equalsIgnoreCase("main")) {
			this.mainPc = Code.pc;
		}
		Code.put(Code.enter);
		Code.put(method.obj.getLevel());
		Code.put(method.obj.getLocalSymbols().size());
	}
	
	@Override
	public void visit(MethodDecl method) {
		if (currMeth.getType() != Tab.noType && !returnFound) {
			Code.put(Code.trap);
			Code.put(1);
			return;
		}
		currMeth = null;
		returnFound = false;
		Code.put(Code.exit);
		Code.put(Code.return_);
	}
	
	@Override
	public void visit(PrintStmt printStmt) {
		// expr mora da bude na steku kada se desava ovaj visit
		//Code.loadConst(1); //  sirina
		if (printStmt.getExpr().struct.equals(Tab.charType)) {
			Code.loadConst(1); //zbog set ovde
			Code.put(Code.bprint);
		}
		else if (printStmt.getExpr().struct.getKind() == Struct.Enum) {
			
			//stek: setAdr
			Code.loadConst(1);
			//stek: setAdr 1
			Code.put(Code.dup_x1);
			//stek: 1 setAdr 1
			Code.put(Code.aload);
			//stek: 1 setAdr[1]
			
			int adr = Code.pc;
			Code.loadConst(0); //sirina
			Code.put(Code.print);//ispis elementa
			
			//provera da li sam ispisala sve elemente
			//stek: 1
			Code.put(Code.dup);
			//stek: 1 1
			Code.load(currSet);
			//stek: 1 1 setAdr
			Code.loadConst(0);
			Code.put(Code.aload);
			//stek: 1 1 setAdr[0]
			
			Code.putFalseJump(Code.ne, 0); //zavrsavamo
			int skokNaKraj = Code.pc - 2;
			
			//stampam razmak
			Code.loadConst(32);
			Code.loadConst(0);
			Code.put(Code.bprint);
			
			//stek: 1
			Code.loadConst(1);
			Code.put(Code.add); //inkrementiranje brojaca
			
			//pristup sledecem elementu
			//stek: 2
			Code.put(Code.dup);
			//stek: 2 2
			Code.load(currSet);
			//stek: 2 2 setAdr
			Code.put(Code.dup_x1);
			//stek: 2 setAdr 2 setAdr
			Code.put(Code.pop);
			//stek: 2 setAdr 2
			Code.put(Code.aload);
			//stek: 2 setAdr[2]

			Code.putJump(adr);
			
			Code.fixup(skokNaKraj);
			Code.put(Code.pop);
		}
		else {
			Code.loadConst(1); // zbog set ovde
			Code.put(Code.print);
		}
	}
	
	@Override
	public void visit(PrintStmtFormat printStmt) {
		Code.loadConst(printStmt.getN2());
		if (printStmt.getExpr().struct.equals(Tab.charType)) {
			Code.put(Code.bprint);
		}
		else {
			Code.put(Code.print);
		}
	}
	
	@Override
	public void visit(FactorNumber numFactor) {
		Code.loadConst(numFactor.getNumFactor());  // numericku konstantu stavljamo na stek
	}
	
	@Override
	public void visit(FactorChar charFactor) {
		Code.loadConst(charFactor.getCharFactor()); // ne znam treba li dodati konverziju u int za svaki sluc 
	}
	
	@Override
	public void visit(FactorBool boolFactor) {
		if (boolFactor.getBoolFactor() == true) {
			Code.loadConst(1); 
		} else {
			Code.loadConst(0);
		}
	}
	
	@Override
	public void visit(AddExpr addExpr) {
		if (addExpr.getAddop() instanceof AddopPlus) {
			Code.put(Code.add);
		} else if (addExpr.getAddop() instanceof AddopMinus) {
			Code.put(Code.sub);
		}
	}
	
	@Override
	public void visit(MapExpr mapExpr) {
		
		Code.load(mapExpr.getDesignator1().obj); // adresa niza
		Code.loadConst(0);
		Code.put(Code.aload);
		int offset = mapExpr.getDesignator().obj.getAdr() - Code.pc;
		Code.put(Code.call);
		Code.put2(offset);
		//stek: rez
		
		Code.loadConst(0);  //brojac
		//stek: rez 0
		
		int adresa = Code.pc;
		Code.loadConst(1);
		Code.put(Code.add);
		//stek: rez 1
		Code.put(Code.dup);
		//stek: rez 1 1
		Code.load(mapExpr.getDesignator1().obj); // adresa niza
		Code.put(Code.arraylength);
		//stek: rez 1 1 len
		Code.putFalseJump(Code.ne, 0);  //zavrsavamo
		int mestoZaprepravku = Code.pc - 2;
		
		//stek: rez 1
		Code.put(Code.dup_x1);
		//stek: 1 rez 1
		Code.load(mapExpr.getDesignator1().obj); // adresa niza
		//stek: 1 rez 1 adr
		Code.put(Code.dup_x1);
		//stek: 1 rez adr 1 adr
		Code.put(Code.pop);
		//stek: 1 rez adr 1
		Code.put(Code.aload);
		int offset2 = mapExpr.getDesignator().obj.getAdr() - Code.pc;
		Code.put(Code.call);
		Code.put2(offset2);
		//stek: 1 rez rez2
		Code.put(Code.add);
		//stek: 1 rez
		Code.put(Code.dup_x1);
		//stek: rez 1 rez
		Code.put(Code.pop);
		//stek: rez 1
		Code.putJump(adresa);
		
		Code.fixup(mestoZaprepravku);
		Code.put(Code.pop);
	}
	
	@Override
	public void visit(TermMul termMul) {
		if (termMul.getMulop() instanceof MulopMul) {
			Code.put(Code.mul);
		} else if (termMul.getMulop() instanceof MulopDiv) {
			Code.put(Code.div);
		} else if (termMul.getMulop() instanceof MulopMod) {
			Code.put(Code.rem);
		}
	}
	
	@Override
	public void visit(FuncCall factor) {
		int offset = factor.getDesignatorProcCall().getDesignator().obj.getAdr() - Code.pc;
		//bitno je da ovo bude pre Code.put jer on inkrementira pc
		Code.put(Code.call);
		Code.put2(offset);
	}
	
	@Override
	public void visit(FactorDes designFactor) {
		//	Code.load(designFactor.getDesignator().obj);
		// npr print(a)
		// stavice se load_2 ako je a npr druga lokalna prom
		// dok ne dodelim vrednost a nula ce biti 
		// tj cita se vrednost te lokalne promenljive iz aktivacionog bloka 
		// tj sa proc steka
		
		if (designFactor.getDesignator().obj.getType().getKind() == Struct.Enum) {
			currSet = designFactor.getDesignator().obj;
			Code.load(designFactor.getDesignator().obj);
		}
		else {
			Code.load(designFactor.getDesignator().obj);
		}
	}
	
	@Override
	public void visit(FactorNew factor) {
		if (factor.getType().struct.equals(Tab.charType)) {
			// b = 0
			Code.put(Code.newarray);
			Code.put(0);
		}
		else if (factor.getType().struct.getKind() == Struct.Enum) {
			Code.loadConst(1);
			Code.put(Code.add); //dodajem jos jedan elem u kome cuvam stvaran broj elemenata skupa
			Code.put(Code.newarray);
			Code.put(1);
		}
		else {
			// b = 1
			Code.put(Code.newarray);
			Code.put(1);
		}
	}
	
	@Override
	public void visit(DesignatorArrayName name) {
		Code.load(name.obj); //ucitavam adresu niza
	}
	
	@Override
	public void visit(Assignment assignment) {
		Obj designator = assignment.getDesignator().obj;
		Code.store(designator);
	}
	
	@Override
	public void visit(DesignatorSetop setop) {
		Obj des1 = setop.getDesignator().obj;
		Obj des2 = setop.getDesignator1().obj;
		Obj des3 = setop.getDesignator2().obj;
		
		for (int i = 0; i < 2; i++) {
			Code.load(des1);
			if (i == 0)
				Code.load(des2);
			else
				Code.load(des3);
			
			Code.loadConst(0);
			//stek: set1 set2 0
			
			int adr = Code.pc;
			Code.loadConst(1);
			Code.put(Code.add);
			//stek: set1 set2 1
			Code.put(Code.dup_x2);
			//stek: 1 set1 set2 1
			Code.put(Code.aload);
			//stek: 1 set1 set2[1]
			int offset = Tab.find("add").getAdr() - Code.pc;
			Code.put(Code.call);
			Code.put2(offset);
			
			//stek: 1
			Code.put(Code.dup);
			//stek: 1 1
			if (i == 0)
				Code.load(des2);
			else
				Code.load(des3);
			Code.loadConst(0);
			Code.put(Code.aload);
			//stek: 1 1 set2[0]
			Code.putFalseJump(Code.ne, 0); //zavrsavamo
			int mesto1 = Code.pc - 2;
			
			//stek: 1
			Code.load(des1);
			//stek: 1 set1
			Code.put(Code.dup_x1);
			//stek: set1 1 set1
			Code.put(Code.pop);
			//stek: set1 1 
			if (i == 0)
				Code.load(des2);
			else
				Code.load(des3);
			//stek: set1 1 set2
			Code.put(Code.dup_x1);
			//stek: set1 set2 1 set2
			Code.put(Code.pop);
			//stek: set1 set2 1
			
			Code.putJump(adr);
			
			Code.fixup(mesto1);		
			Code.put(Code.pop);
		}
		
	}
	
	@Override
	public void visit(DesignatorInc designator) {
		if (designator.getDesignator().obj.getKind() == Obj.Elem) {
			Code.put(Code.dup2);
		}
		Code.load(designator.getDesignator().obj);
		Code.loadConst(1);
		Code.put(Code.add);
		Code.store(designator.getDesignator().obj);
	}
	
	@Override
	public void visit(DesignatorDec designator) {
		if (designator.getDesignator().obj.getKind() == Obj.Elem) {
			Code.put(Code.dup2);
		}
		Code.load(designator.getDesignator().obj);
		Code.loadConst(1);
		Code.put(Code.sub);
		Code.store(designator.getDesignator().obj);
	}
	
	@Override
	public void visit(ProcCall designator) {
		int offset = designator.getDesignatorProcCall().getDesignator().obj.getAdr() - Code.pc;
		//bitno je da ovo bude pre Code.put jer on inkrementira pc
		Code.put(Code.call);
		Code.put2(offset);
		
		if (designator.getDesignatorProcCall().getDesignator().obj.getType() != Tab.noType) {
			Code.put(Code.pop);
			// ovo je za slucaj f(); bez cuvanja vrednosti u neku prom i = f();
		}
	}
	
	@Override
	public void visit(MinusTermExpr term) {
		Code.put(Code.neg);
	}
	
	@Override
	public void visit(ReturnStmt returnStmt) { // return;
		returnFound = true;
		Code.put(Code.exit);
		Code.put(Code.return_);
	}
	
	@Override
	public void visit(ReturnExprStmt returnExprStmt) { // expr ostaje na steku
		returnFound = true;
		Code.put(Code.exit);
		Code.put(Code.return_);
	}
	
	
	@Override
	public void visit(ReadStmt readStmt) { 
		if (readStmt.getDesignator().obj.getType().getKind() == Struct.Char) {
			Code.put(Code.bread);
		}
		else {
			Code.put(Code.read);
		}
		Code.store(readStmt.getDesignator().obj);
	}
	
	/*  ======================== skokovi ========================== */
	
	private List<Integer> jmpOr = new ArrayList<>(); 
	private List<Integer> jmpThen = new ArrayList<>();
	private List<Integer> jmpElse =new ArrayList<>();
	private List<Integer> jmpAfterElse = new ArrayList<>();
	private List<Integer> doWhileCond = new ArrayList<>();
	private Stack<List<Integer>> breakJmp = new Stack<>();
	private Stack<List<Integer>> continueJmp = new Stack<>();
	
	@Override
	public void visit(SimpleCond condFact) {
		Code.loadConst(1);
		Code.putFalseJump(Code.eq, 0); // ako nisu jednaki skacemo, uslov nije ispunjen
		// na steku je x i 1 ako je x = 1 uslov je ispunjen i nastavljam na sledeci and
		// ako nije skacem na sl OR
		jmpOr.add(Code.pc - 2);
	}
	
	@Override
	public void visit(CondRelop cond) {
		int code = 0;
		if (cond.getRelop() instanceof RelopEq)
			code = Code.eq;
		else if (cond.getRelop() instanceof RelopNeq)
			code = Code.ne;
		else if (cond.getRelop() instanceof RelopGt)
			code = Code.gt;
		else if (cond.getRelop() instanceof RelopGte)
			code = Code.ge;
		else if (cond.getRelop() instanceof RelopLs)
			code = Code.lt;
		else if (cond.getRelop() instanceof RelopLse)
			code = Code.le;
		
		Code.putFalseJump(code, 0);
		jmpOr.add(Code.pc - 2);
	}
	
	@Override
	public void visit(ConditionTerm condTerm) {
		if (condTerm.getParent() instanceof CondAnd) return; //tad samo nastavljamo da proveravamo sl uslov iza and
		
		//proverili smo sve and uslove i bili su ispunjeni svi
		//tj imali smo if (x || ....) i x je ispunjeno i idemo na then
		Code.putJump(0);
		jmpThen.add(Code.pc - 2);
		
		for (int i = 0; i < jmpOr.size(); i++) {
		    Code.fixup(jmpOr.get(i));
		}
		jmpOr.clear();
		
	}
	
	@Override
	public void visit(CondAnd condTerm) {
		if (condTerm.getParent() instanceof CondAnd) return;
		
		Code.putJump(0);
		jmpThen.add(Code.pc - 2);
		
		for (int i = 0; i < jmpOr.size(); i++) {
		    Code.fixup(jmpOr.get(i));
		}
		jmpOr.clear();
	}
	
	@Override
	public void visit(Cond cond) {
		if (cond.getParent() instanceof CondOr) return;
		
		// ovo je poslednji uslov iza || 
		// ako smo do njega dosli a nismo nigde izbaceni sa putjmpfalse
		// treba da se ide na else, uslov nije ispunjen
		// a samo jednom se ovo poziva, jedno mesto za prepravku
		//jedan je poslednji uslov
		Code.putJump(0);
		jmpElse.add(Code.pc - 2);
		// a posto je ovo poslednji uslov dalje u kodu sledi then grana
		//pa sve koje su imale ispunjen bar jedan or uslov idu na then
		
		for (int i = 0; i < jmpThen.size(); i++) {
		    Code.fixup(jmpThen.get(i));
		}
		jmpThen.clear();
		
	}
	
	@Override
	public void visit(CondOr cond) {
		if (cond.getParent() instanceof CondOr) return;
		Code.putJump(0);
		jmpElse.add(Code.pc - 2);
		
		for (int i = 0; i < jmpThen.size(); i++) {
		    Code.fixup(jmpThen.get(i));
		}
		jmpThen.clear();
	}
	
	@Override
	public void visit(IfStmt ifStmt) {
		// poslednje je se izgenerisao kod za statement koji je se u if-u izvrsavao i sada se ide dalje
		Code.fixup(jmpElse.remove(jmpElse.size() - 1));
	}
	
	@Override
	public void visit(ElseNT elseStatement) {
		Code.putJump(0);
		jmpAfterElse.add(Code.pc - 2);
		
		Code.fixup(jmpElse.remove(jmpElse.size() - 1));
	}
	
	@Override
	public void visit(IfElseStmt ifElseStmt) {
		Code.fixup(jmpAfterElse.remove(jmpAfterElse.size() - 1));
		// prosao je else
		//tok koji je bio tacan treba ovde da nastavi
	}
	
	@Override
	public void visit(DoWhileStart doWhileStart) {
		doWhileCond.add(Code.pc);
		
		breakJmp.add(new ArrayList<>());
		continueJmp.add(new ArrayList<>());
	}
	
	@Override
	public void visit(DoWhileStmt doWhileStmt) {
		Code.putJump(doWhileCond.remove(doWhileCond.size() - 1));
		
		Code.fixup(jmpElse.remove(jmpElse.size() - 1));
		
		for (int i = 0; i < breakJmp.peek().size() ; i++) {
			Code.fixup(breakJmp.peek().get(i));
		}
		breakJmp.pop();
	}
	
	@Override
	public void visit(DoWhileWhitOutCond doWhileWhitOutCond) {
		Code.putJump(doWhileCond.remove(doWhileCond.size() - 1));
		
		for (int i = 0; i < breakJmp.peek().size() ; i++) {
			Code.fixup(breakJmp.peek().get(i));
		}
		breakJmp.pop();
	}
	
	@Override
	public void visit(DoWhileStmtDes doWhileStmtDes) {
		Code.putJump(doWhileCond.remove(doWhileCond.size() - 1));
		
		Code.fixup(jmpElse.remove(jmpElse.size() - 1));
		
		for (int i = 0; i < breakJmp.peek().size() ; i++) {
			Code.fixup(breakJmp.peek().get(i));
		}
		breakJmp.pop();
	}
	
	@Override
	public void visit(BreakStmt breakStmt) {
		Code.putJump(0);
		breakJmp.peek().add(Code.pc - 2);	
	}
	
	@Override
	public void visit(ContinueStmt continueStmt) {
		Code.putJump(0);
		continueJmp.peek().add(Code.pc - 2);
	}
	
	@Override
	public void visit(WhileNT whileNT) {
		for (int i = 0; i < continueJmp.peek().size() ; i++) {
			Code.fixup(continueJmp.peek().get(i));
		}
		continueJmp.pop();
	}
	
}
