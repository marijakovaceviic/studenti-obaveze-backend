// generated with ast extension for cup
// version 0.8
// 19/7/2025 16:18:7


package rs.ac.bg.etf.pp1.ast;

public class FuncCall extends Factor {

    private DesignatorProcCall DesignatorProcCall;
    private ActPars ActPars;

    public FuncCall (DesignatorProcCall DesignatorProcCall, ActPars ActPars) {
        this.DesignatorProcCall=DesignatorProcCall;
        if(DesignatorProcCall!=null) DesignatorProcCall.setParent(this);
        this.ActPars=ActPars;
        if(ActPars!=null) ActPars.setParent(this);
    }

    public DesignatorProcCall getDesignatorProcCall() {
        return DesignatorProcCall;
    }

    public void setDesignatorProcCall(DesignatorProcCall DesignatorProcCall) {
        this.DesignatorProcCall=DesignatorProcCall;
    }

    public ActPars getActPars() {
        return ActPars;
    }

    public void setActPars(ActPars ActPars) {
        this.ActPars=ActPars;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(DesignatorProcCall!=null) DesignatorProcCall.accept(visitor);
        if(ActPars!=null) ActPars.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(DesignatorProcCall!=null) DesignatorProcCall.traverseTopDown(visitor);
        if(ActPars!=null) ActPars.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(DesignatorProcCall!=null) DesignatorProcCall.traverseBottomUp(visitor);
        if(ActPars!=null) ActPars.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("FuncCall(\n");

        if(DesignatorProcCall!=null)
            buffer.append(DesignatorProcCall.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ActPars!=null)
            buffer.append(ActPars.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [FuncCall]");
        return buffer.toString();
    }
}
