package rs.ac.bg.etf.pp1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Stack;

import org.apache.log4j.Logger;

import rs.ac.bg.etf.pp1.ast.*;
import rs.etf.pp1.symboltable.Tab;
import rs.etf.pp1.symboltable.concepts.Obj;
import rs.etf.pp1.symboltable.concepts.Struct;

public class SemanticAnalyzer extends VisitorAdaptor {
	
	Logger log = Logger.getLogger(getClass());
	
	boolean errorDetected = false;
	boolean returnFound = false;
	private Struct currentType;
	private int doWhile = 0;
	int nVars;
	
	Struct boolType = new Struct(Struct.Bool);
	Struct setType = new Struct(Struct.Enum, Tab.intType); //uzela sam konstantu za enum da oznacava set
	
	private static Obj addObj, addAllObj;
	private Obj currentMethod;
	Stack<List<Struct>> allListsActParams = new Stack<>();

	public SemanticAnalyzer() {
		
		Tab.currentScope().addToLocals(new Obj(Obj.Type, "bool", boolType, -1, -1));
		Tab.currentScope().addToLocals(new Obj(Obj.Type, "set", setType, -1, -1));
		
		Tab.currentScope().addToLocals(addObj = new Obj(Obj.Meth, "add", Tab.noType, 0, 2));
		{
			Tab.openScope();
			Tab.currentScope.addToLocals(new Obj(Obj.Var, "a", setType, 0, 1));
			Tab.currentScope.addToLocals(new Obj(Obj.Var, "b", Tab.intType, 1, 1));
			Tab.currentScope.addToLocals(new Obj(Obj.Var, "i", Tab.intType, 2, 1));
			//Tab.currentScope.addToLocals(new Obj(Obj.Var, "c", Tab.intType, 3, 1));//count
			addObj.setLocals(Tab.currentScope.getLocals());
			Tab.closeScope();
		}
		
		Tab.currentScope().addToLocals(addAllObj = new Obj(Obj.Meth, "addAll", Tab.noType, 0, 2));
		{
			Tab.openScope();
			Struct bType = new Struct(Struct.Array, Tab.intType); 
			Tab.currentScope.addToLocals(new Obj(Obj.Var, "a", setType, 0, 1));
			Tab.currentScope.addToLocals(new Obj(Obj.Var, "b", bType, 1, 1));
			Tab.currentScope.addToLocals(new Obj(Obj.Var, "i", Tab.intType, 2, 1));
			addAllObj.setLocals(Tab.currentScope.getLocals());
			Tab.closeScope();
		}
	}

	public void report_error(String message, SyntaxNode info) {
		errorDetected = true;
		StringBuilder msg = new StringBuilder(message);
		int line = (info == null) ? 0: info.getLine();
		if (line != 0)
			msg.append (" na liniji ").append(line);
		log.error(msg.toString());
	}

	public void report_info(String message, SyntaxNode info) {
		StringBuilder msg = new StringBuilder(message); 
		int line = (info == null) ? 0: info.getLine();
		if (line != 0)
			msg.append (" na liniji ").append(line);
		log.info(msg.toString());
	}
	
	public boolean passed() {
		return !errorDetected;
	}
	
	@Override
	public void visit(ProgramName programName) {
		programName.obj = Tab.insert(Obj.Prog, programName.getProgName(), Tab.noType);
		Tab.openScope();
	}
	
	@Override
	public void visit(Program program) {
		nVars = Tab.currentScope().getnVars();
		if (Tab.find("main") == Tab.noObj) {
			report_error("Nije definisana main funkcija! ", null);
		}
		Tab.chainLocalSymbols(program.getProgramName().obj);
		Tab.closeScope();
	}
	
	@Override
	public void visit(Type type) {
		Obj typeNode = Tab.find(type.getTypeName());
		if (typeNode == Tab.noObj) {
			report_error("Nije pronadjen tip " + type.getTypeName() + " u tabeli simbola", null);
			type.struct = Tab.noType;
		} 
		else {
			if (typeNode.getKind() == Obj.Type) {
				type.struct = typeNode.getType();
			} 
			else {
				report_error("Greska: Ime " + type.getTypeName() + " ne predstavlja tip ", type);
				type.struct = Tab.noType;
			}
		} 
		currentType = type.struct;
	}
	
	@Override
	public void visit(ConstantNumber numConst) {
		Obj constNode = Tab.find(numConst.getConstName());
		if (constNode != Tab.noObj) {
			report_error("Ime " + numConst.getConstName() + " vec postoji u tabeli simbola", numConst);
		}
		else {
			if (!Tab.intType.assignableTo(currentType)) {
				report_error("Vrednost koja se dodeljuje konstanti " + numConst.getConstName()
				+ " nije kompatibilna sa njenim tipom ", numConst);
			}
			else {
				constNode = Tab.insert(Obj.Con, numConst.getConstName(), currentType);
				constNode.setAdr(numConst.getNumConst());
			}
		}
	}
	
	@Override
	public void visit(ConstantChar charConst) {
		Obj constNode = Tab.find(charConst.getConstName());
		if (constNode != Tab.noObj) {
			report_error("Ime " + charConst.getConstName() + " vec postoji u tabeli simbola", charConst);
		}
		else {
			if (!Tab.charType.assignableTo(currentType)) {
				report_error("Vrednost koja se dodeljuje konstanti " + charConst.getConstName()
				+ " nije kompatibilna sa njenim tipom ", charConst);
			}
			else {
				constNode = Tab.insert(Obj.Con, charConst.getConstName(), currentType);
				constNode.setAdr((int)charConst.getCharConst());
			}
		}
	}
	
	@Override
	public void visit(ConstantBool boolConst) {
		Obj constNode = Tab.find(boolConst.getConstName());
		if (constNode != Tab.noObj) {
			report_error("Ime " + boolConst.getConstName() + " vec postoji u tabeli simbola", boolConst);
		}
		else {
			if (!boolType.assignableTo(currentType)) {
				report_error("Vrednost koja se dodeljuje konstanti " + boolConst.getConstName()
				+ " nije kompatibilna sa njenim tipom ", boolConst);
			}
			else {
				constNode = Tab.insert(Obj.Con, boolConst.getConstName(), currentType);
				int value = 0;
				if (boolConst.getBoolConst() == true) {
					value = 1;
				}
				constNode.setAdr(value);
			}
		}
		
	}
	
	@Override 
	public void visit(VarDeclSimple varDecl) {
		Obj varNode = Tab.currentScope().findSymbol(varDecl.getVarName());
		if (varNode != null) {
			report_error("Ime " + varDecl.getVarName() + " vec postoji u tabeli simbola", varDecl);
		}
		else {
			varNode = Tab.insert(Obj.Var, varDecl.getVarName(), currentType);
		}
	}
	
	@Override 
	public void visit(VarDeclArray varDecl) {
		Obj varNode = Tab.currentScope().findSymbol(varDecl.getVarName());
		if (varNode != null) {
			report_error("Ime " + varDecl.getVarName() + " vec postoji u tabeli simbola", varDecl);
		}
		else {
			Struct nodeType = new Struct(Struct.Array, currentType); //ovaj cvor se ne deli kao ostali strukturni cvorovi
			varNode = Tab.insert(Obj.Var, varDecl.getVarName(), nodeType);
		}
	}
	
	@Override
	public void visit(MethodType methType) {
		currentMethod = Tab.find(methType.getMethName()); 
		if (currentMethod != Tab.noObj) {
			report_error("Ime " + methType.getMethName() + " vec postoji u tabeli simbola", methType);
		}
		else {
			currentMethod = Tab.insert(Obj.Meth, methType.getMethName(), methType.getType().struct);
			Tab.openScope();
		}
		methType.obj = currentMethod;
	}
	
	@Override
	public void visit(MethodVoid methVoid) {
		currentMethod = Tab.find(methVoid.getMethName());
		if (currentMethod != Tab.noObj) {
			report_error("Ime " + methVoid.getMethName() + " vec postoji u tabeli simbola", methVoid);
		}
		else {
			currentMethod = Tab.insert(Obj.Meth, methVoid.getMethName(), Tab.noType);
			Tab.openScope();
		}
		methVoid.obj = currentMethod;
	}
	
	@Override
	public void visit(MethodDecl methodDecl) {
		Tab.chainLocalSymbols(currentMethod);
		Tab.closeScope();
		if (!returnFound && currentMethod.getType() != Tab.noType) {
			report_error("Funkciji "+ currentMethod.getName() + " nedostaje return iskaz", methodDecl);
		}
		returnFound = false;
		currentMethod = null;
	}
	
	@Override
	public void visit(FormalParamDeclSimple formParam) {
		Obj paramNode = Tab.currentScope().findSymbol(formParam.getFormParamName());
		if (paramNode != null) {
			report_error("Ime " + formParam.getFormParamName() + " vec postoji u tabeli simbola", formParam);
		}
		else { 
			paramNode = Tab.insert(Obj.Var, formParam.getFormParamName(), currentType);
			//moze za tip i formParam.getType().struct
			currentMethod.setLevel(currentMethod.getLevel() + 1);
		}
	}
	
	@Override
	public void visit(FormalParamDeclArray formParam) {
		Obj paramNode = Tab.currentScope().findSymbol(formParam.getFormParamName());
		if (paramNode != null) {
			report_error("Ime " + formParam.getFormParamName() + " vec postoji u tabeli simbola", formParam);
		}
		else {
			Struct nodeType = new Struct(Struct.Array, currentType);
			paramNode = Tab.insert(Obj.Var, formParam.getFormParamName(), nodeType);
			currentMethod.setLevel(currentMethod.getLevel() + 1);
		}
	}
	
	@Override
	public void visit(FactorNumber factorNumber) {
		factorNumber.struct = Tab.intType;
	}
	
	@Override
	public void visit(FactorChar factorChar) {
		factorChar.struct = Tab.charType;
	}
	
	@Override
	public void visit(FactorExpr factorExpr) {
		factorExpr.struct = factorExpr.getExpr().struct;
	}
	
	@Override
	public void visit(FactorBool factorBool) {
		factorBool.struct = boolType;
	}
	
	@Override
	public void visit(FuncCall funcCall) {
		if (funcCall.getDesignatorProcCall().getDesignator().obj.getKind() != Obj.Meth) {
			report_error("Ime " + funcCall.getDesignatorProcCall().getDesignator().obj.getName() + " nije funkcija", funcCall);
			funcCall.struct = Tab.noType;
		}
		else {
			Obj func = funcCall.getDesignatorProcCall().getDesignator().obj;
			funcCall.struct = func.getType();
			
			List<Struct> formParamList = new ArrayList<>();
			for (Obj local: func.getLocalSymbols()) { 
					formParamList.add(local.getType()); //ovde ce biti i lokalne prom ali prvo idu form param pa cu proveravati samo prvih level
			}
			
			List<Struct> actParamList = allListsActParams.pop();
			
			if (actParamList.size() != func.getLevel()) {
				report_error("Broj stvarnih argumenata funkcije " + func.getName() + " se ne slaze sa brojem formalnih",funcCall);
			}
			else {
				for (int i = 0; i < func.getLevel(); i++) {
					if (!actParamList.get(i).assignableTo(formParamList.get(i))) {
						report_error("Argumnet broj " + (i + 1) + " nije dodeljiv formalnom argumentu na toj poziciji funkcije " + func.getName(), funcCall);
					}
				}
			}

		}
	}
	
	@Override
	public void visit(FactorDes factorDes) {
		factorDes.struct = factorDes.getDesignator().obj.getType();
	}
	
	@Override
	public void visit(FactorNew factorNew) {
		if (!factorNew.getExpr().struct.equals(Tab.intType)) { 
			report_error("Velicina niza ili skupa mora biti int tipa " , factorNew);
			factorNew.struct = Tab.noType;
		}
		else {
			if (factorNew.getType().struct.equals(setType)) { 
				factorNew.struct = setType;
			}
			else if (factorNew.getType().struct != Tab.noType) {
				Struct arrayType = new Struct(Struct.Array, factorNew.getType().struct);
				factorNew.struct = arrayType;
			}
			else {
				factorNew.struct = Tab.noType;
			}
		}
	}
	
	@Override
	public void visit(TermSimple term) {
		term.struct = term.getFactor().struct;
	}
	
	@Override
	public void visit(TermMul term) {
		Struct t = term.getTerm().struct;
		Struct f = term.getFactor().struct;
		if (t.equals(f) && t == Tab.intType) {
			term.struct = t;
		}
		else {
			report_error("Nekompatibilni tipovi u izrazu za mnozenje", term);
			term.struct = Tab.noType;
		}
	}
	
	@Override
	public void visit(TermExpr expr) {
		expr.struct = expr.getTerm().struct;
	}
	
	@Override
	public void visit(MinusTermExpr expr) {
		if (expr.getTerm().struct.equals(Tab.intType)) {
			expr.struct = Tab.intType;
		}
		else {
			report_error("Nije moguce negirati vrednost koja nije int tipa ", expr);
			expr.struct = Tab.noType;
		}	
	}
	
	@Override
	public void visit(AddExpr expr) {
		Struct t = expr.getExpr().struct;
		Struct te = expr.getTerm().struct;
		if (t.equals(te) && t == Tab.intType) {
			expr.struct = t;
		}
		else {
			report_error("Nekompatibilni tipovi u izrazu za sabiranje", expr);
			expr.struct = Tab.noType;
		}
	}
	
	@Override
	public void visit(MapExpr expr) {
		boolean paramDes1ok = false;
		boolean des1ok = false;
		boolean des2ok = false;
		Obj des1 = expr.getDesignator().obj;
		Obj des2 = expr.getDesignator1().obj;
		if (des1.getKind() == Obj.Meth) {
			if (des1.getLevel() == 1) {
				Collection<Obj> localsVars = des1.getLocalSymbols();
				for (Obj local : localsVars) {
					if (local.getType().equals(Tab.intType)) {
						paramDes1ok = true;
						break;
					}
				}
				if (paramDes1ok == true) {
					if (des1.getType().equals(Tab.intType)) {
						des1ok = true;
					}
					else {
						report_error("Prvi designator mora biti funkcija kod map expresion-a", expr);
					}
				}
				else {
					report_error("Funkcija mora imati tacno jedan parametar tipa int", expr);
				}
			}
			else {
				report_error("Funkcija kao prvi designator kod map expresion-a mora imati tacno jedan parametar ", expr);
			}
		}
		else {
			report_error("Prvi designator mora biti funkcija kod map expresion-a", expr);
		}
		
		if (des2.getType().getKind() == Struct.Array) {
			if (des2.getType().getElemType().equals(Tab.intType)) {
				des2ok = true;
			}
			else {
				report_error("Niz kao drugi designator kod map expresion-a mora imati elemente tipa int ", expr);
			}
		}
		else {
			report_error("Drugi designator kod map expresion-a mora biti niz ", expr);
		}
		
		if (des1ok && des2ok) {
			expr.struct = Tab.intType; // zbir rezultata poziva fje za svaki elem niza
		}
		else {
			expr.struct = Tab.noType;
		}
	}
	
	@Override
	public void visit(DesignatorSimple designator) {
		Obj obj = Tab.find(designator.getName());
		if (obj == Tab.noObj) { 
			report_error("Ime " + designator.getName() + " nije deklarisano! ", designator);
		}
		designator.obj = obj;
	}
	
	@Override
	public void visit(DesignatorArray designator) {
		// ovo je npr niz[5]
		// u tom trenutku moramo imati vec u tabeli simbola ime niz
		// i ono mora za type imati Array 
		// pravimo za ovo koriscenje niz[5] novi obj koji ce klasa DesignatorArray
		//cuvati u sebi kao svoj tip koji ce se proveravati u operacijama
		// obj kind je elem 
		// a obj type je tip elemenata ovog niza
		Obj obj = Tab.find(designator.getDesignatorArrayName().getName());
		if (obj == Tab.noObj) { 
			report_error("Ime " + designator.getDesignatorArrayName().getName() + " nije deklarisano! ", designator);
			designator.obj = Tab.noObj;
		}
		if (obj.getKind() != Obj.Var || obj.getType().getKind() != Struct.Array) {
			report_error("Promenljiva koja se indeksira "+ designator.getDesignatorArrayName().getName() + " nije niz! ", designator);
			designator.obj = Tab.noObj;
		}
		else {
			if (!designator.getExpr().struct.equals(Tab.intType)) {
				report_error("Izraz unutar [] prilikom indeksiranja niza "+ designator.getDesignatorArrayName().getName() + " mora biti int tipa ", designator);
				designator.obj = Tab.noObj;
			}
			else {
				designator.obj = new Obj(Obj.Elem, designator.getDesignatorArrayName().getName(), obj.getType().getElemType());
			}
		}
		
	}
	
	@Override
	public void visit(Assignment designator) {
		if (designator.getDesignator().obj.getKind() != Obj.Var && designator.getDesignator().obj.getKind() != Obj.Elem) {
			report_error("U izrazu dodele, vrednost se moze dodeliti samo promenljivoj ili elementu niza ", designator);
		}
		else if (!designator.getExpr().struct.assignableTo(designator.getDesignator().obj.getType())) {
			report_error("Tip izraza nije kompatibilan sa tipom promenljive kojoj se dodeljuje ", designator);	
		}	
	}
	
	@Override
	public void visit(DesignatorSetop designator) {
		Obj des1 = designator.getDesignator().obj;
		Obj des2 = designator.getDesignator1().obj;
		Obj des3 = designator.getDesignator2().obj;
		
		if (!des1.getType().equals(setType) || !des2.getType().equals(setType) || !des3.getType().equals(setType)) {
			report_error("Svaki od designator-a u set operaciji mora biti tipa set ", designator);	
		}
	}
	
	@Override
	public void visit(DesignatorInc designator) {
		if (designator.getDesignator().obj.getKind() != Obj.Var && designator.getDesignator().obj.getKind() != Obj.Elem) {
			report_error("Moze se inkrementirati samo promenljiva ili element niza ", designator);
		}
		else if (!designator.getDesignator().obj.getType().equals(Tab.intType)) {
			report_error("Promenljiva koja se inkrementira mora biti tipa int ", designator);
		}
	}
	
	@Override
	public void visit(DesignatorDec designator) {
		if (designator.getDesignator().obj.getKind() != Obj.Var && designator.getDesignator().obj.getKind() != Obj.Elem) {
			report_error("Moze se dekrementirati samo promenljiva ili element niza ", designator);
		}
		else if (!designator.getDesignator().obj.getType().equals(Tab.intType)) {
			report_error("Promenljiva koja se dekrementira mora biti tipa int ", designator);
		}
	}
	
	@Override
	public void visit(ProcCall designator) {
		if (designator.getDesignatorProcCall().getDesignator().obj.getKind() != Obj.Meth) {
			report_error("Ime " + designator.getDesignatorProcCall().getDesignator().obj.getName() + " nije funkcija", designator);
		}
		else { 
			Obj func = designator.getDesignatorProcCall().getDesignator().obj;
			List<Struct> formParamList = new ArrayList<>();
	
			for (Obj local: func.getLocalSymbols()) {
				formParamList.add(local.getType());
			}
			List<Struct> actParamList = allListsActParams.pop();

			if (actParamList.size() != func.getLevel()) {
				report_error("Broj stvarnih argumenata funkcije " + func.getName() + " se ne slaze sa brojem formalnih",designator);
			}
			else {
				for (int i = 0; i < func.getLevel(); i++) {
					if (!actParamList.get(i).assignableTo(formParamList.get(i))) {
						report_error("Argumnet broj " + (i + 1) + " nije dodlejiv formalnom argumentu na toj poziciji funkcije " + func.getName(), designator);
					}
				}
			}
		}
	}
	
	@Override
	public void visit(ReadStmt statement) {
		Obj desNode = statement.getDesignator().obj;
		if (desNode.getKind() != Obj.Var && desNode.getKind() != Obj.Elem) {
			report_error("Izraz u read statement-u mora biti promenljiva ili element niza  ", statement);
		}
		Struct node = statement.getDesignator().obj.getType();
		if (!node.equals(Tab.intType) && !node.equals(Tab.charType) && !node.equals(boolType)) {
			report_error("Izraz u read statement-u mora biti tipa int, char ili bool  ", statement);
		}
	}
	
	@Override
	public void visit(PrintStmtFormat statement) {
		Struct stm = statement.getExpr().struct;
		if (!stm.equals(Tab.intType) && !stm.equals(Tab.charType) && !stm.equals(boolType) && !stm.equals(setType)) {
			report_error("Promenljiva koja se ispisuje mora biti tipa int, char, bool ili set ", statement);
		}
		
	}
	
	@Override
	public void visit(PrintStmt statement) {
		Struct stm = statement.getExpr().struct;
		if (!stm.equals(Tab.intType) && !stm.equals(Tab.charType) && !stm.equals(boolType) && !stm.equals(setType)) {
			report_error("Promenljiva koja se ispisuje mora biti tipa int, char, bool ili set ", statement);
		}
	}
	
	@Override
	public void visit(CondRelop condRelop) {
		if (!condRelop.getExpr().struct.compatibleWith(condRelop.getExpr1().struct)){
			report_error("Tipovi izraza izmedju kojih se vrsi relaciona operacija nisu kompatibilni ", condRelop);
		}
		if (condRelop.getExpr().struct.getKind() == Struct.Array || condRelop.getExpr1().struct.getKind() == Struct.Array) {
			if (condRelop.getRelop() instanceof RelopGt || condRelop.getRelop() instanceof RelopGte || condRelop.getRelop() instanceof RelopLs || condRelop.getRelop() instanceof RelopLse) {
				report_error("Uz promenljive tipa niza mogu da se koriste samo != i == ", condRelop);
			}
		}		
	}
	
	@Override
	public void visit(SimpleCond simpleCond) {
		if (!simpleCond.getExpr().struct.equals(boolType)){
			report_error("Izraz u uslovu mora biti bool tipa ", simpleCond);
		}	
	}
	
	@Override
	public void visit(DoWhileStart doWhileStart) {
		doWhile++;
	}
	
	@Override
	public void visit(DoWhileStmt doWhileEnd) {
		doWhile--;
	}
	
	@Override
	public void visit(BreakStmt breakStmt) {
		if (doWhile == 0) {
			report_error("Break se nalazi izvan do-while petlje ", breakStmt);
		}
	}
	
	@Override
	public void visit(ContinueStmt continueStmt) {
		if (doWhile == 0) {
			report_error("Continue se nalazi izvan do-while petlje ", continueStmt);
		}
	}
	
	@Override
	public void visit(ReturnExprStmt returnExpr) { // return expr;
		returnFound = true;
		if (currentMethod == null) {
			report_error("Return naredba se nalazi van funkcije ", returnExpr);
		}
		else if (currentMethod.getType() == Tab.noType) {
			report_error("Postoji return naredba sa povratnom vrednosti u funkciji " + currentMethod.getName() + " koja je deklarisana kao void", returnExpr);
        }
		else if (!currentMethod.getType().equals(returnExpr.getExpr().struct)) {
			report_error("Povrtani tip return izraza nije onaj koji funkcija " + currentMethod.getName() + " ocekuje " ,returnExpr);
		}
		
	}
	
	@Override
	public void visit(ReturnStmt returnStmt) { // return;
		returnFound = true;
		if (currentMethod == null) {
			report_error("Return naredba se nalazi van funkcije ", returnStmt);
		}
		else if (currentMethod.getType() != Tab.noType) {
			report_error("Nevalidna return naredba (bez povratne vrednosti) u funkciji " + currentMethod.getName() , returnStmt);
        }
	}
	
	
	@Override
	public void visit(ActualParam actualParam) {
		allListsActParams.peek().add(actualParam.getExpr().struct);
	}
	
	@Override
	public void visit(ActualParams actualParams) {
		allListsActParams.peek().add(actualParams.getExpr().struct);
	}
	
	@Override
	public void visit(DesignatorProcCall designator) {
		allListsActParams.push(new ArrayList<>());
	}
	
	@Override
	public void visit(DesignatorArrayName designator) {
		designator.obj = Tab.find(designator.getName());
	} 
}
