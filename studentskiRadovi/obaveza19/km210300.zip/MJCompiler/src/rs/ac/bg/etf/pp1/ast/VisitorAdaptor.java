// generated with ast extension for cup
// version 0.8
// 19/7/2025 16:18:7


package rs.ac.bg.etf.pp1.ast;

public abstract class VisitorAdaptor implements Visitor { 

    public void visit(Mulop Mulop) { }
    public void visit(Relop Relop) { }
    public void visit(VarDeclN VarDeclN) { }
    public void visit(FormalParamDecl FormalParamDecl) { }
    public void visit(MethodSignature MethodSignature) { }
    public void visit(StatementList StatementList) { }
    public void visit(ActParams ActParams) { }
    public void visit(ConstVarDeclList ConstVarDeclList) { }
    public void visit(Addop Addop) { }
    public void visit(Factor Factor) { }
    public void visit(CondTerm CondTerm) { }
    public void visit(Designator Designator) { }
    public void visit(Term Term) { }
    public void visit(Condition Condition) { }
    public void visit(ConstDeclList ConstDeclList) { }
    public void visit(VarDeclOne VarDeclOne) { }
    public void visit(IfCondition IfCondition) { }
    public void visit(VarDeclList VarDeclList) { }
    public void visit(FormalParamList FormalParamList) { }
    public void visit(Expr Expr) { }
    public void visit(ActPars ActPars) { }
    public void visit(MethodTypeName MethodTypeName) { }
    public void visit(DesignatorStatement DesignatorStatement) { }
    public void visit(Statement Statement) { }
    public void visit(VarDecl VarDecl) { }
    public void visit(CondFact CondFact) { }
    public void visit(ConstDeclOne ConstDeclOne) { }
    public void visit(MethodDeclList MethodDeclList) { }
    public void visit(FormPars FormPars) { }
    public void visit(ErrIfCond ErrIfCond) { visit(); }
    public void visit(IfCond IfCond) { visit(); }
    public void visit(RelopLse RelopLse) { visit(); }
    public void visit(RelopLs RelopLs) { visit(); }
    public void visit(RelopGte RelopGte) { visit(); }
    public void visit(RelopGt RelopGt) { visit(); }
    public void visit(RelopNeq RelopNeq) { visit(); }
    public void visit(RelopEq RelopEq) { visit(); }
    public void visit(CondRelop CondRelop) { visit(); }
    public void visit(SimpleCond SimpleCond) { visit(); }
    public void visit(CondAnd CondAnd) { visit(); }
    public void visit(ConditionTerm ConditionTerm) { visit(); }
    public void visit(CondOr CondOr) { visit(); }
    public void visit(Cond Cond) { visit(); }
    public void visit(ActualParams ActualParams) { visit(); }
    public void visit(ActualParam ActualParam) { visit(); }
    public void visit(NoActuals NoActuals) { visit(); }
    public void visit(Actuals Actuals) { visit(); }
    public void visit(MulopMod MulopMod) { visit(); }
    public void visit(MulopDiv MulopDiv) { visit(); }
    public void visit(MulopMul MulopMul) { visit(); }
    public void visit(Setop Setop) { visit(); }
    public void visit(FactorNew FactorNew) { visit(); }
    public void visit(FactorDes FactorDes) { visit(); }
    public void visit(FuncCall FuncCall) { visit(); }
    public void visit(FactorBool FactorBool) { visit(); }
    public void visit(FactorExpr FactorExpr) { visit(); }
    public void visit(FactorChar FactorChar) { visit(); }
    public void visit(FactorNumber FactorNumber) { visit(); }
    public void visit(TermMul TermMul) { visit(); }
    public void visit(TermSimple TermSimple) { visit(); }
    public void visit(AddopMinus AddopMinus) { visit(); }
    public void visit(AddopPlus AddopPlus) { visit(); }
    public void visit(MapExpr MapExpr) { visit(); }
    public void visit(AddExpr AddExpr) { visit(); }
    public void visit(MinusTermExpr MinusTermExpr) { visit(); }
    public void visit(TermExpr TermExpr) { visit(); }
    public void visit(DesignatorArrayName DesignatorArrayName) { visit(); }
    public void visit(DesignatorArray DesignatorArray) { visit(); }
    public void visit(DesignatorSimple DesignatorSimple) { visit(); }
    public void visit(DesignatorProcCall DesignatorProcCall) { visit(); }
    public void visit(ErrAsignment ErrAsignment) { visit(); }
    public void visit(ProcCall ProcCall) { visit(); }
    public void visit(DesignatorDec DesignatorDec) { visit(); }
    public void visit(DesignatorInc DesignatorInc) { visit(); }
    public void visit(DesignatorSetop DesignatorSetop) { visit(); }
    public void visit(Assignment Assignment) { visit(); }
    public void visit(ElseNT ElseNT) { visit(); }
    public void visit(WhileNT WhileNT) { visit(); }
    public void visit(DoWhileStart DoWhileStart) { visit(); }
    public void visit(StatementsInBrackets StatementsInBrackets) { visit(); }
    public void visit(DoWhileStmtDes DoWhileStmtDes) { visit(); }
    public void visit(DoWhileWhitOutCond DoWhileWhitOutCond) { visit(); }
    public void visit(DoWhileStmt DoWhileStmt) { visit(); }
    public void visit(ReturnStmt ReturnStmt) { visit(); }
    public void visit(ReturnExprStmt ReturnExprStmt) { visit(); }
    public void visit(ContinueStmt ContinueStmt) { visit(); }
    public void visit(BreakStmt BreakStmt) { visit(); }
    public void visit(PrintStmt PrintStmt) { visit(); }
    public void visit(PrintStmtFormat PrintStmtFormat) { visit(); }
    public void visit(ReadStmt ReadStmt) { visit(); }
    public void visit(IfElseStmt IfElseStmt) { visit(); }
    public void visit(IfStmt IfStmt) { visit(); }
    public void visit(DesignatorStmt DesignatorStmt) { visit(); }
    public void visit(NoStatement NoStatement) { visit(); }
    public void visit(Statements Statements) { visit(); }
    public void visit(FormalParamDeclSimple FormalParamDeclSimple) { visit(); }
    public void visit(FormalParamDeclArray FormalParamDeclArray) { visit(); }
    public void visit(FormalParamDecls FormalParamDecls) { visit(); }
    public void visit(SingleFormalParamDecl SingleFormalParamDecl) { visit(); }
    public void visit(NoFormPars NoFormPars) { visit(); }
    public void visit(FormalParameters FormalParameters) { visit(); }
    public void visit(MethodVoid MethodVoid) { visit(); }
    public void visit(MethodType MethodType) { visit(); }
    public void visit(ErrMethSignatureComma ErrMethSignatureComma) { visit(); }
    public void visit(ErrMethSignatureRparen ErrMethSignatureRparen) { visit(); }
    public void visit(MethSignature MethSignature) { visit(); }
    public void visit(NoVarDeclList NoVarDeclList) { visit(); }
    public void visit(ListOfVarDecl ListOfVarDecl) { visit(); }
    public void visit(MethodDecl MethodDecl) { visit(); }
    public void visit(NoMethodDeclList NoMethodDeclList) { visit(); }
    public void visit(MethodDeclarations MethodDeclarations) { visit(); }
    public void visit(Type Type) { visit(); }
    public void visit(VarDeclSimple VarDeclSimple) { visit(); }
    public void visit(VarDeclArray VarDeclArray) { visit(); }
    public void visit(SingleVarDecl SingleVarDecl) { visit(); }
    public void visit(VarDeclNDecl VarDeclNDecl) { visit(); }
    public void visit(ErrVarDeclSemi ErrVarDeclSemi) { visit(); }
    public void visit(ErrVarDeclComma ErrVarDeclComma) { visit(); }
    public void visit(VarDeclarations VarDeclarations) { visit(); }
    public void visit(ConstantBool ConstantBool) { visit(); }
    public void visit(ConstantChar ConstantChar) { visit(); }
    public void visit(ConstantNumber ConstantNumber) { visit(); }
    public void visit(SingleConstDecl SingleConstDecl) { visit(); }
    public void visit(ListOfConstDecl ListOfConstDecl) { visit(); }
    public void visit(ConstDecl ConstDecl) { visit(); }
    public void visit(NoConstVarDeclList NoConstVarDeclList) { visit(); }
    public void visit(ConstVarDeclListVar ConstVarDeclListVar) { visit(); }
    public void visit(ConstVarDeclListConst ConstVarDeclListConst) { visit(); }
    public void visit(ProgramName ProgramName) { visit(); }
    public void visit(Program Program) { visit(); }


    public void visit() { }
}
