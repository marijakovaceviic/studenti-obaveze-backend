// generated with ast extension for cup
// version 0.8
// 19/7/2025 16:18:7


package rs.ac.bg.etf.pp1.ast;

public class VarDeclarations extends VarDecl {

    private Type Type;
    private VarDeclN VarDeclN;

    public VarDeclarations (Type Type, VarDeclN VarDeclN) {
        this.Type=Type;
        if(Type!=null) Type.setParent(this);
        this.VarDeclN=VarDeclN;
        if(VarDeclN!=null) VarDeclN.setParent(this);
    }

    public Type getType() {
        return Type;
    }

    public void setType(Type Type) {
        this.Type=Type;
    }

    public VarDeclN getVarDeclN() {
        return VarDeclN;
    }

    public void setVarDeclN(VarDeclN VarDeclN) {
        this.VarDeclN=VarDeclN;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(Type!=null) Type.accept(visitor);
        if(VarDeclN!=null) VarDeclN.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(Type!=null) Type.traverseTopDown(visitor);
        if(VarDeclN!=null) VarDeclN.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(Type!=null) Type.traverseBottomUp(visitor);
        if(VarDeclN!=null) VarDeclN.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("VarDeclarations(\n");

        if(Type!=null)
            buffer.append(Type.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(VarDeclN!=null)
            buffer.append(VarDeclN.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [VarDeclarations]");
        return buffer.toString();
    }
}
