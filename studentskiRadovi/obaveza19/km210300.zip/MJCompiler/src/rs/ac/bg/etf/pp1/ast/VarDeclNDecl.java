// generated with ast extension for cup
// version 0.8
// 19/7/2025 16:18:7


package rs.ac.bg.etf.pp1.ast;

public class VarDeclNDecl extends VarDeclN {

    private VarDeclN VarDeclN;
    private VarDeclOne VarDeclOne;

    public VarDeclNDecl (VarDeclN VarDeclN, VarDeclOne VarDeclOne) {
        this.VarDeclN=VarDeclN;
        if(VarDeclN!=null) VarDeclN.setParent(this);
        this.VarDeclOne=VarDeclOne;
        if(VarDeclOne!=null) VarDeclOne.setParent(this);
    }

    public VarDeclN getVarDeclN() {
        return VarDeclN;
    }

    public void setVarDeclN(VarDeclN VarDeclN) {
        this.VarDeclN=VarDeclN;
    }

    public VarDeclOne getVarDeclOne() {
        return VarDeclOne;
    }

    public void setVarDeclOne(VarDeclOne VarDeclOne) {
        this.VarDeclOne=VarDeclOne;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(VarDeclN!=null) VarDeclN.accept(visitor);
        if(VarDeclOne!=null) VarDeclOne.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(VarDeclN!=null) VarDeclN.traverseTopDown(visitor);
        if(VarDeclOne!=null) VarDeclOne.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(VarDeclN!=null) VarDeclN.traverseBottomUp(visitor);
        if(VarDeclOne!=null) VarDeclOne.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("VarDeclNDecl(\n");

        if(VarDeclN!=null)
            buffer.append(VarDeclN.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(VarDeclOne!=null)
            buffer.append(VarDeclOne.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [VarDeclNDecl]");
        return buffer.toString();
    }
}
