#include "FlotaAviona.h"
#include <string>
#include <iostream>
using namespace std;

int main() {

	FlotaAviona flota1("prvaFlota");
	
	Pilot pilot1("Ivan",50,'L');
	Pilot pilot2("Milan",122,'L');
    Pilot pilot3("Petar",200);
	Pilot pilot4("Dragan",97,'N');
	
	Avion avion1("Airbus A3", 150);
	Avion avion2("Airbus M6", 200);
	Avion avion3("Airbus L4", 133);

	avion1.postavljanjeKapetana(&pilot4);
	avion1.postavljanjeKopilota(&pilot1);
	avion2.postavljanjeKapetana(&pilot2);
	avion2.postavljanjeKopilota(&pilot3);
	avion3.postavljanjeKapetana(&pilot3);
	avion3.postavljanjeKopilota(&pilot2);
	

	flota1.dodaj(&avion2);
	flota1.dodaj(&avion1);
	flota1.dodaj(&avion3);


	flota1.pisi();
	
	Avion* maksimalno=flota1.NalazenjeAvionaSaMaksPutnika();

	cout << "Avion sa najvise putnika je :" << endl;
	maksimalno->ispisi();

	
	
	
}