#ifndef PILOT_H
#define PILOT_H
#include <string>
#include <iostream>
using namespace std;

class Pilot {
private:
	string ime;
	int brSati;
	char naLetu;
	
public:

	Pilot(const Pilot& pilot) = delete;
	
	Pilot(string i, int br, char let='N') : ime(i), brSati(br), naLetu(let) {}
	 
	string dohvatiIme() const { return ime; }
	int dohvatiBrSati()const { return brSati; }
	char dohvatiStanje() const { return naLetu; }


	void promenaBrSati(int sati) {
		if (sati > 0) brSati += sati;
	}
	
	void promenaStanja(char stanje) {
		this->naLetu = stanje;
	}

	void ispisi() const {
		cout << ime << " (" << brSati << ") -" << naLetu << endl;
	}

	bool daLiMozeBitiPilot() const {
		if (brSati >= 100) return true;
		else return false;
	}

	
};
 
#endif
