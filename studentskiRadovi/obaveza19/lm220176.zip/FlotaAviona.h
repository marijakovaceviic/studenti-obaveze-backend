#ifndef FLOTA_H
#define FLOTA_H
#include "Avion.h"
#include <string>
#include <iostream>
using namespace std;

class FlotaAviona {	
private:
    string naziv;
	
	struct Elem {
		Avion* avion;
		Elem* sledeci;

		Elem(Avion* av, Elem* sl = nullptr) : avion(av), sledeci(sl){}

	};

	Elem* prvi = nullptr;
public:
	
	FlotaAviona(string naz) : naziv(naz){}; 
	FlotaAviona(const FlotaAviona& a);
	FlotaAviona(FlotaAviona&& a);
	~FlotaAviona();
	void dodaj(Avion* a);
	void pisi()const;
	int ukupanBrojAviona()const;
	int maksPutnikaUFloti()const;
	Avion* NalazenjeAvionaSaMaksPutnika()const;
};

#endif
