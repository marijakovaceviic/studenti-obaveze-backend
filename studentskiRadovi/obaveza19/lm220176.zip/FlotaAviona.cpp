#include "FlotaAviona.h"

FlotaAviona::FlotaAviona(const FlotaAviona& f){
	naziv = f.naziv;
	Elem* tek = f.prvi;
	Elem* novi = nullptr, * posl = nullptr;
	while (tek) {

		novi = new Elem(tek->avion);
		if (!prvi) prvi = novi;
		else posl->sledeci = novi;
		posl = novi;
		tek = tek->sledeci;
	}
}

FlotaAviona::FlotaAviona(FlotaAviona&& f) {
	naziv = f.naziv;
	prvi = f.prvi;
	f.prvi = nullptr;
}

FlotaAviona::~FlotaAviona() {
	Elem* tek = prvi, * stari;
	while (tek) {
		stari = tek;
		tek = tek->sledeci;
		delete stari;
	}
}

void FlotaAviona::dodaj(Avion* a) {
	prvi = new Elem(a, prvi);
}

void FlotaAviona::pisi()const {
	cout << naziv << endl;
	for (Elem* tek = prvi;tek;tek = tek->sledeci) {
		tek->avion->ispisi();
	}
}

int FlotaAviona::ukupanBrojAviona() const {
	int brAviona = 0;
	for (Elem* tek = prvi;tek;tek = tek->sledeci) {
		brAviona++;
	}
	return brAviona;
}

int FlotaAviona::maksPutnikaUFloti() const{
	int maks = 0;
	for (Elem* tek = prvi;tek;tek = tek->sledeci) {
		maks+= tek->avion->dohvatiMaksPutnika();
	}
	return maks;
}

Avion* FlotaAviona::NalazenjeAvionaSaMaksPutnika()const {
	Avion* avionSaNajvisePutnika = prvi->avion;
	for (Elem* tek1 = prvi;tek1->sledeci;tek1 = tek1->sledeci){
		for (Elem* tek2 = tek1->sledeci;tek2;tek2 = tek2->sledeci) {
			if (tek1->avion->dohvatiMaksPutnika() < tek2->avion->dohvatiMaksPutnika()) {
				avionSaNajvisePutnika = tek2->avion;
			}
		}
	}
	return avionSaNajvisePutnika;


}
