#ifndef AVION_H
#define AVION_H
#include "Pilot.h"
#include <string>
#include <iostream>
using namespace std;

class Avion {
private:
	string naziv;
	Pilot* kapetan;
	Pilot* kopilot;
	int maksPutnika;

public:

	
	Avion(const Avion& avion) = delete;

	Avion(string n, int maks) : naziv(n), maksPutnika(maks){}
	
	string dohvatiNaziv() const { return naziv; }
	int dohvatiMaksPutnika()const { return maksPutnika; }
	Pilot* dohvatiKapetana()const { return  kapetan; }
	Pilot* dohvatiKopilota()const { return  kopilot; }


	void postavljanjeKapetana(Pilot* pilot) {
		if (pilot->daLiMozeBitiPilot()) {
			this->kapetan = pilot;
			kapetan->promenaStanja('L');
		}
	}

	void postavljanjeKopilota(Pilot* pilot) {
		pilot->promenaStanja('L');
		this->kopilot = pilot;
	}

	void ispisi() const{
		cout << "AVION :" << naziv << " - " << maksPutnika <<endl;

	 }
	
};

#endif