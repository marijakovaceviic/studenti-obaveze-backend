package primer;

public class Meda extends Zivotinja {
	
	private int pojedenMed;

	public Meda(Kosnica kosnica, int minVreme, int maxVreme) {
		super(kosnica, minVreme, maxVreme);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void akcija() throws InterruptedException {
		synchronized (kosnica) {
			while (kosnica.dohvatiMed() == 0) kosnica.wait();
			pojedenMed += kosnica.dohvatiMed();
			// 
			kosnica.isprazniMed();
			kosnica.notifyAll();
			System.out.println(this);
		}
	}
	
	public int dohvatiPojedenMed() {
		return pojedenMed;
	}
	
	@Override
	public String toString() {
		return "M";
	}

}
