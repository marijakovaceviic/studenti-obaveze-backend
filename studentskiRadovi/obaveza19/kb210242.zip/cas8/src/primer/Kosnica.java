package primer;

public class Kosnica {
	
	private int med;
	private int kap;
	
	public Kosnica(int kap) {
		this.kap = kap;
	}
	
	public void dodajMed() throws InterruptedException {
		while(med == kap) this.wait(); // ...
		med++;
	}
	
	public void isprazniMed() throws InterruptedException {
		med = 0;
	}
	
	public int dohvatiMed() {
		return med;
	}
	
	@Override
	public String toString() {
		return "[" + med + "]";
	}

}
