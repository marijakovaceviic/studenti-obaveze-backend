package primer;

public abstract class Zivotinja extends Thread {
	
	protected Kosnica kosnica;
	private int minVreme, maxVreme;
	
	public Zivotinja(Kosnica kosnica, 
			int minVreme, int maxVreme) {
		super();
		this.kosnica = kosnica;
		this.minVreme = minVreme;
		this.maxVreme = maxVreme;
	}
	
	@Override
	public void run() {
		try {
			while(!Thread.interrupted()) {
				Thread.sleep(minVreme + (int)(Math.random() * 
					(maxVreme - minVreme)));
				akcija();
			}
		} catch (InterruptedException e) {}
		// ...
		
	}

	protected abstract void akcija() throws InterruptedException ;

}
