package primer;

public class Pcela extends Zivotinja {
	
	private int id;
	private int proizvedenMed;

	public Pcela(Kosnica kosnica, int minVreme, int maxVreme, int id) {
		super(kosnica, minVreme, maxVreme);
		this.id = id;
	}

	@Override
	protected void akcija() throws InterruptedException {
		synchronized (kosnica) {
			kosnica.dodajMed();
			kosnica.notifyAll();
			// 
			proizvedenMed++;
			System.out.print(this);
			System.out.println(kosnica);
		}
	}
	
	@Override
	public String toString() {
		return "P" + id + " ";
	}
	
	public int dohvatiProizvedenMed() {
		return proizvedenMed;
	}

}
